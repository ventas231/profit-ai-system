---
name: "pas-diagnostico-rentabilidad-v1-8-10"
description: "v1.8.10 · Profit AI System · Diagnóstico de Rentabilidad Amazon (recurso de entrada). Convierte 4 reportes de Seller Central y los costos del vendedor en un artefacto: tabla Parent/Child con una sola fórmula de contribución, cargos de cuenta y cobros por validar con CSV. Solo Amazon México. Úsala para diagnóstico de rentabilidad, qué producto deja dinero o qué cobros revisar."
---


# Diagnóstico de Rentabilidad Amazon México · v1.8.10


> **Profit AI System** · Recurso de entrada · **v1.8.10** · 2026-10-21 (cifras fuera de la página con código y fórmula completa; formato y rótulos del chat; cierre según si el CSV se pegó; conteo de celdas obligatorio)
> Historial: v1.0 base · v1.1 diseño con marca primero (no se publicó) · v1.2 plantilla del artefacto dentro de la skill y cargos de cuenta · **v1.3 una sola fórmula de contribución y una sola fuente de publicidad, comisión % con una sola fórmula, todo se pide al inicio, paso de guardado, sin la cifra «$5M+ USD en ventas verificadas», co-branding y CSV con respaldo copiable.** · **v1.4 sin semáforo cuando falta costo o venta neta, volumen contra contribuciones positivas, contribución del canal visible en el artefacto (sin fila TOTAL), titular de cobros igual al CSV, tasa de ISR por fecha con fuente, publicidad con nombres de Amazon sin importar mayúsculas, ventas de USA sin sales tax, cuadres 4 y 6 independientes y texto de privacidad corregido.** · **v1.5 las 3 decisiones y las alertas incluyen a los productos que pierden con 3% o más de las ventas, contribución del canal marcada INCOMPLETA y aviso grande cuando falta un costo, base de volumen sin renglones sin costo, campos de FBA en una sola base y alerta si la publicidad asignada supera el cargo de publicidad.** · **v1.5.1 cuadre 11 con toda la publicidad (SP + SB/SD), pregunta de cómo se paga Amazon Ads (saldo, tarjeta o mixto), cargo de publicidad reconocido por nombre si falta la etiqueta, decisiones Proteger y Arreglar solo con productos CORE o RELEVANTE, y «FBA cobrado» al lado de «FBA debería ser».** · **v1.5.2 Detener fuga elige entre los mismos productos que las alertas, la respuesta de cómo se paga Ads se reconoce sin importar mayúsculas, acentos ni espacios («no anuncio» incluido), y renglón visible del IVA de la factura de Ads mientras se decide la regla de IVA (D3).** · **v1.5.3 una respuesta que nombra saldo y tarjeta a la vez se toma como mixto, «no uso tarjeta» no cuenta como tarjeta, y el renglón del IVA de Ads dice «incluido» siempre que el reporte traiga el cargo.** · **v1.6 regla de IVA (D3) de Gerardo: en México todo se calcula con IVA, en una sola base (ventas, comisión, FBA, Ads y cargos); la retención de IVA del 8% y el ISR por producto van en renglones aparte; la caja del mes va en un bloque aparte; se quitó el renglón temporal de D31; «no de mis ventas» niega el saldo (D35).** · **v1.6.1 la caja del mes en su propia sección, con «Lo que quedó de las liquidaciones», el costo de producto y los Ads pagados con tarjeta en renglones propios (mismo resultado con saldo o tarjeta cuando el cobro es igual al gasto); la plantilla recibe el gasto del bulk sin IVA y le suma el IVA ella misma; tasa de IVA parametrizada (región fronteriza 8%, solo confirmada) con alto si la retención da 4%; chequeos de retención e ISR dentro de la plantilla; base de la retención con fuente (LIVA 18-J); más frases de negación en la forma de pago de Ads.** · **v1.6.2 «SUPUESTO SIN VERIFICAR» de los Ads con tarjeta también en los cargos y en los avisos; la publicidad siempre lleva el 16% de la factura de Amazon Ads (también en región fronteriza) y una retención entre 4% y 8% detiene y pregunta por ventas mezcladas; sin decisiones cuando la retención no cuadra; rótulo correcto si la publicidad del bulk no suma; la caja de USA ya no menciona el ISR; más frases de pago de Ads.** Si hay otra versión instalada (`pas-diagnostico-rentabilidad`, `-v1-2` a `-v1-6-1`), es vieja: usar esta. · **v1.6.3** (19-oct-2026) en región fronteriza el canal y la caja solo quedan iguales con saldo (con tarjeta: canal 474.69, caja 493.67 en P1); «no ocupo tarjeta», «ventas no, tarjeta» y «ni saldo ni tarjeta» (D49); con tasa de IVA no reconocida no se revisan retención ni ISR (D50); bordes de la retención en pesos con medio centavo de tolerancia y porcentajes con 2 decimales (D51); retención en 0 (D48) PENDIENTE de la decisión de Gerardo · **v1.7** (19-oct-2026, decisión de Gerardo del 19-oct-2026 a las 10:01) solo Amazon México (se quitó USA); solo reglas vigentes de IVA y retención (16%, u 8% en región fronteriza confirmada) y sin preguntar tasas de ISR de 2025; ya no se pregunta cómo se paga la publicidad: en la rentabilidad sale siempre del archivo de Ads × 1.16 (D36, D44, D49 y D54 obsoletos); retención en 0 avisa y deja el canal POR VALIDAR (D48, opción B); un solo cerco de la plantilla (D52); porcentaje de la retención sin redondeo engañoso y con el rango en pesos (D55) · **v1.7.1** (19-oct-2026) porcentaje de la retención con 2 decimales y rango en pesos (D56); sin restos de USA y de pago de Ads (D58); la plantilla se detiene si la moneda no es MXN (D59); aviso de caja sin cargo de publicidad listo pero apagado, pendiente de Gerardo (D57) · **v1.8** (19-oct-2026, decisiones de Gerardo del 19-oct-2026 a las 10:20) aviso de caja sin cargo de publicidad PRENDIDO (D57); el cuadre 11 deja el canal POR VALIDAR; ISR de enero 2026 POR CONFIRMAR; el rango en pesos de los avisos de región fronteriza y de mezcla es el de 4% ($172.81–$181.67 en P1), calculado (D60) · **v1.8.1** (19-oct-2026, lote de pruebas de la vuelta 13) el aviso de retención rara también dice el rango de región fronteriza (D61); «</» se escribe «<\/» dentro de `DATA` (D62); la plantilla se detiene si un valor de `DATA` no es número (D63); los montos se redondean mitad hacia arriba (D64); los parámetros fiscales salen de la ficha «Parámetros fiscales y de marketplaces (vigentes)», no de las reglas generales (decisión de Gerardo). Ningún número cambia · **v1.8.2** (20-oct-2026) «Si el vendedor llega sin contexto» ya no menciona la pregunta 4 de la publicidad (se quitó en v1.7); «Entradas» ya no pide país ni dice «en México» (restos de USA). Plantilla y números sin cambio · **v1.8.3** (20-oct-2026) FBA y comisión por referencia **por banda de precio** y con regla fija (D66, D67); SP total desde los renglones de anuncio y «no asignable» negativo sin contribución (D69); ACOS con IVA en gasto y ventas, igual que la consola (E3), y ACOS total de la cuenta; solo el «Otro» negativo es candidato a ISR (E1) y su renglón dice qué mes es; cierre sin contradicción con los cuadres y sin jerga (D68, D72); base de la retención al centavo (D71); plantilla con doctype y charset (D70), columnas clave visibles, sin columnas de decisión vacías, avisos plegables (D73, D75), MUESTRA fuera del DOM (D74) y subtotal sin costos rotulado «sobrestimado» (D76, E2) · **v1.8.4** (20-oct-2026) FBA y comisión **por orden y SKU** (se suman los renglones de la misma orden), con el envío que pagó el comprador × 1.16 restado del FBA antes de comparar (D77, D78); la ficha de parámetros solo se usa si el vendedor la sube, sin buscarla y sin IDs ni jerga interna (D79); ejemplo de flete con fórmula (D80); IVA de la publicidad redondeado por SKU (D81); un Parent «Decidir por Child» no lleva acción de familia y sus variantes entran a las decisiones (D82); el texto de la tabla de cobros dice la banda de precio (D83) · **v1.8.5** (20-oct-2026) nunca se mencionan sistemas, memorias ni guardados internos y el chat termina en la pregunta de guardado (D84); «sin conclusión» se cuenta aparte para FBA y para comisión (D85); la pregunta del nombre aclara que solo agrega «Preparado para» (D86); al FBA también se le resta la envoltura de regalo que pagó el comprador (D87); la banda de la comisión se toma con el precio después de promociones, por confirmar con Amazon (D88); la sección de cobros entrega una tabla de casos por orden con el texto listo para Soporte al Vendedor, también en el CSV (C1); «N de M» se cuenta por orden y SKU (C3) · **v1.8.6** (20-oct-2026) si no hay costos, la skill genera con código el Excel `PAS_Plantilla_Costos_por_Child.xlsx` prellenado con ASIN, SKU, nombre y Parent, con todas las columnas de costo y la fórmula del costo total, y lo ofrece para descargar (cualquier número de SKU) · **v1.8.7** (20-oct-2026) el turno 1 lleva siempre la línea de privacidad y la pregunta «Preparado para», con lista de control (D90); las 3 decisiones van siempre en el orden 1 Proteger · 2 Arreglar · 3 Detener fuga, con etiqueta fija (D89); las ventas sin costo usan V con IVA (D91); la plantilla lleva solo los SKU con venta y toma el ASIN de las hojas SP, SB y SD (D92); el ACOS de Sponsored Products sale del bloque SP (D93); «conciliados» no incluye transferencias al banco (D94); la plantilla crea la carpeta y avisa si F = No y faltan flete y aduana · **v1.8.8** (20-oct-2026) auditoría completa: toda cifra del chat se copia de la página con su rótulo; contribución de productos incluye los renglones «sin venta»; universo de la tabla escrito; titular y cuadre 10 solo FBA; N de transacciones sin transferencias; contradicciones de publicidad de marca, entregable y cuadres 1 a 12 resueltas; la versión vive solo en el título (D96) · **v1.8.9** (21-oct-2026) quinto punto bloqueante del turno 1: pregunta de flete y aduana; plantilla de costos y movimientos sin transferencias desde el turno 1; cierre literal en dos bloques (la frase de no guardado solo después de la respuesta); autoverificación antes de enviar; cuadre 5 con deduplicación cuenta como cuadrado; SKU sin costo con nombre y monto; aviso de flete con ejemplo; solo se reporta lo medido del artefacto; «flete y aduana» en «Qué faltó» · **v1.8.10** (21-oct-2026) montos de SKU sin costo y toda cifra del turno 1 con código y la fórmula completa (D115); porcentajes del chat con 1 decimal (D108); bloque B con dos variantes según el CSV y «costos, flete y aduana» (D109); CSV en el chat solo si falló la descarga o lo pide el vendedor (D111); sin enlace del artefacto (D112); ACOS y TACOS siempre con rótulo (D113); conteo de celdas y medida a 1300 px obligatorios (D114)
>
> **Qué hace:** con 4 reportes de Seller Central y tus costos entrega la contribución por producto y las 3 decisiones que más mueven la utilidad del mes.
> **Entradas:** confirmación de que la tienda es de Amazon México, mes cerrado, 4 reportes originales del mes, costo de producto confirmado (plantilla `PAS_Plantilla_Costos_por_Child.xlsx` o por chat) y el reporte de transacciones del mes anterior.
> **Salida:** un artefacto Profit AI System con el nombre de tu tienda (secciones 10 y 14), las 3 decisiones en el chat y un resumen para guardar (sección 15).
> **Ejemplo de uso:** «Hazme el diagnóstico de rentabilidad de septiembre, Amazon México».
> **Regla:** la skill propone; el vendedor revisa y decide. Nunca modifica nada en Amazon.


Seller Central te da datos. Esta skill te da decisiones.


Funciona **solo en Amazon México** (decisión de Gerardo del 19-oct-2026 a las 10:01). Amazon Estados Unidos va a ser otra skill aparte. Las reglas de impuestos son las vigentes de México y se aplican solas.


**Esta skill no trae datos de ninguna tienda.** Todo número sale de los archivos que sube la persona; la plantilla de la sección 14 llega vacía.


**Determinismo (regla nueva v1.3):** con los mismos archivos, dos corridas tienen que dar **los mismos números al centavo**. Por eso cada cifra sale de **una sola fuente y una sola fórmula** (sección 3). Si algo no se puede calcular con esas fórmulas, **se detiene ese cálculo y se pregunta**; nunca se elige otra fuente «porque parece mejor».


**Nunca busques archivos por tu cuenta** (Drive, correo, conectores, otras conversaciones), **tampoco la ficha de parámetros fiscales** (v1.8.4, D79). Solo se usan los archivos que el vendedor sube o pega en esta conversación. Esta regla manda sobre cualquier otra sección. **Nombres que el vendedor no escribió (v1.8.9):** en el chat solo se nombran los archivos que subió el vendedor y lo que dice esta skill. Ningún nombre propio de sistema, proyecto, archivo interno o lugar de almacenamiento que venga de tu contexto (instrucciones de la cuenta, memoria, proyectos) aparece en el chat, en el resumen ni en el artefacto. La única excepción es el texto fijo de privacidad de la sección 0. El cierre es el bloque literal de la sección 15, sin agregarle nada.


---


## 0. El primer mensaje — se sigue al pie de la letra


Se le entrega a alguien que **no vio ningún video**. El primer mensaje tiene que funcionar solo.


### Lista de control del turno 1 — obligatoria, pase lo que pase (v1.8.7, D90)


Tu **primera respuesta** en la conversación lleva siempre estas cinco cosas, **aunque el vendedor ya haya subido todos los archivos, los costos, o haya contestado algo por adelantado**. Antes de enviar el turno 1, revisa la lista; si falta una, agrégala:


- [ ] **1. La línea de privacidad, textual y al inicio** (la de «Lo primero, textual», abajo), palabra por palabra.
- [ ] **2. Pregunta 1 (tienda de Amazon México) y pregunta 2 (mes cerrado)**, salvo que el vendedor ya lo haya dicho por escrito; en ese caso se confirma en una línea: «Tomo Amazon México, <mes> (1 al <último día>).»
- [ ] **3. La pregunta «Preparado para», textual** (pregunta 3, abajo). Es opcional **para el vendedor**, pero **hacerla es obligatorio**. Solo se omite si el vendedor ya dio el nombre o ya dijo que no lo quiere en esta conversación.
- [ ] **4. La lista de archivos**, o, si ya llegaron, la lista con lo que llegó y lo que falta.
- [ ] **5. La pregunta de flete y aduana, textual (v1.8.9, bloqueante)**, siempre que **no** hayan llegado costos, o que llegaron pero la columna F («¿Ese costo ya incluye flete y aduana…?») esté vacía en alguna fila, o que el vendedor no haya dicho por escrito si su costo incluye flete y aduana:
  > «¿El costo que me das ya incluye todo lo que te cuesta tener el producto en la bodega, o el flete y la aduana van aparte?»
  Solo se omite si **todas** las filas traen «Sí» o «No» en F, o si el vendedor ya lo contestó por escrito en esta conversación. **Sin este punto el turno 1 no se envía** y no se calcula nada. Que el vendedor lo conteste después por su cuenta no lo reemplaza.


**Además, en el turno 1, si ya llegó el reporte 1 (v1.8.9):**
- Si dices cuántos movimientos trae, **N = filas del reporte 1 sin las transferencias** (la misma regla que la línea de cierre, sección 5); nunca el total de filas.
- **Si no llegaron costos:** la plantilla de costos prellenada se **genera y se entrega en este mismo turno 1** (sección «Plantilla de costos prellenada»), antes de calcular; nunca «en el siguiente paso».
- **Si llegaron costos y algún SKU con ventas no tiene costo:** se lista cada uno con **nombre y monto (V con IVA)**, uno por renglón, nunca solo el código o un total. **El monto se calcula con código y con la fórmula de V de la sección 3.2 completa (v1.8.10, D115):** filas Pedido, `ventas de productos` + `créditos de envío` + `créditos por envoltura de regalo` + `descuentos promocionales`, cada uno con su columna de impuesto. Es el mismo número que tendrá la tabla. **Nunca solo `ventas de productos` + su impuesto.** Debajo va **el total y su porcentaje** (Σ V de los SKU sin costo ÷ Σ V de todos los SKU, con 1 decimal), y **antes de enviar se comprueba con código que la suma de los renglones = el total**. Si no puedes correr código en este turno o la suma no coincide, **no das montos**: listas solo nombre y código y escribes «te los doy en el diagnóstico».
- **Toda otra cifra del turno 1** (porcentaje de ventas sin costo, totales de ventas, de publicidad o de cualquier otra cosa) sigue la regla «Cifras fuera de la página» de la sección 13: con código, con la fórmula de la sección 3 y en el formato de la página, o no se da.
Si llegaron archivos en el primer mensaje, **no se empieza el diagnóstico** en ese turno sin las preguntas (sí se leen los archivos, con código: movimientos sin transferencias, plantilla de costos y montos de SKU sin costo con la fórmula de la sección 3.2; v1.8.10, D115): el turno 1 es la línea de privacidad + las preguntas (incluida la de flete y aduana, punto 5) + qué llegó + la plantilla de costos si no llegaron costos. El cálculo empieza cuando contesta (o cuando dice «sigue»).


### Lo primero, textual


> **Esto corre en tu propia cuenta de Claude. Ni Summa ni Gerardo ven tus reportes. Claude los procesa según la configuración de privacidad de tu cuenta. Antes de subirlos, borra los datos de tus compradores.**


### Luego, tres preguntas (la 3 es opcional) y la lista completa de lo que vas a necesitar


**Pregunta 1 — la tienda:**


> **Esta herramienta es para Amazon México.** ¿Tu tienda es de Amazon México? (Si vendes en Amazon Estados Unidos, esa tienda va en otra herramienta.)


**Pregunta 2 — el periodo:**


> **¿Qué mes quieres analizar?** Tiene que ser un **mes calendario completo y ya cerrado**. Por ejemplo: septiembre 2026, del 1 al 30.


**Pregunta 3 (opcional) — tu marca:**


> **¿Quieres que tu reporte diga «Preparado para» con el nombre de tu tienda o marca?** Es opcional. Si me lo das, aparece como «Preparado para: <nombre>».


(v1.8.7, D90: esta pregunta va **siempre en el turno 1**, con este texto, también cuando el vendedor llega con costos o con todos los archivos.)


(v1.8.5, D86, decisión de Gerardo del 20-oct-2026: la pregunta es solo sobre el nombre de la tienda o marca del cliente, que va en «Preparado para». **«Profit AI System» y «por Gerardo Villa» van siempre en el artefacto y nunca se quitan**; la pregunta nunca promete quitarlos ni dejar el reporte «sin nombre». El pie lleva un bloque de contacto para dudas: correo cursos@summaproducts.com. WhatsApp: todavía no hay número, así que esa línea no se muestra; nunca se pone un número de relleno.)


**Ya no se pregunta cómo se paga la publicidad** (v1.7, decisión de Gerardo del 19-oct-2026 a las 10:01: «cero importante»). La publicidad de la rentabilidad sale siempre del archivo de Ads × 1.16, se pague como se pague.


**En el mismo mensaje, la lista completa (textual):**


> **Para darte el diagnóstico completo voy a necesitar esto, todo del mismo mes cerrado:**
> 1. **Transacciones (CSV)** — Pagos › Reports Repository › Rango de fechas › tipo **Transacción**. *Obligatorio.*
> 2. **Business Report por Child** — Business Reports › Ventas y tráfico por página de detalle (Child).
> 3. **Bulk de publicidad (.xlsx)** — Publicidad › Operaciones masivas, con el rango del mes.
> 4. **Fee Preview** — Logística de Amazon › Pagos › Vista previa de comisiones.
> 5. **Tus costos por producto** — la plantilla `PAS_Plantilla_Costos_por_Child.xlsx` llena (viene en el kit). Si no la tienes, en cuanto subas el reporte 1 te genero el Excel con tus productos ya puestos para que solo llenes los costos, y te lo doy para descargar.
> 6. **Transacciones del mes anterior (CSV)** — mismo lugar que el 1. Sirve para confirmar el ISR que Amazon cobra en el mes.
>
> Puedes subirlos todos juntos o de uno en uno. Si te falta alguno (menos el 1), igual corre y te digo qué se pierde.


- **Mes cerrado.** El mes en curso no sirve: las liquidaciones no terminan. Si pide el mes en curso, se ofrece el anterior.
- **Mes calendario completo.** Nada de «últimos 30 días». Los cargos globales (ISR en México, suscripción, almacenamiento) se cobran por mes calendario.
- El mes elegido **se repite de vuelta** para confirmarlo, y es el mismo rango para los reportes 1, 2 y 3.


**No se calcula nada hasta que las preguntas 1 y 2 estén contestadas y el reporte 1 haya llegado.**


**Los tres errores que se nombran antes de que ocurran:**


- **No uses el botón *Download* de Transaction View.** Está topado a 600 transacciones y **corta los datos sin avisar**.
- **No es el reporte *Summary*.** Trae totales, no movimientos. Es **tipo Transacción**.
- **Bórrale las columnas con datos de tus compradores** antes de subirlo (nombre, dirección, ciudad, estado, código postal, correo, teléfono). Si llegan, **no se leen, no se copian a ningún entregable, y se avisa.**


Al llegar cada archivo se confirma tienda y rango. Si no coincide con lo dicho, **se avisa antes de calcular** — no se corrige en silencio.


### Los costos: se piden antes de calcular, una vez y con insistencia


Cuando llegue el reporte 1 y **antes de calcular**, si no llegaron los costos:


1. Se lista el universo de SKU detectado (sección 5, join externo).
2. **Siempre que no haya costos (v1.8.6, cualquier número de SKU): se genera el Excel prellenado y se ofrece para descargar** (ver «Plantilla de costos prellenada», abajo). Con **15 SKU o menos**, además se ofrece darlos en el chat, producto por producto, con la lista.
3. **Nunca una plantilla vacía, y nunca solo mencionarla o «adjuntarla» sin haberla generado:** el archivo se crea con código en esta conversación, se vuelve a abrir para comprobar filas y fórmula, y se da el enlace de descarga.
4. Se hace la pregunta obligatoria de flete y aduana (punto 5 de la lista de control del turno 1), en el mismo mensaje que la plantilla.
5. Si dice que no tiene costos, se corre sin ellos con el aviso de la sección 1. No se vuelve a preguntar.


### Plantilla de costos prellenada — se genera con código (v1.8.6)


**Cuándo:** en la primera corrida, cuando llegó el reporte 1 y **no** llegaron costos (ni plantilla llena ni costos en el chat). **Antes de calcular.**


**Qué lleva** (igual que la plantilla del kit, hoja «Costos por Child»):
- **Universo de la plantilla (v1.8.7, D92): una fila por SKU con renglón `Pedido` en el reporte de transacciones del mes** (los SKU que vendieron). **No** se agregan filas por SKU que solo aparecen en el archivo de Ads o en el Business Report: esos se listan **aparte en el chat**, como «SKU que solo aparecen en anuncios (sin pedidos en el mes)», con su hoja (SP, SB o SD) y su ASIN. Este universo es solo para la plantilla; el join externo de la sección 5 no cambia.
- Cada fila lleva:
  - ASIN Child: se busca en **las tres hojas de anuncios del bulk** — `Sponsored Products Campaigns` y `Sponsored Display Campaigns` (filas `Product Ad`, columnas `SKU` y `ASIN (Informational only)`) y las de Sponsored Brands (`Creative ASINs`, para confirmar) —, luego en el Fee Preview y el Business Report. **Nunca se lee solo la hoja de SP.**
  - **No se dice que un SKU «no tiene anuncio»** si aparece en cualquiera de las hojas de anuncios (SP, SB o SD); se dice en cuál. Si no aparece en ninguna, se dice «no lo encontré en el archivo de Ads».
  - SKU;
  - nombre (la `descripción` del reporte 1, o el título del Fee Preview);
  - ASIN Parent, si se sabe (Business Report o Fee Preview).
  - Lo que no se sabe se deja vacío: **no se inventa**.
- **Todas las columnas de costo vacías, en durazno, para que las llene el vendedor:**
  - costo unitario;
  - «¿Ese costo ya incluye flete y aduana hasta tu bodega?» (lista Sí/No);
  - flete por unidad;
  - aduana e impuestos de importación por unidad;
  - otros costos por unidad (empaque, etiquetado, prep);
  - «Agrupar con»;
  - notas.
- **Costo total por unidad con fórmula** en cada fila: `=IF(E="","",E+IF(F="Sí",0,N(G)+N(H))+N(I))`.
- Encabezado con tienda, mes y moneda, la marca «PROFIT AI SYSTEM» y la firma «por Gerardo Villa».


**Cómo:** con este código (Python, herramienta de análisis o de archivos), sin cambiar columnas ni orden. Primero `universo_plantilla()` arma las filas y la lista aparte; luego `plantilla_costos()` escribe el Excel:


~~~python
# Plantilla de costos prellenada (v1.8.6; v1.8.7: universo D92, carpeta y aviso F = No)
# skus = lista de dicts {asin, sku, nombre, parent}; si no se sabe, se deja vacío: nunca se inventa
import os
import pandas as pd
def universo_plantilla(txn, bulk):
    """txn: DataFrame del reporte 1; bulk: ruta del .xlsx de Ads. Devuelve (skus, solo_ads)."""
    p = txn[txn["tipo"] == "Pedido"]
    nombres = p.dropna(subset=["sku"]).groupby("sku")["descripción"].first()
    asin, hoja = {}, {}
    xl = pd.ExcelFile(bulk)
    for h, et in (("Sponsored Products Campaigns", "SP"), ("Sponsored Display Campaigns", "SD")):
        if h not in xl.sheet_names: continue
        d = pd.read_excel(xl, h, dtype=str)
        d = d[d["Entity"] == "Product Ad"]
        for _, r in d.iterrows():
            if pd.notna(r.get("SKU")):
                if pd.notna(r.get("ASIN (Informational only)")): asin.setdefault(r["SKU"], r["ASIN (Informational only)"])
                hoja.setdefault(r["SKU"], set()).add(et)
    skus = [{"sku": k, "asin": asin.get(k), "nombre": nombres[k], "parent": None} for k in nombres.index]
    solo_ads = [{"sku": k, "asin": asin.get(k), "hojas": sorted(hoja[k])} for k in sorted(set(hoja) - set(nombres.index))]
    return skus, solo_ads
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.formatting.rule import FormulaRule
NEGRO, NAR, DUR, GRIS = "FF0A0A0A", "FFFF6B00", "FFFFF1E5", "FFF2F2F2"
MON = '\\$#,##0.00;[RED]"-$"#,##0.00;\\-'
COLS = ["ASIN (Child)", "SKU", "Nombre del producto", "ASIN Parent (opcional)", "Costo unitario del producto",
        "¿Ese costo ya incluye flete y aduana hasta tu bodega?", "Flete por unidad",
        "Aduana e impuestos de importación por unidad", "Otros costos por unidad (empaque, etiquetado, prep)",
        "Costo total por unidad (se calcula solo)", "Agrupar con (opcional)", "Notas"]
def plantilla_costos(skus, tienda, mes, moneda="MXN", ruta="/mnt/user-data/outputs/PAS_Plantilla_Costos_por_Child.xlsx"):
    wb = openpyxl.Workbook(); ins = wb.active; ins.title = "Instrucciones"
    for i, t in enumerate(["PROFIT AI SYSTEM", "Cómo llenar la plantilla de costos · Diagnóstico de Rentabilidad Amazon · por Gerardo Villa",
        "Llena solo las celdas color durazno: costo unitario; si el costo NO incluye flete y aduana, escribe «No» y llena flete y aduana por unidad; otros costos por pieza si hay.",
        "El costo total por unidad se calcula solo. Un producto sin costo se queda vacío: no se inventa.",
        "Si escribes «No» en la columna F, llena flete y aduana: si quedan vacías, se pintan de rojo como aviso.",
        "Si no sabes si tu costo incluye flete y aduana, deja F vacía y pregúntalo en la conversación.",
        "Al terminar, sube este mismo archivo en la conversación."], 1):
        ins.cell(i, 1, t).font = Font(bold=(i == 1), color=NAR if i == 1 else "FF000000")
    ws = wb.create_sheet("Costos por Child")
    ws["A1"] = "PROFIT AI SYSTEM"; ws["A2"] = "Plantilla de costos por Child · Diagnóstico de Rentabilidad Amazon · por Gerardo Villa"
    ws["A3"] = "Llena solo las celdas color durazno. Una fila por Child (ASIN o SKU). No cambies los encabezados."
    for c, v in (("A5", "Tienda"), ("B5", tienda), ("D5", "Mes cerrado"), ("E5", mes), ("G5", "Moneda"), ("H5", moneda)):
        ws[c] = v
    ws["A6"] = "Qué llenar: costo unitario. Flete, aduana y otros solo si no están ya dentro del costo."
    for j, h in enumerate(COLS, 1):
        c = ws.cell(7, j, h); c.font = Font(bold=True, color=NAR); c.fill = PatternFill("solid", fgColor=NEGRO)
        c.alignment = Alignment(wrap_text=True, vertical="top")
    ws["A1"].font = Font(bold=True, color=NAR, size=14)
    fin = 7 + max(len(skus), 1)
    for i, s in enumerate(skus):
        r = 8 + i
        ws.cell(r, 1, s.get("asin") or None); ws.cell(r, 2, s.get("sku") or None)
        ws.cell(r, 3, s.get("nombre") or None); ws.cell(r, 4, s.get("parent") or None)
        for j in (5, 6, 7, 8, 9, 11, 12):                       # celdas para llenar (durazno), vacías
            ws.cell(r, j).fill = PatternFill("solid", fgColor=DUR); ws.cell(r, j).font = Font(color="FF0000FF")
        for j in (5, 7, 8, 9):
            ws.cell(r, j).number_format = MON
        t = ws.cell(r, 10, f'=IF(E{r}="","",E{r}+IF(F{r}="Sí",0,N(G{r})+N(H{r}))+N(I{r}))')
        t.fill = PatternFill("solid", fgColor=GRIS); t.font = Font(bold=True); t.number_format = MON
    dv = DataValidation(type="list", formula1='"Sí,No"', allow_blank=True, showErrorMessage=True,
                        errorTitle="Elige Sí o No", error="Escribe Sí o No."); ws.add_data_validation(dv); dv.add(f"F8:F{fin}")
    for col, w in zip("ABCDEFGHIJKL", (16, 14, 42, 16, 17, 22, 15, 17, 18, 18, 24, 34)):
        ws.column_dimensions[col].width = w
    ws.freeze_panes = "D8"; wb.active = 1
    ws.conditional_formatting.add(f"G8:H{fin}", FormulaRule(formula=['AND($F8="No",$G8="",$H8="")'],
                                  fill=PatternFill("solid", fgColor="FFFFC7CE", bgColor="FFFFC7CE")))   # aviso F = No sin flete ni aduana
    os.makedirs(os.path.dirname(ruta) or ".", exist_ok=True)                                            # v1.8.7: la carpeta puede no existir
    wb.save(ruta); return ruta
~~~


**Entrega:**
1. Se vuelve a abrir el archivo y se comprueba que trae una fila por SKU con pedidos y la fórmula en la columna J.
2. Se ofrece en el chat: *«Te preparé el Excel con tus N productos ya puestos (`PAS_Plantilla_Costos_por_Child.xlsx`). Descárgalo, llena solo las celdas color durazno (costo unitario y, si importas, flete y aduana por unidad) y súbelo aquí. Si prefieres, también puedes darme los costos en el chat.»*
3. Si el entorno no deja crear o descargar archivos, se dice así: «No pude generar el archivo para descargar en esta conversación». Se dan las mismas columnas como tabla para copiar y **no se dice que se adjuntó**.


En el mismo mensaje, si `solo_ads` no está vacío: «Estos SKU solo aparecen en tus anuncios, sin pedidos en el mes; no los puse en el Excel: <SKU (hoja, ASIN)>». Si un SKU de la plantilla quedó sin ASIN: «No encontré el ASIN de <SKU> en el archivo de Ads (SP, SB y SD); si lo sabes, ponlo en la columna A».


Si el vendedor sube la plantilla llena, se lee la hoja «Costos por Child». Si la columna J viene vacía (por ejemplo, abierta sin recalcular), se calcula con la misma suma y se dice. **Si una fila dice «No» en F y no trae flete ni aduana (v1.8.7), se avisa antes de calcular:** «En <SKU> dice que el costo no incluye flete y aduana, pero esas celdas están vacías. ¿Las agrego o tomo solo el costo unitario?»


### Si el vendedor llega sin contexto


Si escribe «hola» o cualquier cosa que no sea un archivo: **tres líneas** —qué hace, qué necesita, qué recibe— y **en el mismo mensaje, debajo, el primer mensaje completo** de esta sección (frase de privacidad, preguntas 1 y 2, la 3 opcional, la lista de 6 archivos y los tres errores; desde v1.7 **no** se pregunta cómo se paga la publicidad). Es lo único que se responde; **nunca se devuelve un manual** ni otras explicaciones.


---


## Las cinco reglas que no se rompen


**1. Ningún número se inventa.** Si un dato no está en un archivo del vendedor, se pide. Si no se puede saber, se dice y por qué. **Tampoco se usan tarifas de comisión o FBA «de memoria»:** la referencia sale del Fee Preview o de los propios datos del mes (sección 4).


**2. El reporte detecta, el sistema corrige.** Se puede probar que hay una fuga y cuánto mueve. **No** se puede saber qué campaña, término o parte del listing es responsable. Cada hallazgo es **ALERTA** u **OPORTUNIDAD** con su cifra, nunca una orden que el dato no sostiene.


**3. Nunca se detiene por un archivo opcional.** Si falta un archivo opcional o un costo, se entrega lo que sí se puede y se dice en grande qué falta y qué se pierde.


**4. Nunca se promete dinero.** Los cobros por validar son **posibles diferencias**. Amazon decide.


**5. Una sola fuente y una sola fórmula por cifra (sección 3).** Mismos archivos = mismos números al centavo.


---


## 1. Lo que se le pide


| # | Archivo | Dónde sacarlo | Para qué sirve |
|---|---|---|---|
| 1 | **Rango de fechas · tipo Transacción** (CSV) | Pagos › Reports Repository | Ventas, comisión, FBA, devoluciones, impuestos y cargos de cuenta. Es el corazón. **Obligatorio** |
| 2 | **Ventas y tráfico por página de detalle (child)** | Business Reports | Sesiones, unidades y Parent ASIN → conversión y agrupación |
| 3 | **Bulk de Publicidad** (.xlsx) | Publicidad › Operaciones masivas | **Única fuente** del gasto de publicidad por SKU |
| 4 | **Vista previa de comisiones / Fee Preview** | Logística de Amazon › Pagos | Nombres, ASIN, SKU y tarifa vigente de referencia |
| 5 | **Costos** (plantilla o chat) | El vendedor | Costo de producto y retorno sobre costo |
| 6 | **Transacciones del mes anterior** | Pagos › Reports Repository | Confirmar el ISR cobrado en el mes |


Mismo mes completo y cerrado en 1, 2 y 3.


### Los costos — se preguntan, nunca se estiman


- La plantilla se llena **por Child, por ASIN o por SKU**, se sube y se cruza con el universo de SKU. Un Child sin costo se lista con **nombre y monto, uno por renglón** (en el turno 1 si ya se sabe, en el chat del diagnóstico y en el resumen; v1.8.9): **no se le inventa costo.** **El monto es su V con IVA** (sección 3.2: ventas de productos + créditos de envío + envoltura de regalo + descuentos promocionales, cada uno con su impuesto) y **el porcentaje es Σ V de los SKU sin costo ÷ Σ V de todos los SKU** (v1.8.7, D91). Nunca solo «ventas de productos» más su impuesto. **El denominador nunca es** el total del reporte 1, las liquidaciones ni conciliados más transferencias (v1.8.9): siempre Σ V de la tabla, copiado de la página (en el turno 1, antes de la página, calculado con código con la misma fórmula; sección 13, «Cifras fuera de la página»), con 1 decimal. La misma base en el chat, en la tabla de SKU sin costo y en el resumen.
- **Costo total por unidad** = costo unitario + flete + aduana + otros (columna «Costo total por unidad» de la plantilla; si viene vacía, se calcula con esa suma y se dice).
- **Kits y paquetes:** si el vendedor da el costo del kit, se usa ese. Si dice que el kit es la suma de componentes, se suma lo que él dio. Nunca se arma un costo que él no dio.


**Pregunta obligatoria antes de calcular:**


> «¿El costo que me das ya incluye todo lo que te cuesta tener el producto en la bodega, o el flete y la aduana van aparte?»


- **Ya puesto en bodega** → flete y aduana en **cero por definición**. **Queda prohibido volver a insinuar que faltan** o que los márgenes están inflados. Se escribe: *«el costo unitario es el costo real del producto puesto en tu bodega, confirmado por ti»*.
- **Flete y aduana aparte** → se piden; si no los tiene, se corre con aviso de márgenes inflados y ejemplo numérico. **El aviso del artefacto (`DATA.avisos`) lleva el mismo ejemplo que el chat (v1.8.9):** «Si flete y aduana suman ~20% del costo, el retorno de <producto real de la tabla> baja de <r>% a ~<(r − 0.20) ÷ 1.20>% (fórmula (r − 0.20) ÷ 1.20). Dame flete y aduana por unidad y lo corro completo.» El número se calcula, no se estima.


**Si no da costos (o falta el de algún producto con venta):** se corre igual (cobros, publicidad, cargos, devoluciones no dependen de costos). **La plantilla pone sola** el aviso grande arriba de la tabla y marca la contribución del canal «INCOMPLETA: falta el costo de N productos (sobrestimada)»; en el chat se repite este aviso:


> **Sin tus costos no puedo decirte cuánto deja cada producto realmente.** Te falta el retorno sobre costo, que dice si un producto vale la pena crecerlo o arreglarlo antes. Dame el costo unitario y lo corro completo.


### Opcional


- **Inventario FBA** — sin esto no hay rotación ni cobertura. **No se estiman con las unidades del mes.**


---


## 2. Confirmar la tienda antes de calcular


Del reporte 1: columna `marketplace` y moneda. Tienen que ser Amazon México y MXN. Si el reporte es de otra tienda (por ejemplo, Amazon Estados Unidos), **se detiene**: esta skill es solo para Amazon México. **Respaldo (v1.7.1, D59):** si aun así `DATA.moneda` no es `'MXN'`, la plantilla se detiene sola, no calcula nada y lo dice.


| Tienda | Impuesto en la venta | Base de la comisión por referencia | Retenciones |
|---|---|---|---|
| **México** | IVA 16% incluido (8% solo con el estímulo de región fronteriza, confirmado por el vendedor; ver abajo). **Desde v1.6 todo se calcula con IVA** (sección 2) | Precio total de venta **con** IVA | Retención de IVA: 50% del IVA cobrado = 8.0% de la venta sin IVA (LIVA art. 18-J, fr. II, inciso a); 4.0% en región fronteriza) · ISR: tasa según la fecha de la venta (tabla de tasas de ISR, abajo) |








### Parámetros fiscales y de marketplaces — de dónde salen (v1.8.1; corregido en v1.8.4, D79)


> Los valores fiscales y de Amazon México que usa la plantilla están documentados en la tabla de abajo, con su fuente. Existe además una ficha de parámetros fiscales, con fecha de revisión, que el dueño de la skill mantiene aparte. **El vendedor normalmente no la tiene, y no hace falta.**


**Cómo los usa la skill (v1.8.4, D79):**
1. **La ficha solo se usa si el vendedor la sube o la pega en esta conversación.** **Nunca se busca** en Drive, correo ni ningún conector, aunque estén conectados (regla «Nunca busques archivos por tu cuenta», arriba).
2. Si la subió: se lee su bloque `json` y se comparan sus valores con los de la tabla. **Si alguno es distinto, se detiene y se avisa**: la plantilla trae esos valores fijos y cambiarlos pide una versión nueva. Ningún número se cambia por cuenta propia. Si la ficha trae un valor vacío (`null`), se usa el de la tabla **sin comentarlo**.
3. **Si no la subió (lo normal)**, se usan los valores de la tabla y se escribe así, textual, en el cierre del chat y en el «Resumen para guardar»: **«Parámetros fiscales: valores vigentes documentados en la skill (revisados al 19-oct-2026).»**
4. Si la subió y coincide: «Parámetros fiscales: los de la ficha que subiste, versión <versión>, revisión <fecha>; coinciden con los de la skill.»
5. **Con el vendedor no se habla de estados internos de la ficha** («pendiente», «validación del contador», versiones internas): el IVA de la factura de Ads se dice como «16% (la factura de Amazon Ads lleva IVA)», sin más.


| Parámetro | Valor vigente documentado en la skill | Dónde está la fuente en esta skill | Clave en el bloque `json` de la ficha (si el vendedor la sube) |
|---|---|---|---|
| IVA de la venta | 16% (8% solo con región fronteriza confirmada) | §2, «Reglas de México» y «Región fronteriza» | `ivaVenta: 0.16`. Región fronteriza: no está en la ficha |
| Retención de IVA | 50% del IVA cobrado = 8% de la venta sin IVA (4% en región fronteriza; ~16% sin RFC) | §2, «Tasas de ISR» (chequeo de la retención) | `fraccionRetencionIVA: 0.5` |
| ISR de plataformas | 2.5% de la venta sin IVA (ventas de 2026); 2025: no está en la skill (ISR de enero 2026 POR CONFIRMAR) | §2, «Tasas de ISR» | `isrPorAnio: {"2025": null, "2026": 0.025}` |
| IVA de la factura de Amazon Ads | 16% (la plantilla multiplica el gasto del bulk × 1.16) | §2 y §3.3 | `ivaAdsFactura` |
| Comisión por referencia | ~14.6%–15.0% con IVA, solo como referencia | §2 y §4 | no está en la ficha |
| Semáforo (retorno sobre costo) | 20% / 45% / 70% / 100% / 150% | §7 | `semaforoLimites` |
| TACOS de Sponsored Products de publicidad limitada | 5% | §7 | `tacosUmbral: 0.05` |
| ACOS | gasto y ventas con ads, los dos con IVA (igual que la consola) | §2 | `acosBase: "misma_base"` |


### Reglas de México — una sola base: todo con IVA (v1.6, regla D3)


> **Fuente de la regla (D3):** decisión de Gerardo Villa, del 19-oct-2026. **v1.8.1 (decisión de Gerardo, 19-oct-2026):** esta regla vive en esta skill; los valores fiscales son los de la tabla de la sección anterior (la ficha solo cuenta si el vendedor la sube).


**La regla, en cuatro puntos (resumen):**
1. **Todo se calcula con IVA incluido.** Las ventas cuentan con su IVA como ingreso; la comisión, el FBA, los anuncios y cualquier otro cargo cuentan con su IVA como gasto. «Todo lo que tenga IVA tiene que estar ahí puesto, en todos lados.»
2. **Aparte se resta la retención de IVA del 8%.**
3. La comisión es de alrededor de **12.9% (o 12.6%) más IVA**, cerca del **15% con IVA**. **Es una referencia, no una tasa:** la skill usa siempre lo que viene en el reporte (sección 4).
4. **El ISR se calcula y se resta por producto** en el reporte de rentabilidad (para ver lo que deja de verdad cada producto, aunque Amazon lo descuente después). **La caja del mes**, con lo que Amazon realmente cobró, va **aparte** (sección 11).


| Concepto | Cómo entra (MX) |
|---|---|
| Ventas (V) | Lo que pagó el comprador, **con IVA** |
| Comisión (C) y FBA (F) | **Tal cual el reporte, con IVA.** No se divide entre 1.16 |
| Publicidad (PUB, SP no asignable, SB/SD) | El bulk trae el gasto **sin IVA** y **así se pone en `DATA`** (v1.6.1, D41). **La plantilla** lo multiplica × 1.16 (tasa de la factura de Amazon Ads, también en región fronteriza; v1.6.2, D43) por SKU y por renglón, redondeado a centavos. Es la única conversión de la cadena y ya no depende de Claude |
| Cargos de cuenta | Tal cual el reporte (con IVA) |
| Retención de IVA 8% (IVA) | Renglón aparte por producto: lo que Amazon retuvo, tal cual el reporte. En este reporte se trata como **salida de dinero**, según la regla de Gerardo |
| ISR devengado (ISR) | Renglón aparte por producto (tabla de tasas, abajo) |


| Porcentaje | Fórmula única |
|---|---|
| Comisión por referencia % | **Comisión con IVA ÷ Ventas con IVA** (misma base; con la referencia de Gerardo debería rondar 14.6%–15.0%, ver sección 4) |
| Retención de IVA % (chequeo) | Retención de IVA ÷ (Ventas ÷ (1 + tasa de IVA)) → debe dar 8.0% (entre 7.9% y 8.1%); 4.0% en región fronteriza confirmada. **La plantilla lo revisa sola** (v1.6.1). **La retención es la real del reporte** (columna `impuesto de retenciones en la plataforma`), no el 8% calculado: por eso puede salir unos pesos distinta de una cuenta hecha con 8% exacto o con otra base de ventas (por ejemplo, por fecha de pedido) (v1.8.3) |
| ISR % (chequeo) | ISR cobrado ÷ (Ventas del mes anterior ÷ 1.16) → debe dar la tasa de la tabla de ISR para el mes anterior (± 0.1 puntos) |
| ACOS | **Misma base (regla de Gerardo del 20-oct-2026, reemplaza la del 19-oct):** (gasto SP × 1.16) ÷ (ventas con ads × 1.16). El IVA va **al gasto y a las ventas con ads, y solo a esos dos**; por eso el ACOS es **igual al de la consola de Ads**. Lo hace la plantilla. Además se da el **ACOS total de la cuenta** = (SP + SB + SD) ÷ (ventas con ads SP + SB + SD), misma base, en el bloque de publicidad de marca | **Etiquetas (v1.8.7, D93):** el «ACOS de Sponsored Products» es (gasto SP × 1.16) ÷ (ventas con ads **de SP** × 1.16), con el gasto SP total y las ventas de las filas `Ad group` de la hoja SP. El ACOS de SB/SD (bloque de marca) y el ACOS total de la cuenta se dan con su propio nombre. **Nunca** se pone junto al gasto de SP un ACOS que no sea el de SP. En el chat, si se dan, van así: «Sponsored Products: $<gasto SP con IVA>, ACOS <ACOS SP>» · «Marca (SB/SD): $<gasto>, ACOS <ACOS SB/SD>» · «ACOS total de la cuenta: <ACOS total>». **El TACOS de la tabla también es solo de SP** (publicidad SP con IVA ÷ ventas con IVA) y en el chat se escribe «TACOS de Sponsored Products»; nunca se le suma SB/SD sin decirlo (v1.8.8). Con o sin costos, igual.
| TACOS | Publicidad SP con IVA ÷ Ventas con IVA |
| % final (margen) | Contribución ÷ Ventas con IVA |


**Las únicas divisiones entre (1 + tasa de IVA) que quedan** son las de las **bases de los impuestos** (chequeo de la retención de IVA y base del ISR), porque la ley los calcula sobre la venta sin IVA. No tocan la cadena de contribución. En el texto se escribe «÷ 1.16» por ser el caso general; con región fronteriza confirmada es «÷ 1.08» en **toda** la cadena (sección siguiente).


### Región fronteriza (v1.6.1, D38) — tasa de IVA parametrizada


**Fuente de la tasa:** «Decreto de estímulos fiscales región fronteriza norte» (DOF 31-dic-2018), artículo décimo primero: crédito fiscal equivalente al 50% de la tasa del IVA, que deja una tasa efectiva de **8%** en las operaciones elegibles; y «Decreto de estímulos fiscales región fronteriza sur» (DOF 30-dic-2020). Los dos se prorrogaron **hasta el 31 de diciembre de 2026** por el decreto publicado en el DOF el 31-dic-2025 (sidof.segob.gob.mx/notas/5777697; minisitio del SAT «Estímulos fiscales región fronteriza norte · IVA»). **No es automático:** aplica solo a quien está inscrito en el padrón de beneficiarios del SAT y cumple los requisitos. Para 2027 en adelante: no sé (depende de una nueva prórroga); se pregunta.


**Retención en región fronteriza:** el art. 18-J, fr. II, inciso a) de la LIVA retiene el **50% del IVA cobrado**; con IVA de 8% eso da **4% de la venta sin IVA** (fuente secundaria: calcu.mx, «Plataformas digitales», revisada el 19-oct-2026). Cómo lo aplica Amazon MX en su reporte: no lo sé; se confirma con datos reales.


**Qué hace la skill:**
1. Por omisión, `ivaTasa: 0.16`.
2. **Si el chequeo de la retención da entre 3.9% y 4.1%** (con la base ÷ 1.16), **se detiene y se pregunta**, textual: «Tu retención de IVA da 4% de la venta sin IVA, no 8%. Eso pasa cuando vendes con el IVA de región fronteriza (8%). ¿Vendes con el estímulo de región fronteriza?». La plantilla, si se llega a correr así, también se detiene: aviso grande arriba y canal **POR VALIDAR: ¿región fronteriza?**
3. **Solo si el vendedor confirma**, se pone `ivaTasa: 0.08` y se usa **1.08 en las bases de impuestos del vendedor**: la plantilla revisa la retención contra 4%; **la publicidad sigue × 1.16** (v1.6.2, D43: la factura de Amazon Ads es de Amazon, a la tasa general; el estímulo aplica solo a las ventas del propio vendedor con entrega en la región, según el minisitio del SAT revisado el 19-oct-2026; se confirma con una factura de Ads de un vendedor fronterizo); Claude calcula el ISR devengado con V ÷ 1.08 (la plantilla avisa si la suma no da 2.5% × V ÷ 1.08). Comisión, FBA y cargos siguen tal cual el reporte. Si se quedara en 1.16, el ISR saldría 6.9% más bajo (1 − 1.08 ÷ 1.16).
4. Si contesta que no o no sabe: no se corre a ciegas; se queda POR VALIDAR y se pide su constancia de retenciones.
5. **Ventas mezcladas (v1.6.2, D43):** con FBA, Amazon entrega desde sus almacenes a todo el país, así que una tienda puede tener ventas al 8% y al 16%. Si la retención da **entre 4.1% y 7.9%**, se detiene y se pregunta: «¿Tienes ventas con y sin el estímulo de región fronteriza?». La plantilla también se detiene (aviso grande, canal POR VALIDAR, sin decisiones). Un solo `ivaTasa` por tienda no representa ventas mezcladas: cómo repartirlas no lo sé todavía; queda como pregunta para Gerardo.
6. **Con cualquier alto de la retención (4%, entre 4% y 8%, u otro porcentaje), la plantilla no da decisiones** (v1.6.2, D46): Proteger, Arreglar y Detener fuga dicen «POR VALIDAR» y el cierre en el chat también.
7. **Región fronteriza con P1 (v1.7, D53):** una sola cifra, porque ya no importa cómo se pague la publicidad: CON A 386.79, CON B 505.50, productos 822.69, TOTAL CARGOS −448.00, canal **474.69**, caja **412.47**. (La cuenta «−52.80 = 660 × 0.08» de v1.6.3 —500 de publicidad de productos + 60 no asignable + 100 de marca— comparaba × 1.08 contra × 1.16 con tarjeta; ya no aplica porque la publicidad siempre va × 1.16.)
8. **Bordes del chequeo (v1.6.3, D51; v1.7.1, D55 y D56; v1.8, D60):** cada aviso dice el rango en pesos de **su** franja, calculado con la venta sin IVA: región fronteriza (3.9%–4.1%; en P1 $172.81–$181.67) junto con el de 8% para comparar; mezcla, los dos rangos; otro porcentaje, el rango esperado de la tasa del vendedor y, con la tasa general (16%), también el de región fronteriza (v1.8.1, D61: así se ve aunque la retención quede a un centavo de esa franja; en P1 con 172.80: «fuera del rango esperado con 8.00%, de $350.05 a $358.91; el de región fronteriza, 4.00%, es de $172.81 a $181.67»). Los límites (7.9%–8.1%, 3.9%–4.1%, 4.1%–7.9%) se comparan **en pesos** con medio centavo de tolerancia; eso decide el alto. El porcentaje se muestra **con 2 decimales redondeados** (4% exacto = «4.00%», no «3.9999%») y el aviso dice **siempre el rango en pesos**: por ejemplo, 350.04 sobre 4,431.03 muestra «7.90% … (retención $350.04: entre el rango de región fronteriza, 4.00%, de $172.81 a $181.67, y el de 8.00%, de $350.05 a $358.91)» y se detiene; 350.05 se acepta.
9. **Tasa de IVA no reconocida (v1.6.3, D50):** si `ivaTasa` no es 0.16 ni 0.08, la plantilla no corre las revisiones de retención ni de ISR, avisa que la tasa no es válida, rotula el canal «POR VALIDAR: tasa de IVA no reconocida» y no da decisiones.
10. **Retención de IVA en 0 (v1.7, D48, opción B de Gerardo; decisión de Gerardo del 19-oct-2026 a las 10:01):** la plantilla avisa «No encontré la retención de IVA (debería ser 8% de la venta sin IVA, ≈ $X). ¿Falta la columna?» y marca el canal «POR VALIDAR: no encontré la retención de IVA». Las decisiones se quedan. En P1: ≈ $354.48.


**Ya no existe** el renglón «IVA pagado en comisión y FBA» (IVAtar) ni ninguna columna «sin IVA»: con una sola base no hay IVA que separar.


### Tasas de ISR — se usan solo con su fuente (nuevo en v1.4)


| Ventas de | Tasa que usa la skill | Fuente |
|---|---|---|
| **Vigente** (enero 2026 en adelante), vendedor con RFC registrado en Amazon | **2.5%** de la venta sin IVA | Ley de Ingresos de la Federación 2026, art. 25, fr. VI («aplicarán la tasa del 2.5 por ciento», en sustitución de la tasa del art. 113-A, párrafo tercero, fr. III de la LISR). DOF y PDF oficial: diputados.gob.mx/LeyesBiblio/pdf_mov/Ley_de_Ingresos_2026.pdf |


| Cualquier mes, si el chequeo da **cerca de 20%** | **No se calcula.** Se detiene y se pregunta: «Amazon te está reteniendo cerca de 20% de ISR; eso pasa cuando Amazon no tiene tu RFC. ¿Tu RFC está registrado en tu cuenta?» | LIF 2026 art. 25 fr. VI (20% a personas morales que no proporcionan RFC). Para personas físicas sin RFC: no sé; se pregunta |


**Chequeo de la retención de IVA:** retención ÷ (Ventas ÷ 1.16) debe dar entre 7.9% y 8.1%. Es el **8% de Gerardo** (punto 2 de la regla) y es lo mismo que «50% del IVA cobrado» (16% × 50% = 8%), **LIVA art. 18-J, fr. II, inciso a)** (texto oficial: diputados.gob.mx/LeyesBiblio/pdf/LIVA.pdf; base confirmada el 19-oct-2026). Desde v1.6.1 **la plantilla hace este chequeo**: si da otra cosa, avisa y marca el canal POR VALIDAR. **Si da entre 3.9% y 4.1%:** región fronteriza (arriba). **Si da cerca de 16%** (entre 15.9% y 16.1%), es la retención del **100% del IVA** (16% de la venta sin IVA), que Amazon aplica cuando no tiene el RFC del vendedor, cuando el vendedor reside en el extranjero o cuando los depósitos van a una cuenta bancaria extranjera (fuente secundaria: Deloitte, «Plataformas Digitales», 2025): se detiene y se pregunta la situación fiscal. **Las dos cifras no se contradicen:** 8% es el caso normal (vendedor con RFC) y 100% del IVA es la excepción; la regla de Gerardo no cambia esto. **No se corrige el cálculo por cuenta propia.** Cualquier otro porcentaje: se avisa arriba con el monto y se pregunta.


Si el vendedor tiene una tasa distinta confirmada por su contador, se usa la suya y se escribe de dónde salió.


**ISR — el error que casi todos cometen.** Amazon México lo cobra como **un cargo mensual global, sin SKU y con descripción vacía**, sobre la venta del **mes anterior**. Dos cifras distintas que **nunca se suman**:


- **ISR devengado del mes analizado** — la tasa de la tabla para ese mes, repartida por producto (campo ISR, sección 3). Resta en la contribución por producto. **No salió de la cuenta este mes.**
- **ISR cobrado en el mes** — el cargo global (mes anterior). **Ese sí salió de la cuenta** y es el único que entra al bloque de caja.


> **Efectivo de impuestos del mes = IVA retenido + ISR cobrado.** Restar además el devengado cuenta el impuesto dos veces.


**ISR cobrado en enero 2026 (ventas de diciembre 2025):** queda **POR CONFIRMAR** (decisión de Gerardo del 19-oct-2026 a las 10:20): la skill no trae la tasa de 2025, así que muestra los dos renglones de canal («si el cargo es ISR» y «si no es ISR»).


**Cómo confirmar que un cargo sin descripción es el ISR:** con el reporte 6 (mes anterior), dividirlo entre (Ventas del mes anterior ÷ 1.16). Si da la tasa de la tabla para el mes anterior (± 0.1 puntos; por ejemplo, entre 2.4% y 2.6% para ventas de 2026), es ISR, **no es reclamable** y **vive solo en el bloque de impuestos y en los cargos de cuenta**. Si no llegó el reporte 6, se rotula **«Cargo sin descripción — probablemente ISR del mes anterior, POR CONFIRMAR»**, se pone `isrConfirmado:false` (la plantilla muestra la contribución del canal **con y sin** ese cargo) y se pide el reporte 6. Nunca se da por confirmado sin la división. Si el mes anterior es diciembre 2025 o antes, la división se muestra y el vendedor confirma con su constancia (tabla de tasas). En el renglón de ISR de `cargos` va el cuarto campo `'isr'`.


**Retenciones (v1.6; texto corregido en v1.6.1, D39):** por regla de Gerardo, la retención de IVA del 8% y el ISR se **restan por producto**, cada uno en su propia columna (grupo RETENCIONES), para ver lo que deja de verdad cada producto. **En este reporte se tratan como salida de dinero, según la regla de Gerardo.** Si además se pueden acreditar o no en la declaración depende del régimen del vendedor: la skill no lo afirma ni lo calcula (pregunta abierta para Gerardo).


**Retención de IVA, por producto o en el total:** va **por producto**, porque Amazon la retiene orden por orden y el reporte 1 la trae por SKU (columna `impuesto de retenciones en la plataforma`). El total del canal es la suma de los productos; no se vuelve a restar en los cargos. Se usa **el monto del reporte**, no un 8% calculado. **Base (cerrada en v1.6.1):** la venta **sin** IVA. Fuente: LIVA art. 18-J, fr. II, inciso a), «el 50% del impuesto al valor agregado cobrado»; el 50% de un IVA de 16% es 8% de la venta sin IVA. Ejemplo P1: SKU-A 8% × 2,990.00 ÷ 1.16 = **206.21** (sobre la venta con IVA serían 239.20, y eso es incorrecto). Confirmado con fuente el 19-oct-2026 y por **Gerardo** (19-oct-2026, 9:32 CDMX): «la venta causa 16% de IVA y se retiene la mitad, o sea 8% sobre la venta sin IVA; el ISR se calcula sobre la venta sin IVA». Pregunta cerrada.


### Los tres cobros nunca se mezclan


| Cobro | Qué es | Cómo se valida |
|---|---|---|
| **Comisión por referencia** | Porcentaje por vender | Tasa real del mes vs tasa de referencia (sección 4) |
| **Tarifa FBA** | Logística por unidad | La tarifa más frecuente de ese SKU en el mes |
| **Publicidad** | SP, SB y SD | Cobro del CSV vs gasto del bulk (sección 3.4) |


**Antes de escribir una cifra se verifica de qué campo salió.** Si dos cifras de bloques distintos coinciden casi al peso, es la misma cifra mal etiquetada.






---


## 3. La cadena de contribución — UNA sola fórmula (obligatoria, paso por paso)


Esta sección sustituye a cualquier otra forma de calcular. Se aplica **en este orden**, por SKU, y después se agrupa.


### 3.1 Clasificar filas del reporte 1


Cada fila tiene `tipo` (y `descripción`). Se clasifica en exactamente uno de estos grupos:


| Grupo | Qué filas | A dónde va |
|---|---|---|
| **Pedido** | `tipo` de pedido/venta con SKU | Campos V, C, F, IVA, U y parte de AJ |
| **Reembolso** | `tipo` de reembolso/devolución con SKU | Campo DEV y unidades devueltas |
| **Ajuste con SKU** | ajustes, reembolsos de inventario FBA u otros con SKU | Campo AJ |
| **Cargo de cuenta** | filas sin SKU (servicios, suscripción, almacenamiento, publicidad, ISR, envíos a Amazon, retiros…) | Bloque de cargos de cuenta (sección 10) |
| **Transferencia** | transferencia a banco | Se excluye siempre y se dice |


Un `tipo` o `descripción` que no se sabe clasificar **detiene el cálculo y se pregunta**. Nunca un saco de «otros».


Los nombres exactos de columnas pueden variar por idioma de Seller Central. Si una columna mencionada aquí no existe con ese nombre ni con su equivalente obvio en inglés, **se detiene y se pregunta**; no se sustituye por otra.


### 3.2 Campos por SKU (todos los costos en POSITIVO; montos en centavos)


| Campo | Fórmula única | Fuente |
|---|---|---|
| **U** — unidades de pedido | Σ `cantidad` de filas Pedido | Reporte 1 |
| **Udev** — unidades devueltas | Σ `cantidad` de filas Reembolso | Reporte 1 |
| **Unet** — unidades netas | U − Udev | — |
| **V** — Ventas | Σ en filas Pedido de: `ventas de productos` + `créditos de envío` + `créditos por envoltura de regalo` + `descuentos promocionales` (vienen negativos: se suman tal cual). + sus columnas de impuesto si existen y no están en cero. | Reporte 1 |
| **C** — Comisión (MX con IVA) | −Σ `tarifas de venta` (filas Pedido), **tal cual** (v1.6: sin ÷ 1.16) | Reporte 1 |
| **F** — FBA (MX con IVA) | −Σ `tarifas fba` (filas Pedido), **tal cual** (v1.6: sin ÷ 1.16) | Reporte 1 |
| **IVA** — Retención de IVA 8% | −Σ `impuesto de retenciones en la plataforma` (filas Pedido) | Reporte 1 |
| **ISR** — ISR devengado | tasa ISR del mes analizado (tabla de tasas, sección 2) × (V ÷ 1.16; ÷ 1.08 en región fronteriza confirmada) — la base es la de la ley (venta sin IVA; LISR 113-A), confirmada por Gerardo (19-oct-2026 9:32 CDMX). La plantilla revisa la suma. Si la tasa está POR CONFIRMAR: 0 y aviso | Calculado |
| **DEV** — Devoluciones | −Σ `total` de filas Reembolso del SKU (todo lo que trae la fila: venta reembolsada, comisión devuelta, cargos y retenciones devueltas) | Reporte 1 |
| **AJ** — Ajustes y otros (con signo) | Σ `total` de filas Ajuste con SKU **+** Σ en filas Pedido de las columnas que no entran en V, C, F ni IVA (`tarifas de otras transacciones`, `otro`, tarifas reglamentarias y su impuesto) | Reporte 1 |
| **CP** — Costo de producto | **max(Unet, 0)** × costo total por unidad. Sin costo del vendedor: 0 (la plantilla lo marca SIN COSTO) | Costos del vendedor |
| **PUB** — Publicidad SP | Sección 3.3: gasto del bulk **tal cual, sin IVA**; la plantilla le suma el IVA (v1.6.1) | Reporte 3 |
| **VA** — Ventas con ads SP | Sección 3.3 | Reporte 3 |


**Unidades devueltas:** el costo de producto se calcula con **unidades netas** porque la unidad devuelta regresa al inventario; si Amazon la da por dañada, su reembolso aparece en AJ. Así se dice en la nota del artefacto.


**Unet en cero o negativo** (reembolsos de ventas de meses anteriores sin ventas este mes): CP = 0, el renglón se queda en la tabla con su DEV y su contribución, **sin retorno, sin semáforo y sin acción** (la plantilla lo marca «SIN VENTA NETA») y no entra a las 3 decisiones.


### 3.3 Publicidad — UNA sola fuente: el bulk (reporte 3)


- **Cómo se leen los nombres (nuevo en v1.4):** hojas, columnas y valores de `Entity` se comparan **sin importar mayúsculas ni espacios al inicio o al final**. Equivalencias aceptadas: `Product Ad` = `Product ad`; `Ad Group` = `Ad group`; `Campaign` = `campaign`. Cualquier otro nombre: **se detiene y se pregunta**.
- **Gasto SP por SKU (PUB)** = Σ columna `Spend` de las filas con `Entity` = **`Product ad`** (así lo escribe Amazon) de la hoja **`Sponsored Products Campaigns`**, agrupado por `SKU`. **VA** = Σ `Sales` de esas mismas filas.
- **Gasto SP total (v1.8.3, D69)** = Σ `Spend` de las filas con `Entity` = **`Ad group`** de la misma hoja. Es el nivel que cuadra con los anuncios; el renglón `Campaign` puede venir corto en algunas campañas. El renglón `Campaign` **ya no** es fuente: solo se usa en el cuadre 4, como aviso de calidad del bulk.
- **SP no asignable a SKU** = Gasto SP total (Ad group) − Σ PUB de todos los SKU; normalmente $0. Va como renglón propio en `sin` («Sponsored Products no asignable a SKU»), **aunque valga $0**. Si es mayor a 1% del gasto SP total, se avisa arriba con el monto. **Si sale negativo**, la plantilla no lo suma a la contribución (usa el gasto por anuncio, el mayor) y avisa; en el chat se dice igual.
- **Nunca se suman filas de distintos niveles** (Campaign + Ad Group + Product Ad + Keyword…): eso cuenta el gasto varias veces.
- **Nunca se usa otra fuente de gasto** (consola de Ads, cargos del CSV, Business Report) para la tabla de productos. El cargo de publicidad del CSV solo se usa para el chequeo 3.4.
- **SB** = Σ `Spend` de filas `Entity` = `Campaign` de `Sponsored Brands Campaigns` y `SB Multi Ad Group Campaigns`, **deduplicado por Campaign ID** (una campaña que aparece en las dos hojas se cuenta una vez; decir cuántas se deduplicaron y por cuánto). **SD** = Σ `Spend` de filas `Entity` = `Campaign` de `Sponsored Display Campaigns`. No se asume que una cuenta no tiene SB o SD: se abre el bulk y se revisa.
- Si las hojas o columnas no se llaman así, **se detiene y se pregunta**; no se escoge otra hoja.
- El gasto del bulk es **sin IVA** y **así va a `DATA`** (v1.6.1, D41): PUB por SKU, «SP no asignable», `sb.pub` y `pubAsignada` (= Σ PUB + SP no asignable, sin IVA). **Claude no multiplica nada.** La plantilla multiplica cada renglón × 1.16 (factura de Amazon Ads; `ivaTasa` no la cambia), redondea a centavos y recalcula la publicidad asignada con IVA; si `pubAsignada` no es la suma de los renglones, avisa. Si por error se pone el gasto ya multiplicado y el reporte trae cargo de publicidad, el gasto queda arriba del cargo y el cuadre 11 lo marca. **Las ventas con ads (VA) también van sin IVA, tal cual el bulk; la plantilla les suma el IVA (v1.8.3, E3)** para que el ACOS quede en la misma base.


### 3.4 Chequeo obligatorio: cobro de publicidad vs gasto


> Cobro de publicidad = −Σ filas de cargo de publicidad del CSV, **tal cual** (con IVA; v1.6 ya no lo divide)
> Gasto total Ads = Gasto SP total + SB + SD (con IVA: gasto del bulk × 1.16, lo calcula la plantilla)
> **Diferencia cobro vs gasto** = Cobro − Gasto total Ads (los dos en la misma base)


**Congruencia (cuadre 11; v1.7: solo si el reporte trae cargo de publicidad):** el **Gasto total Ads** (SP + SB + SD) **no puede ser mayor** que el cobro de publicidad (los dos con IVA). Si lo es (por ejemplo, el IVA puesto dos veces), la plantilla lo avisa arriba, pone un renglón rojo en el bloque de cargos y marca la contribución del canal **POR VALIDAR**. En el chat se dice como «Validar antes de actuar» (puede ser un cobro de otro mes, publicidad pagada fuera de Amazon o un error de datos) y nunca se corrige un número para que cuadre. El renglón del cargo de publicidad en `cargos` lleva la etiqueta `'pub'`; si falta, la plantilla lo busca por nombre («publicidad», «advertising», «anuncio») y lo dice.


**La publicidad de la rentabilidad sale siempre del archivo de Ads (v1.7, decisión de Gerardo del 19-oct-2026 a las 10:01):** Sponsored Products ya está restado por producto (bulk × 1.16) y la publicidad de marca (SB/SD) se resta en los cargos de cuenta con el gasto del bulk × 1.16. **El cargo de publicidad del reporte 1 no entra a la contribución**, se pague como se pague; así el canal no se infla cuando el reporte no trae el cargo (por ejemplo, si los Ads se pagan fuera de Amazon). Ese cargo solo sirve para este chequeo, el cuadre 11 y la caja del mes (sección 11), donde sí está porque Amazon lo cobró. **Si no hay cargo de publicidad**, no aplica el cuadre 11 y no hay marca: la contribución sale igual.


**Ya no hay supuesto sobre el IVA de una factura de Ads con tarjeta:** la plantilla nunca usa un cargo de tarjeta; solo el gasto del bulk × 1.16 (factura de Amazon Ads al 16%).


La diferencia se reporta **siempre**, aunque sea $0, como recuadro de revisión en `rev` del artefacto y en el cierre del chat, con la etiqueta **«Validar antes de actuar»**. Una diferencia distinta de cero puede venir de cobros de otro mes o de impuestos; **no** se afirma que sea sobrecobro.


### 3.5 La cadena (por SKU, en este orden)


~~~
UB  (Util. bruta)            = V − C − F − CP
UT  (Util. tras publicidad)  = UB − PUB
CON (Contribución producto)  = UT − DEV + AJ − IVA − ISR        (todo con IVA; IVA = retención 8%, 4% en región fronteriza confirmada)
Comisión %                   = C ÷ V
Retorno sobre costo          = CON ÷ CP     (solo si CP > 0, V > 0 y Unet > 0; si no, vacío)
Contribución por unidad neta = CON ÷ Unet   (solo si Unet > 0)
~~~


**Signos:** C, F, CP, PUB, DEV, IVA e ISR van **en positivo** y se **restan**. AJ lleva su signo (+ a favor del vendedor). Nunca se mete un costo negativo a la plantilla.


### 3.6 Redondeo y orden de operaciones (fijo)


1. Sumar las filas del CSV por SKU y por columna **sin redondear**.
2. C y F **no se dividen** (v1.6). **La plantilla** multiplica la publicidad del bulk × 1.16 por SKU y la **redondea a 2 decimales** (mitad hacia arriba). **Para que el redondeo sea por SKU y no por Parent (v1.8.4, D81), todo Parent que agrupa más de un SKU manda sus SKU en `hijos`** con su gasto y sus ventas con ads sin IVA; la plantilla redondea cada SKU y el Parent es la suma.
3. ISR = tasa ISR × V ÷ 1.16 (÷ 1.08 en región fronteriza confirmada), redondeado a 2 decimales por SKU.
4. CP = max(Unet, 0) × costo total por unidad, redondeado a 2 decimales por SKU.
5. UB, UT y CON se calculan con los campos ya redondeados.
6. **Agrupar (Parent o «Agrupar con») = suma de los campos de sus SKU.** Nunca se recalcula un Parent desde filas crudas.
7. Subtotales y totales = suma de los campos de los renglones. Todo porcentaje de subtotal **se recalcula desde los totales** (lo hace la plantilla); jamás se suman ni se promedian porcentajes.
8. Los porcentajes se muestran con 1 decimal. Los montos se calculan con centavos aunque la tabla muestre pesos enteros. **Al mostrar (v1.8.1, D64):** la plantilla redondea primero a centavos y después **mitad hacia arriba** (no redondeo bancario): 28,661.50 → «$28,662»; 28,660.50 → «$28,661»; −1,234.50 → «−$1,235».


### 3.7 Agrupación (fija)


1. Si el vendedor llenó «Agrupar con» en la plantilla, manda eso.
2. Si no, Parent ASIN del Business Report (reporte 2).
3. Si no hay ninguno, cada SKU es su propio Parent.


### 3.8 Nombres de los agregados


- **Contribución de productos** = Σ CON de todos los renglones de producto − la publicidad SP con IVA de **todos** los renglones de `sin` (los «sin venta», como un SKU que solo tiene anuncio en la hoja SP, **y** «Sponsored Products no asignable a SKU»). Es el subtotal de la tabla; **en el chat se copia de la página**, no se recalcula.
- **Contribución del canal** = Contribución de productos + **Gasto compartido real sin ISR** (sección 10). Si el ISR no está confirmado (sección 2), se muestran las dos versiones, rotuladas. **La plantilla la calcula y la muestra al final del bloque de cargos.** No existe fila TOTAL en la tabla de productos: sumar la tabla con el renglón de publicidad de marca y los cargos cuenta dos veces la publicidad de marca (ya está restada en los cargos de cuenta, del archivo de Ads × 1.16) y el ISR (ya está restado por producto).
- **Caja del mes** (sección 11) = lo que Amazon realmente cobró. Va **aparte**, en su propio bloque, y **no se suma** a la contribución. Concilia así: contribución del canal + ISR devengado por producto − ISR cobrado en el mes + gasto de Ads con IVA − cargo de publicidad del reporte = caja (v1.7). Así el ISR nunca se cuenta dos veces (D4).
- **No se le llama «utilidad neta» a nada de esto.** Son contribución, no utilidad contable.


**Cargos de cuenta** (suscripción, almacenamiento, servicios, ISR cobrado y publicidad de marca SB/SD del archivo de Ads; **el cargo de publicidad del reporte no**, v1.7) van en su propio bloque (secciones 10 y 14). **No se prorratean dentro del margen de un producto.**


**Publicidad de marca:** SB y SD van en su propio bloque, **rotulado «PUBLICIDAD DE MARCA — NO BAJA A PRODUCTO»**, y **se restan una sola vez, en los cargos de cuenta, con el gasto del archivo de Ads × 1.16** (v1.7). El cargo de publicidad del reporte no entra a la contribución. Decirlo así.


**La transferencia a banco NO es un costo.** Se excluye siempre y se dice.


---


## 4. Cobros que merecen validación


No depende de los costos: sale completo de los reportes.


**Lenguaje obligatorio:** **«posible diferencia»**, **«por validar»**, **«evidencia para abrir caso»**. Nunca «te deben», «vas a recuperar» ni «dinero garantizado».


| Etiqueta | Cuándo |
|---|---|
| **Evidencia para abrir caso** | Hay referencia contra la cual comparar y la desviación es consistente |
| **Validar antes de actuar** | El método es estadístico, o falta el concepto exacto |
| **Sin anomalía detectada** | Se revisó y cuadra. **Se escribe igual:** un renglón en cero prueba que se revisó |


### Comisión por referencia: tasa real vs referencia


- **Tasa real por orden y SKU (v1.8.4, D78)** = Σ −`tarifas de venta` ÷ Σ V de **todos los renglones Pedido de la misma orden (`Id. del pedido`) y el mismo SKU** (las dos con IVA; v1.6). **Nunca por renglón:** Amazon a veces parte una orden en dos renglones del mismo SKU y cobra la comisión de las dos unidades en uno y 0 en el otro; por renglón eso parece una tasa del doble y no lo es.
- **Referencia de Gerardo (solo cuadre de rango, v1.6):** comisión de alrededor de 12.9% (o 12.6%) + IVA ≈ **14.6%–15.0% con IVA**. **No es la tasa:** se usa lo que trae el reporte. Si la comisión % del subtotal sale fuera de ese rango, **no es error** (depende de la categoría): se menciona en una línea («tu comisión promedio fue X% con IVA; la referencia general es ~15%») y se revisa con la tasa de cada SKU. No detiene nada ni cambia ningún número.
- **Referencia** (en este orden, sin saltarse): (1) la **tasa más frecuente del propio SKU en el mes, dentro de su banda de precio** (v1.8.3, D67; ver «Regla fija» abajo); (2) si el Fee Preview trae la comisión estimada por unidad y el precio, esa tasa, rotulada **«tarifa vigente hoy, no la del mes»**. **Nunca** una tarifa de memoria.
- Lo que vuelve defendible el caso: **el mismo SKU, en la misma banda de precio, cobrado a una tasa más alta en una orden completa**. Se reporta monto, órdenes **y cuántos SKU o Child ASIN**.
- **Banda de la comisión (v1.8.5, D88):** para la comisión, la banda ($299 o más / menos de $299) se toma con el **precio después de promociones** (Σ `ventas de productos` + impuesto + `descuentos promocionales` + su impuesto, ÷ unidades). En los datos reales, órdenes que quedaron abajo de $299 por una promoción pagaron la tasa de la banda baja. **No está confirmado cómo lo hace Amazon:** en la tabla de casos y en el texto del caso se escribe «banda tomada con el precio después de la promoción, por confirmar con Amazon». La banda del FBA sigue con el precio antes de promociones.
- **Cómo se dice (v1.8.4, D78):** «comisión arriba de la tasa normal del SKU en N órdenes, $X por validar». **Nunca** «cobrada al doble», «cobrada dos veces» ni «duplicada»: eso es una afirmación que la skill no puede probar.
- **Chequeo de cordura de la comisión %:** el subtotal de la tabla debe quedar **entre la menor y la mayor** comisión % de sus renglones. Si no, hay un error de signo, de IVA o de agrupación: **se detiene, se corrige y se dice**. No se entrega un subtotal fuera de ese rango.


### Tarifa FBA fuera de rango


El Fee Preview trae la tarifa **de hoy**, no la del día de cada venta. **La referencia sale de los propios datos:** la tarifa por unidad más frecuente del SKU en el mes, en su banda de precio; las órdenes que pagaron más son el hallazgo (Order ID, fecha, unidades, exceso). Cada una va como renglón en `ordenes` (sección 14) para el CSV.


**Por orden y SKU, y sin el envío que pagó el comprador (v1.8.4, D77):** antes de comparar, se suman los renglones Pedido de la misma orden y el mismo SKU (FBA, unidades, ventas y `créditos de envío`). Cuando el comprador paga envío (rápido), Amazon cobra ese envío como tarifa FBA más alta, **pero ya se lo pagó al vendedor** en `créditos de envío`: el efecto neto es cero. Por eso el FBA que se compara es **−`tarifas fba` − `créditos de envío` × 1.16 − `créditos por envoltorio de regalo` × 1.16** (los créditos vienen sin IVA; cada uno redondeado a centavos). **La envoltura de regalo (v1.8.5, D87)** sigue el mismo patrón que el envío: Amazon la cobra dentro de la tarifa FBA y ya se la pagó al vendedor en el crédito de envoltura. Solo lo que queda arriba de la tarifa normal es exceso.


**Banda de precio (v1.8.3, D66):** en Amazon México la tarifa FBA cambia con el precio: las órdenes con precio por unidad **de $299 o más** pagan una tarifa más alta que las de menos de $299. Por eso **la tarifa modal se saca por SKU y por banda**, nunca de todo el mes junto. Precio por unidad = Σ (`ventas de productos` + `impuesto de ventas de productos`) ÷ Σ `cantidad` de la orden y SKU, con IVA. Si un SKU, dentro de una banda, tiene **dos tarifas frecuentes** (la segunda en 25% o más de sus órdenes), **no se marca ningún exceso** en esa banda: se dice «dos tarifas frecuentes, sin conclusión». **Se cuenta aparte (v1.8.5, D85):** la tarjeta de FBA dice cuántas combinaciones SKU/banda de **FBA** quedaron sin conclusión, y la de comisión las de **comisión**; nunca se suman en un solo número. Sin bandas, casi todo el «exceso» resulta ser la tarifa normal de $299 o más.


Como es estadística, **se etiqueta «validar antes de actuar»** y va **separada** de la comisión: no se suman en un titular. La referencia se construye con unidades **de las órdenes**, no netas de devoluciones. Una orden ya revertida en el mismo mes **no** cuenta como exceso; se dice cuántas se excluyeron.


**Fórmulas de los campos de atención (nuevo en v1.4, una sola fórmula):**


| Campo (posición en `productos`) | Fórmula |
|---|---|
| **Tarifa modal** | La tarifa FBA por unidad de cada **orden y SKU** ((Σ −`tarifas fba` − Σ `créditos de envío` × 1.16) ÷ Σ `cantidad`, redondeada a centavos; v1.8.4) que más se repite en el mes para ese SKU **y esa banda de precio** (v1.8.3). Empate: la menor. Con dos tarifas frecuentes en la banda: sin referencia (no se marca exceso) |
| **FBA debería ser, por banda** | Cada orden se compara con la tarifa modal **de su banda** |
| **FBA debería ser** (16) | Σ (unidades de cada orden × tarifa modal), **tal cual el reporte** (con IVA; no se divide entre 1.16) |
| **Dif. FBA** (17) | −Σ `tarifas fba` de las filas Pedido del SKU (tal cual el reporte) − FBA debería ser, con signo. Misma base que «Por validar»; puede ser menor si alguna orden pagó menos que la tarifa modal |
| **Por validar $** (18) | Σ de las diferencias **positivas** por orden y SKU (cobrado − envío pagado por el comprador × 1.16 − unidades × tarifa modal), con IVA (así se rotula) |
| **Uds a revisar** (19) | Σ unidades de esas mismas órdenes |


**Los campos de atención van en la misma base, tal cual el reporte, y no se dividen ni se redondean por partes** (v1.5). Desde v1.5.1 el grupo se llama «ATENCIÓN · tal cual el reporte, con IVA» y trae al lado **«FBA cobrado»** (= FBA debería ser + Dif. FBA), y desde v1.6 «Costo FBA total (con IVA, entra a la contribución)» está en la **misma base**: FBA cobrado = Costo FBA total cuando no hay otro ajuste.


`ordenes` lleva **exactamente** esas órdenes (diferencia positiva), con las unidades en el campo 9. El titular «Vimos $X» y el CSV salen de `ordenes`; la plantilla avisa «Descuadre» si Σ «por validar» de `productos` ≠ Σ diferencias de `ordenes` (cuadre 10).


**Regla fija para comisión y FBA (v1.8.3, D67; por orden y SKU desde v1.8.4, D77 y D78: dos corridas deben dar lo mismo).** Se calcula **con código** (Python o la herramienta de análisis), nunca a ojo, exactamente así:


~~~python
# p = filas tipo Pedido del reporte 1; rev = Order ID con fila Reembolso en el mes
# 1) Se suman los renglones de la MISMA orden y el MISMO SKU (Amazon a veces parte una orden en dos renglones)
o = p.groupby(["Id. del pedido", "sku"]).sum(cantidad, V, tarifas_de_venta, tarifas_fba,
                                             ventas_prod, imp_ventas_prod, creditos_de_envio,
                                             creditos_envoltura, descuentos_promo, imp_descuentos_promo)
banda = "299+" if (ventas_prod + imp_ventas_prod) / cantidad >= 299 else "<299"
banda_com = "299+" if (ventas_prod + imp_ventas_prod + descuentos_promo + imp_descuentos_promo) / cantidad >= 299 else "<299"  # D88: después de promociones
fba_neto = round(-tarifas_fba - round(creditos_de_envio * 1.16, 2) - round(creditos_envoltura * 1.16, 2), 2)   # D77, D87: sin envío ni envoltura pagados por el comprador
fba_u = round(fba_neto / cantidad, 2)               # FBA por unidad de la orden
com_t = round(-tarifas_de_venta / V, 3)             # comisión de la orden: tasa a 0.1 punto
# 2) FBA por (SKU, banda); comisión por (SKU, banda_com): referencia = valor más frecuente entre las órdenes (empate: el menor)
#    si el segundo valor más frecuente está en >= 25% de las órdenes: sin referencia (FBA y comisión)
# 3) exceso FBA de la orden = fba_neto - cantidad * ref_fba            (cuenta si > 0.005)
#    exceso comisión = -tarifas_de_venta - V * ref_com                 (cuenta si com_t > ref_com y > 0.005)
# 4) las órdenes en rev no cuentan; se dice cuántas se excluyeron
# 5) N de M (C3): N = órdenes (orden + SKU) con la referencia; M = órdenes del SKU en esa banda. Nunca renglones
# 6) sin_conclusion_fba y sin_conclusion_com se cuentan APARTE (D85): cada tarjeta dice solo el suyo
~~~


**Tabla de casos por orden (v1.8.5, C1).** Todo exceso de FBA **y** de comisión va como renglón en `ordenes`, una orden y SKU por renglón, con los campos del 10 al 15 (sección 14):
- ASIN, del bulk o del Business Report; si no está, «no sé».
- Base del esperado: banda, tarifa o tasa normal y «N de M órdenes del SKU en esa banda» (C3).
- Validación previa: qué explicación podría tener el exceso y no está descontada. Si no hay ninguna, «Sin explicación en el reporte».
- Recomendación: «Abrir caso» o «NO abrir todavía: <motivo>».
- Texto del caso: en español y listo para pegar a Soporte al Vendedor. Trae el pedido, el SKU, el ASIN, las unidades, la fecha, cobrado contra esperado, la base, la base de IVA («montos tal cual el reporte, con IVA») y lo que no se sabe, dicho como «no sé». Pide primero «confirmar cómo se calculó» y después «si no corresponde, revisar y reembolsar». **Nunca afirma un cobro indebido.** Si se deja vacío, la plantilla arma uno con esos campos.
- Tipo: `'fba'` o `'com'`.


La plantilla muestra la tabla de casos y el CSV lleva los mismos campos. El titular «Vimos $X» y el cuadre 10 suman **solo FBA**; la comisión va en la tabla y en su propio total del CSV, sin sumarse al titular. En el chat se dice: «N casos listos para abrir; M que no recomiendo abrir todavía, y por qué».


Se reporta monto, órdenes y SKU de cada revisión **por separado** (FBA en `ordenes` y titular; comisión en `ordenes` con tipo `'com'` y en su tarjeta de `rev`). En `ordenes`, «cobrado» es el FBA de la orden y SKU tal cual el reporte y «esperado» = unidades × tarifa modal + envío y envoltura pagados por el comprador × 1.16; el concepto dice «FBA arriba de la tarifa normal (ya restados el envío y la envoltura que pagó el comprador)». La comisión también cambia con el precio (por ejemplo, alrededor de 15% contra 18%): sin bandas, esa diferencia normal sale como exceso.


Un SKU que cobra de más sistemáticamente suele ser **peso o dimensiones mal medidos**: ruta **FBA product weights and dimensions**.


Al pie: *«$0 de exceso significa que ninguna orden se salió de la tarifa normal de ese SKU; no significa que la tarifa normal sea la correcta.»*


### Cargos sin descripción


Antes de ponerlos por validar, la división de la sección 2. Si da la tasa de la tabla para el mes anterior (± 0.1 puntos), es ISR y sale de este bloque.


**Cuál es el candidato a ISR (v1.8.3, E1):** solo los cargos **negativos** tipo Ajuste «Otro» sin SKU ni descripción. Si hay más de uno negativo, se suman en un solo renglón y el chequeo de tasa se hace con la suma. Un «Otro» **positivo** (abono) **no** es ISR: entra a los cargos de cuenta como «Abono sin descripción», sin etiqueta `isr`.


**Cómo se llama el renglón (v1.8.3, pedido de Gerardo):** «Retención de ISR de <mes anterior> cobrada en <mes analizado>», con la fecha de la fila; si no está confirmado, se agrega «— POR CONFIRMAR». Ese nombre aparece en los cargos de cuenta y la plantilla lo repite en la caja del mes («ISR cobrado este mes: …»), para que se vea que es el ISR de las ventas del mes anterior y que sí salió de la liquidación.


### Ruta del caso


Ayuda › Obtener soporte › Vender en Amazon › **Reconcile Charges** › **Referral Fee** › **Review Fees** › Order ID › **Contact an associate** › pestaña **Email**. **Nunca por chat.** Se entrega asunto y cuerpo listos. Si a los 3 días no contestan, se responde **en el mismo caso**.


---


## 5. Cuadres — sin esto no se entrega nada


**Cada peso de los reportes termina en algún renglón.** Lo no asignable se muestra con su monto y nombre. Nunca se descarta en silencio.


| # | Qué se suma | Contra qué debe dar | Tolerancia |
|---|---|---|---|
| 1 | Todas las filas del reporte 1 **excepto transferencias** (columna `total`) | Contribución de productos + CP total + ISR devengado total + TOTAL CARGOS DE CUENTA + gasto total de Ads con IVA − cargo de publicidad del reporte (v1.7: la publicidad de la contribución sale del archivo de Ads; el cargo del reporte sí está en el reporte 1) | $0.00 |
| 2 | Cada `tipo` y `descripción` distintos | Total del CSV, cada tipo con destino | $0.00 |
| 3 | V de SKU mapeados + sin mapear | Ventas totales del CSV | $0.00 |
| 4 | Por cada campaña SP: Σ `Spend` de sus filas `Ad group` | `Spend` de su fila `Campaign`. **Desde v1.8.3 es aviso de calidad del bulk, no cambia ningún número:** se dice «el renglón de campaña difiere de sus anuncios por $X en N campañas; usé los anuncios» | $0.01 por campaña |
| 5 | Filas `Campaign` del bulk | Campaign IDs únicos (dedup, decir cuántas y por cuánto). **Deduplicar es lo esperado: si el SB usado = Σ de Campaign IDs únicos, el cuadre 5 cuadró** y se escribe «cuadró (N campañas deduplicadas por $X)»; nunca se lista como descuadre (v1.8.9) | exacto |
| 6 | MX: C y F de `DATA`, por SKU | = −Σ `tarifas de venta` y −Σ `tarifas fba` del reporte, **exacto** (v1.6: comprueba que no se dividió entre 1.16) | $0.00 |
| 7 | Unidades del Business Report | U − Udev (sección 6) | 6% · 1.5 días de cola |
| 8 | **Caja** (sección 11, sección aparte del artefacto) | «Lo que quedó de las liquidaciones» = Σ reporte 1 sin transferencias; resultado de caja = eso − CP total; la conciliación (canal + ISR devengado − ISR cobrado + gasto de Ads con IVA − cargo de publicidad del reporte) debe decir «cuadra» | $0.00 |
| 9 | **Determinismo:** antes de publicar, recalcular Contribución de productos y TOTAL CARGOS desde cero con las fórmulas de la sección 3 | Mismo número al centavo | $0.00 |
| 10 | Σ «por validar $» de `productos` | Σ diferencias de `ordenes` **de tipo `fba`** (sección 4; la comisión va aparte, en su tarjeta y en su total del CSV) | $0.00 |
| 11 | Gasto total Ads (SP + SB + SD, con IVA, calculado por la plantilla) | ≤ cobro de publicidad, tal cual (sección 3.4). Si no, aviso «Revisar la publicidad» y canal POR VALIDAR (confirmado por Gerardo el 19-oct-2026 a las 10:20). **No aplica si el reporte no trae cargo de publicidad** (v1.7) | — |
| 12 | MX (v1.6.1, lo hace la plantilla): retención ÷ (V ÷ (1 + tasa)) y Σ ISR devengado vs 2.5% × V ÷ (1 + tasa); `pubAsignada` vs Σ renglones de publicidad | 8.0% (4.0% fronteriza) ± 0.1; ISR ± $0.01 por producto; publicidad exacta. Si no, aviso y canal POR VALIDAR; si la retención da 4% con tasa 16%: alto y pregunta de región fronteriza | ver columna anterior |


**Si un cuadre no da, el descuadre va arriba, en el encabezado, con monto y qué no se ubicó.**


### Reglas duras


- **Join externo, siempre.** Universo de SKU de la tabla = transacciones ∪ SKU con gasto en la hoja **`Sponsored Products Campaigns`** del bulk ∪ Fee Preview. Un SKU sin listing activo aparece igual como `(sin listing activo)`. Un SKU que solo aparece en Sponsored Display o Sponsored Brands **no** es renglón de la tabla: su gasto ya está en la publicidad de marca. (La plantilla de costos usa otro universo: solo SKU con pedidos; sección 0.)
- **Un tipo de transacción o cargo que no se sabe clasificar detiene el cálculo y se pregunta.**
- **Todo lo no asignable existe como renglón visible, aunque valga $0.**
- **El join con sesiones es por ASIN.** Sin venta o sin sesiones → conversión **vacía, no cero**.
- Una línea al cierre: **«N transacciones revisadas, $X conciliados, $Y sin clasificar.»** **N = filas del reporte 1 sin las transferencias** (el mismo universo que $X; las transferencias se cuentan en su propia frase). **$X = Σ `total` de todas las filas del reporte 1 menos las transferencias al banco** (tipo `Transferir`/`Trasferir`); es el mismo monto que «lo que quedó de las liquidaciones» de la caja (v1.8.7, D94). Las transferencias **nunca** se suman a «conciliados», ni en valor absoluto; si se mencionan, van en otra frase: «Además hubo K transferencias a tu banco por $T.»


---


## 6. El Business Report nunca va a cuadrar, y está bien


Por qué difiere: **dos relojes** (fecha del pedido vs envío/cobro), **bruto vs neto**, **cancelaciones**, **zona horaria** (transacciones en GMT-7), **definición de venta** (`Ordered Product Sales` sin envío ni promociones).


> `días de cola = (unidades Business Report − U + Udev) ÷ (U ÷ días del mes)`


**≤ 1.5 días** es rezago normal; **> 1.5** se investiga antes de entregar.


**Frase fija arriba del entregable:**


> **Este reporte mide cobros del mes, no pedidos del mes.** La diferencia de unidades se explica por devoluciones, tránsito y fechas de liquidación de Amazon.


---


## 7. Retorno sobre costo y volumen


> `Retorno sobre costo = Contribución del producto ÷ Costo de producto (CP)`
> `Contribución por unidad neta = Contribución del producto ÷ Unet`


**Redacción obligatoria:**


> **Retorno sobre costo muestra cuánto deja cada peso invertido en producto** después de comisiones, logística, publicidad y demás costos incluidos. Un retorno de 81% significa que por cada $1 invertido, recuperaste ese $1 y además quedaron **$0.81 de contribución**. Arriba de 100% es excelente; entre 70% y 99% sigue siendo rentable, pero con menos margen para errores, descuentos o costos nuevos.


**Prohibido decir** «no se repone solo». Un retorno positivo ya recuperó el costo. **No es margen sobre venta.**


| Semáforo | Banda | Qué significa |
|---|---|---|
| **SÚPER SANO** | ≥ 150% | Regresa y deja $1.50 o más. Aquí va presupuesto e inventario |
| **SANO** | 100–149% | Regresa y deja más de otro peso. No se toca |
| **ACEPTABLE** | 70–99% | **Rentable, con oportunidad de mejora** |
| **REVISAR** | 45–69% | Deja contribución, margen de maniobra estrecho |
| **PELIGRO** | 20–44% | El capital regresa muy lento |
| **PIERDE** | < 20% | La contribución no cubre el ciclo |


**Ajuste por flete y aduana — solo si aplica.** Se omite si el costo es puesto en bodega. Si faltan y suman ~20% del costo, el retorno nuevo es **(r − 0.20) ÷ 1.20** y **se calcula, no se estima** (v1.8.4, D80): 295% → ~229% · 103% → ~69% · 88% → ~57% · 70% → ~42% · 52% → ~27% · 25% → ~4%. El ejemplo del chat usa un producto real de la tabla y esta fórmula.


### Volumen (en pesos de contribución, % de la suma de contribuciones positivas)


**Base (fija desde v1.4; ajustada en v1.5):** contribución del renglón ÷ **suma de las contribuciones positivas de los productos que tienen costo y venta neta**. Los renglones «SIN COSTO» y «SIN VENTA NETA» **no entran a ninguna base** (ni a la de contribución ni a la de ventas), porque su contribución no tiene restado el costo y desplazaría a los demás. Un renglón que pierde queda con porcentaje negativo (RUIDO) y su peso se mide con las ventas en la matriz (regla del 3%, abajo). **Si ningún producto tiene contribución positiva**, la base son las ventas: ventas del renglón ÷ ventas de los productos con costo y venta neta. Nunca se divide entre un total en cero o negativo.


| Tier | Banda |
|---|---|
| **CORE** | ≥ 10% |
| **RELEVANTE** | 2–10% |
| **MARGINAL** | 0.5–2% |
| **RUIDO** | < 0.5% |


### Matriz retorno × volumen


Textos exactos que pone la plantilla (v1.4 alinea esta tabla con el código):


|  | CORE | RELEVANTE | MARGINAL / RUIDO |
|---|---|---|---|
| **SANO / SÚPER SANO** | Proteger stock y subir publicidad | ESCALAR FUERTE: aquí va el presupuesto | TACOS de Sponsored Products < 5%: «PROBAR: rentable con publicidad limitada» · TACOS de Sponsored Products ≥ 5%: «Ya se empujó con presupuesto y no jaló» |
| **ACEPTABLE** | Arreglar antes de crecer: precio o publicidad | Subir precio 5-10% y medir | Dejar quieto: no merece presupuesto |
| **REVISAR** | EMERGENCIA: volumen drenando caja | Cortar publicidad y arreglar precio o empaque | Con ≥ 3% de las ventas: «Cortar publicidad y arreglar precio o empaque» · si no: «Cortar publicidad y revisar precio» |
| **PELIGRO** | EMERGENCIA: volumen drenando caja | Cortar publicidad y arreglar precio o empaque | Con ≥ 3% de las ventas: «Cortar publicidad y arreglar precio o empaque» · si no: «DESCONTINUAR» |
| **PIERDE** | PARAR VENTAS YA | PARAR VENTAS YA | Con ≥ 3% de las ventas: «PARAR VENTAS YA» · si no: «DESCONTINUAR» |


**Regla del 3% (documentada en v1.4):** un renglón con 3% o más de las ventas de los productos (misma base de ventas) se trata como **grande** aunque su volumen de contribución sea MARGINAL o RUIDO (por ejemplo, porque pierde). **Umbral de «publicidad limitada»:** TACOS de Sponsored Products < 5%, igual en MXN y USD (antes era $500 fijo).


**Renglones sin costo o sin venta neta** (CP = 0, V ≤ 0 o Unet ≤ 0): **sin retorno, sin semáforo, sin volumen y sin acción**; la plantilla pone «SIN COSTO» o «SIN VENTA NETA». Si algún producto con venta no tiene costo, el subtotal no lleva retorno ni semáforo («FALTA COSTO»). El monto y el % de ventas sin costo se dan con V con IVA (sección 1, v1.8.7, D91).


**TACOS de Sponsored Products:** < 5% = vende poco porque casi no lo anunciaste (probar con presupuesto acotado). > 15% con presupuesto real = ya lo empujaste y no jaló. **De un gasto insignificante no se concluye «no hay mercado».**


La lógica de `salud`, `tier` y `accion` está implementada en la plantilla de la sección 14; **no se reescribe**.


### Reglas de cálculo


- **Subtotales y totales van SIN Volumen ni Acción.** El semáforo sí se pinta.
- En subtotales el costo unitario es **CP total ÷ Σ Unet positivas**; ACOS, TACOS, comisión % y todo porcentaje **se recalculan desde los totales** (lo hace la plantilla).
- Todo producto grande (CORE, RELEVANTE o con 3% o más de las ventas) en REVISAR, PELIGRO o PIERDE **entra al cierre en el chat**: como «Detener fuga» o como alerta.
- **Las 3 decisiones se eligen con regla fija, a nivel Parent** (para que dos corridas elijan lo mismo), **salvo los Parent «Decidir por Child» (v1.8.4, D82): esos no entran como familia; en su lugar entran sus variantes, cada una con su propio retorno, semáforo y volumen**, y en el chat se nombran como «Parent · variante». Solo entran renglones con semáforo (nunca «SIN COSTO» ni «SIN VENTA NETA»). **Grande** = CORE o RELEVANTE **o con 3% o más de las ventas** (la misma regla que usa la matriz). **Proteger** = el renglón **CORE o RELEVANTE** en SANO o SÚPER SANO con mayor contribución. **Arreglar** = el renglón **CORE o RELEVANTE** en ACEPTABLE con mayor contribución (así coincide con la acción de la tabla: un MARGINAL o RUIDO en ACEPTABLE es «Dejar quieto»). **Detener fuga** = el renglón con menor retorno entre **los mismos que van a las alertas: todo renglón grande en REVISAR, PELIGRO o PIERDE** (v1.5.2, D29; en esas celdas la tabla dice «EMERGENCIA: volumen drenando caja», «Cortar publicidad y arreglar precio o empaque» o «PARAR VENTAS YA», así que no hay contradicción). La restricción a CORE o RELEVANTE de Proteger y Arreglar (D26) **se queda igual**. Si no hay renglón para una decisión, se dice «no aplica este mes» (desde v1.5.1 ya no hay segunda opción por gasto de publicidad). Empates: gana el de más ventas. **Los demás renglones grandes en REVISAR, PELIGRO o PIERDE** se listan debajo de las 3 decisiones como alertas, de menor a mayor retorno. Así un producto que pierde con mucha venta nunca desaparece del cierre aunque su volumen salga RUIDO.
- **La plantilla calcula estas 3 decisiones con la misma regla** y las deja en el atributo `data-decisiones` de la página (no se muestran en el artefacto). Si el HTML corrió, las del chat **tienen que ser las mismas**; si no son iguales, se corrige el chat, no la plantilla. Si no corrió, se aplican a mano y se dice «No pude probar el artefacto en un navegador».


### Dos límites


**El retorno no ve la velocidad** (requiere inventario real). **El ratio no ve la contribución absoluta**: contribución muy baja no absorbe costos fijos aunque se arregle el ratio.


---


## 8. Variantes, Parents y Children


Dos renglones que son **el mismo producto en otra talla** y comparten costo van en uno solo (`Producto (XL + normal)`); **qué se agrupa lo decide el vendedor** (columna «Agrupar con» de la plantilla de costos; sección 3.7).


**Cuando los Children de un Parent no se parecen:** si el rango de retorno entre el mejor y el peor Child **con retorno** supera **40 puntos** (los Child sin costo o sin venta neta no cuentan), el Parent esconde el problema: marca **«Decidir por Child»**, aviso con el Child que arrastra, y **no se da instrucción general para la familia** (v1.8.4, D82): la columna Acción del Parent dice «Decidir por Child: ver la acción de cada variante», cada variante lleva su propia acción, y en las 3 decisiones y las alertas entran las variantes, no el Parent. En el chat, ese Parent se presenta **por Child** (por ejemplo: «la variante X está en REVISAR con 68%; las otras dos en ACEPTABLE y SANO»). La plantilla ya lo calcula.


---


## 9. Alerta vs instrucción


**SÍ puede decir:** cuánto gasta y deja un producto, que su ACOS/TACOS o devoluciones están fuera de rango, que su retorno es bajo, cuánto dinero está en juego.


**NO puede decir:** «pausa la campaña X», «lleva el ACOS de Sponsored Products a <cifra>» (sin calcular el ACOS máximo rentable del SKU), «negativiza estos términos», «el problema es el listing».


~~~
ALERTA / OPORTUNIDAD: <qué pasa, en una línea>
<cifras: ventas, contribución, publicidad, retorno>
El reporte general detectó <el hecho>, pero todavía no dice <qué falta saber>.
Siguiente paso: abrir el <Sistema> para <qué abre> y decidir <qué se decide>.
~~~


| Problema | Sistema |
|---|---|
| Gasto publicitario ineficiente, ACOS/TACOS alto | **Sistema de Optimización de Pujas** |
| Producto rentable que no crece | **Sistema de Escalamiento y Nuevas Campañas** |
| Baja conversión, listing débil | **Sistema de Optimización de Listings e Imágenes con IA** |
| Margen, precio u oferta | **Sistema de Precio y Oferta** |
| Cobros que merecen validación | **Auditoría y Recuperación Amazon** |


---


## 10. El entregable


**Un solo artefacto**, publicado con la herramienta Artifact (privado). No Excel ni archivos sueltos con el diagnóstico; el CSV de cobros es la única descarga del diagnóstico y sale del propio artefacto. (La única excepción es la plantilla de costos prellenada de la sección 0, que se entrega **antes** de calcular.) Una sola vista oscura. **No se pega en el chat ningún enlace ni URL del artefacto** (v1.8.10, D112): el artefacto ya se ve en la conversación; se dice «el diagnóstico está en el artefacto».


**El artefacto se construye con la plantilla de la sección 14, sin rediseñarla.** Antes: cargar `artifact-design` y `artifact-capabilities`. Publicar con `capabilities: {downloads: true}` (el CSV usa `claude.use('downloads').save(...)`; el vendedor confirma el guardado y puede declinar).


**CSV en el chat: solo en dos casos (v1.8.10, D111).** (a) La descarga no está disponible o falló (el artefacto lo dice o la prueba lo mostró), o (b) el vendedor lo pide. En esos casos el CSV va en un bloque de código, completo. **Si la descarga funciona y el vendedor no lo pidió, el CSV no se pega en el chat** (tampoco «por si la descarga no funciona»): ya está en el artefacto, con su botón y con «¿No se descarga? Ver el CSV para copiarlo». Nunca se cierra sin que el vendedor tenga el CSV de alguna de las dos formas. El bloque B de la sección 15 tiene una variante para cada caso.


### Estructura, en este orden


0. **Marca:** barra fija con logomark + «PROFIT AI SYSTEM»; si el vendedor dio el nombre de su tienda o marca (pregunta 3), aparece en la barra y en el encabezado como **«Preparado para: <marca>»**. Encabezado «Diagnóstico de Rentabilidad Amazon · por Gerardo Villa», con tienda, periodo, moneda y la línea de privacidad *«Corrió en tu propia cuenta de Claude. Ni Summa ni Gerardo ven tus reportes.»* El nombre de la marca se muestra como texto (la plantilla lo escapa).
1. **Tabla de productos:** pestañas **Parent / Child**, selector **Columnas clave / Todas**, encabezados ordenables, columnas de **DECISIÓN** (retorno, salud, volumen, acción) justo después de Unidades, renglones «SIN VENTA» / «NO ASIGNABLE», subtotal de productos y renglón de publicidad de marca. **Sin fila TOTAL.** Arriba de la tabla, los avisos grandes (`avisos` y los que agrega la plantilla). «Decidir por Child», leyenda de bandas.
2. **Cargos de cuenta** (abajo), con este rotulado y orden de mayor a menor cargo:
   - **CARGOS QUE AMAZON NO ATA A NINGÚN PRODUCTO**
   - Tarifa de servicios Premium
   - ISR retenido de <mes anterior> (tasa confirmada X% s/venta sin IVA) — *informativo, ya repartido por producto* (si no está confirmado: «Cargo sin descripción — probablemente ISR, POR CONFIRMAR»)
   - Almacenamiento mensual FBA
   - Envío con transportista asociado FBA
   - Suscripción Seller Central
   - Transporte de envíos a Amazon
   - Almacenamiento prolongado FBA
   - Retiro de inventario FBA
   - **Publicidad de marca SB/SD** (negativo, del bulk × 1.16). Sponsored Products ya está restado por producto. **El cargo de publicidad del reporte no se lista aquí ni entra al total** (v1.7); la nota del bloque lo muestra junto con su diferencia contra el gasto.
   - **TOTAL CARGOS DE CUENTA**
   - **Gasto compartido real (sin ISR)** y **CONTRIBUCIÓN DEL CANAL** (si el ISR está POR CONFIRMAR: dos renglones, «si el cargo es ISR» y «si el cargo NO es ISR»). Los calcula la plantilla.
   - Debajo: **PUBLICIDAD DE MARCA — NO BAJA A PRODUCTO** (gasto SB/SD, ventas SB/SD, «ACOS de marca (SB/SD)»; el renglón de marca de la tabla de productos deja en blanco «ACOS SP» y «TACOS SP»: el ACOS de marca se lee solo de este bloque) y el «ACOS TOTAL DE LA CUENTA (SP + SB + SD)».
3. **Caja del mes · reporte aparte** (v1.6.1, D40: sección propia, con borde punteado y color distinto): **CAJA DEL MES — REPORTE APARTE: LIQUIDACIONES DE AMAZON MENOS COSTO DE PRODUCTO** (sección 11; la arma la plantilla).
4. **Cobros por validar: tabla de casos por orden + CSV descargable** (v1.8.5, C1; con `ordenes` llenas: Order ID, fecha, SKU/ASIN, concepto, cobrado, esperado, diferencia, etiqueta, unidades, base, validación previa, recomendación y texto del caso; montos tal cual el reporte; BOM UTF-8; sin datos del comprador), con el texto: *«Vimos $X que Amazon podría haberte cobrado de más en <mes>. Aún hay que revisar producto por producto antes de reclamarlo. **No es dinero garantizado.**»* El recuadro **«Cobro de publicidad vs gasto»** (sección 3.4) va siempre en `rev`.


**Pie:** logomark, «PROFIT AI SYSTEM» y «Diagnóstico de Rentabilidad Amazon · por Gerardo Villa». **Ninguna cifra de ventas, trayectoria o resultados de Gerardo, Summa o sus marcas** en el artefacto ni en el chat (ni «$5M+ USD en ventas verificadas» ni otra). Si el dueño de la skill aprueba una cifra con evidencia, se agrega en una versión nueva, no en una corrida.


### Montos de los cargos de cuenta


**Por qué este total no se parece al de una hoja hecha con el API (v1.8.3, pregunta de Gerardo):** aquí los reembolsos a clientes, las cuotas que Amazon devuelve y los envíos cobrados **no** son cargos de cuenta: viven por producto (envío dentro de V; reembolsos y cuotas devueltas dentro de DEV). Y aquí **sí** están el ISR del mes anterior y la publicidad de marca. Si el vendedor compara, se le dice renglón por renglón dónde quedó cada uno.


Los cargos de cuenta se registran **tal cual el reporte 1**, que los trae **con IVA**, y así se dice en la nota del bloque («Montos tal cual el reporte, con IVA»). Desde v1.6 nada se divide entre 1.16: ni aquí ni en el chequeo 3.4.


### Reglas del bloque de cargos


- Nombres de Amazon, tal cual del reporte 1. **Un cargo que no está en la lista entra con su propio nombre**; nunca «otros». Un cargo en $0 se queda en cero.
- **TOTAL CARGOS DE CUENTA = suma de los renglones del reporte sin el cargo de publicidad (incluido el ISR) − publicidad de marca SB/SD del bulk × 1.16** (v1.7). La plantilla lo calcula.
- **Gasto compartido real sin ISR** = TOTAL − renglón de ISR; es el que entra a la **Contribución del canal** (sección 3.8). Tiene que cuadrar con el cuadre 1; si no, el descuadre va arriba.




### Qué NO va en el artefacto


Las **3 decisiones** (regla fija de la sección 7) van **en el cierre del chat**: una por línea, con producto o grupo · ventas · contribución · publicidad · retorno, en formato alerta/oportunidad, **siempre en este orden y con esta etiqueta fija (v1.8.7, D89):**


| # | Decisión | Etiqueta |
|---|---|---|
| 1 | **Proteger** | **Hacer hoy** |
| 2 | **Arreglar** | **Probar y medir** |
| 3 | **Detener fuga** | **Auditar o validar** |


El mismo orden y las mismas etiquetas en el chat, en el «Resumen para guardar» (sección 15) y en el atributo `data-orden-decisiones` de la página. Nunca se reordenan por monto ni por urgencia, y ninguna lleva otra etiqueta. Si una no aplica, conserva su número y dice «no aplica este mes». El bloque de caja, la matriz, el puente y «Cómo leer esto» **no se incluyen** salvo que el vendedor los pida. **El diagnóstico no es página de venta**: una sola línea al cierre nombra el siguiente sistema.


### Muestra para captura de pantalla


Si el artefacto es de **muestra**: `DATA.muestra=true`, **sin datos de ninguna tienda real** (nombres «Producto A…», sin ASIN, SKU, Order IDs ni nombre de cuenta; `marca` vacía o «Tienda de muestra»); si no hay datos Child, no se inventan hijos y se dice.


### Antes de publicar


- **Si no puedes ejecutar el HTML**, escribe en el chat, textual: **«No pude probar el artefacto en un navegador»**, y marca cada chequeo de esta lista como **no hecho**. Nunca se da por probado algo que no corrió.
- Ejecutar el HTML (Playwright o equivalente) y **contar celdas**: `<td>` de cada fila = `<th>` = suma de los `colspan`, en Parent y Child y en Clave y Todas. **Obligatorio siempre que el HTML corra (v1.8.10, D114):** se reporta con números («celdas: Parent Clave <a>/<a>, Parent Todas …, Child Clave …, Child Todas …»). «No conté las celdas» solo se permite junto con «No pude probar el artefacto en un navegador».
- `scrollWidth` = `innerWidth` a 1300 y a 390 px. **En el chat solo se reporta lo medido (v1.8.9):** «a <ancho> px: scrollWidth <a> = innerWidth <b>» por cada ancho que de verdad corriste; si no mediste 390 px, «a 390 px no lo medí». **La medida a 1300 px es obligatoria cuando el HTML corre (v1.8.10, D114).** Nunca «sin desborde» sin la medición.
- El **TOTAL CARGOS DE CUENTA** de la página = el calculado en el cuadre.
- La **Contribución de productos** de la página = la del cuadre 9, y la **CONTRIBUCIÓN DEL CANAL** de la página = la calculada (sección 3.8).
- El titular «Vimos $X» = Σ diferencias de `ordenes` **de tipo `fba`** = total de FBA del CSV (cuadre 10); la comisión no se suma al titular (sección 4); no aparece el aviso «Descuadre».
- Las 3 decisiones del chat = `data-decisiones` de la página (sección 7).
- Si falta algún costo: se ve el aviso grande arriba de la tabla y la contribución del canal dice «INCOMPLETA». Si aparece «Revisar la publicidad» (cuadre 11), se explica en el chat.
- El subtotal de **Comisión ref. %** está entre la menor y la mayor de sus renglones (sección 4).
- Formatos: moneda con `$` y miles, negativos en rojo, porcentajes reales, nunca números crudos.
- En `DATA` no queda ningún «</» sin escapar: todos van como «<\/» (v1.8.1, D62).
- No salió el alto «DATA incompleto o con valores que no son números» (v1.8.1, D63). Si salió, se corrige el dato y se vuelve a armar la página.


---


## 11. La caja del mes — reporte aparte (v1.6, regla D3 punto 4; corregido en v1.6.1, D37 y D40)


**Va en el artefacto, en su propia sección** («3 · Caja del mes · reporte aparte», con borde punteado y color verde, distinto de los cargos de cuenta): **«CAJA DEL MES — REPORTE APARTE: LIQUIDACIONES DE AMAZON MENOS COSTO DE PRODUCTO»** La plantilla lo arma con los mismos `DATA`. **No se suma a la contribución** ni la reemplaza: la contribución dice lo que deja cada producto (con el ISR devengado por producto); la caja dice cuánto dinero dejó el mes (con el ISR **cobrado**).


~~~
Ventas del mes (con IVA)                          $X   (Σ V)
− Comisión y FBA cobradas (con IVA)               $X   (Σ C + Σ F)
− Devoluciones                                           $X   (Σ DEV)
+ Ajustes y otros                                        $X   (Σ AJ)
− Cargos de cuenta del reporte, sin el ISR               $X   (tal cual, con IVA; incluye el cargo de publicidad si Amazon lo cobró)
− Retención de IVA (8%)                                  $X   (Σ IVA; aquí cuenta como salida de dinero, regla de Gerardo)
− ISR cobrado este mes (ventas del mes anterior)         $X   (renglón ISR)
= Lo que quedó de las liquidaciones de Amazon            $X   (= Σ reporte 1 sin transferencias; cuadre 8)
− Costo de producto                                      $X   (Σ CP; lo pagas tú, Amazon no lo cobra)


= RESULTADO DE CAJA DEL MES                              $X   (no es el saldo de tu banco)
Concilia: contribución del canal + ISR devengado − ISR cobrado + gasto de Ads con IVA − cargo de publicidad del reporte = resultado de caja
~~~


**v1.7 (decisión de Gerardo del 19-oct-2026 a las 10:01):** la caja solo cuenta lo que pasó por las liquidaciones de Amazon menos el costo de producto. **Efecto que se pierde:** si el vendedor paga Ads fuera de Amazon (con tarjeta), ese dinero ya no se resta en la caja del mes y la caja sale más alta (en P1 con los Ads fuera de Amazon: 1,095.15 en vez de 329.55). La caja lo dice en su rótulo. En P1 (con cargo de publicidad 846.80 en el reporte): liquidaciones 1,703.35, caja 248.35, igual que antes.


**Aviso de caja sin cargo de publicidad (D57; PRENDIDO en v1.8 por decisión de Gerardo del 19-oct-2026 a las 10:20):** si hay gasto en el archivo de Ads y el reporte no trae cargo de publicidad, la caja sale más alta. La plantilla avisa (`AVISO_CAJA_SIN_CARGO=true`): «Revisa tu caja: no encontré el cargo de publicidad en el reporte. Si pagaste $<gasto de Ads con IVA> de Ads con tarjeta, tu caja real es $<caja − gasto>, no $<caja>.» No cambia números ni decisiones. En P1 sin cargo: «Si pagaste $765.60 de Ads con tarjeta, tu caja real es $329.55, no $1,095.15.» Con cargo en el reporte no sale.


> «De lo que Amazon liquidó en <mes>, después de impuestos retenidos, te quedaron $X; menos tu costo de producto, el mes dejó $Y. **No es el saldo de tu banco.**»


**El ISR no se cuenta dos veces (D4):** en la contribución va el **devengado** del mes (por producto); en la caja va el **cobrado** (cargo del mes, ventas del mes anterior). La conciliación muestra la diferencia entre los dos. Si la conciliación no dice «cuadra», hay un dato incongruente (desde v1.6.1 la plantilla recalcula la publicidad asignada, así que ese error ya no puede pasar; si no cuadra, se avisa arriba y se corrige el dato, no la plantilla). Nunca «flujo neto», «P&L», «EBITDA», «utilidad neta».


---


## 12. Cuando falta algo


| Qué falta | Qué se hace |
|---|---|
| **Costos** | Se piden una vez antes de calcular (sección 0). En «Qué faltó» (chat y resumen) se escribe **«costos, flete y aduana»** (v1.8.9; redacción v1.8.10, D109). Si no los da: corre todo lo demás, aviso grande de qué se pierde; CP = 0 y la plantilla marca «SIN COSTO» (sin semáforo ni acción) |
| **Bulk de publicidad** | Sin ACOS ni TACOS; PUB = 0 con aviso grande «sin publicidad: la contribución está inflada por el gasto de Ads»; se omite el bloque de publicidad de marca y se dice |
| **Business Report** | Sin conversión ni cuadre de unidades; agrupación por «Agrupar con» o por SKU; se dice |
| **Fee Preview** | Los SKU salen con su código en vez de nombre; sin tarifa vigente de referencia |
| **Transacciones del mes anterior (MX)** | ISR «POR CONFIRMAR»; contribución del canal con y sin ese cargo |
| **Reporte de transacciones** | **Detiene todo.** Se explica cómo bajarlo y se espera |
| **Catálogo de 1–3 SKU** | Corre; se dice que tiers y medianas no informan |
| **Mes con muy poca venta** | Se pide otro mes |
| **Mes en curso o rango partido** | No se corre; se pide el mes cerrado completo |
| **Reporte Summary** | No se corre; se repite la ruta de Reports Repository |
| **Cargo o tipo no clasificable / columna u hoja con otro nombre** | Detiene ese cálculo y se pregunta |


**Formato del aviso:** qué falta · qué no se pudo calcular · qué sí está · cómo conseguirlo. Cada aviso va como texto en `DATA.avisos` (se muestra arriba de la tabla) y se repite en el chat.


---


## 13. Límites y honestidad


Esta skill **analiza y prepara. No ejecuta.** No cambia precios, no abre casos con Amazon (redacta el texto y la evidencia; nada sale sin OK explícito), no pausa campañas, no desactiva listings, no da asesoría fiscal. **Corre en la cuenta de Claude del vendedor; ni Summa ni Gerardo ven sus reportes.**


### Cierre en el chat


Cortito: **las 3 decisiones** con cifras y etiqueta, en el orden fijo **1 Proteger (Hacer hoy) · 2 Arreglar (Probar y medir) · 3 Detener fuga (Auditar o validar)** (sección 10, v1.8.7, D89), la línea de **parámetros fiscales** («valores vigentes documentados en la skill», o la ficha solo si el vendedor la subió; sección 2), la diferencia cobro vs gasto de publicidad, qué falta, qué se verificó (cuadres 1 a 12 con «cuadró» o el monto del descuadre; si no se pudo probar el artefacto, «No pude probar el artefacto en un navegador»). **Se dice lo que quedó y lo que no**: si un cuadre no corrió, si faltó un archivo, si un dato no se verificó, se nombra con el motivo. Al final, la pregunta de guardado (sección 15).


**Sin contradicciones con los cuadres (v1.8.3, D68):** si **algún** cuadre no dio, **nunca** se escribe «no sale ningún descuadre», «todo cuadra» ni «$0 sin clasificar» sin la salvedad; se escribe «**cuadró todo menos el N** ($X: qué es)». La línea «N transacciones revisadas, $X conciliados, $Y sin clasificar» habla solo del reporte 1 y lo dice.


**Cifras del chat = cifras de la página (v1.8.8):** si el HTML corrió, **toda** cifra del chat y del «Resumen para guardar» se copia de la página (o de su atributo `data-test`/texto), con el mismo rótulo que tiene ahí; **no se recalcula a mano** ni con otra base. En particular:


| Cifra en el chat | De dónde sale en la página | Base |
|---|---|---|
| Contribución de productos | subtotal de la tabla | incluye los renglones de `sin` |
| Contribución del canal (una o dos) | final del bloque de cargos | con el rótulo de la página |
| Ventas sin costo y su % | sección 1 (V con IVA) | Σ V sin costo ÷ Σ V de la tabla |
| Gasto SP / SB / SD | archivo de Ads | **sin IVA**, rotulado «sin IVA, tal cual el archivo de Ads» |
| Gasto de Ads con IVA y diferencia contra el cobro | nota del bloque de cargos | la de la página (redondeo por SKU), nunca (SP + SB + SD) × 1.16 de un golpe |
| ACOS de Sponsored Products y TACOS de Sponsored Products | subtotal de la tabla | solo SP; rotulados «de Sponsored Products» |
| ACOS de marca (SB/SD) y ACOS total de la cuenta | bloque de publicidad de marca | con su nombre |
| Retención de IVA % | revisión de la plantilla | ver abajo |
| Conciliados, caja | caja del mes | sin transferencias |
| Por validar | titular (solo FBA) y tarjeta de comisión | **por separado**, nunca sumados |


Si el HTML no corrió, se calcula con las mismas bases y se dice «No pude probar el artefacto en un navegador».


**Cifras fuera de la página (v1.8.10, D115):** toda cifra que no se puede copiar de la página (las del turno 1, antes de que exista; o todas, si el HTML no corrió) **se calcula con código, con la fórmula completa de la sección 3** (V de la sección 3.2, publicidad de la sección 3.3, conteos de la sección 5) y con la misma base que la plantilla. **Nunca una cuenta corta** (una sola columna, una muestra de filas, una estimación antes de leer todo el archivo). Si no se puede calcular así, no se da la cifra. Se muestra en el formato de la página (porcentajes con 1 decimal). **Una cifra del turno 2 nunca corrige una del turno 1:** si cambiaría, es un defecto; antes de enviar el turno 1 se revisa contra esta regla. **Si aun así tienes que corregir (v1.8.10, D116):** dices la base real que usaste, con los nombres de las columnas (por ejemplo, «los di con `ventas de productos` + su impuesto, sin envío, envoltura ni promociones»), la base correcta y cada cifra antes y después. Nunca una descripción aproximada de la base.


**Formato y rótulos en todo el chat (v1.8.10, D108, D113):**
- **Porcentajes con 1 decimal**, igual que la página (por ejemplo, «8.7%», no «8.66%»). La única excepción es la retención de IVA, que va con 2 decimales como en la página (D56).
- **Todo ACOS y TACOS lleva su rótulo, en cualquier parte del chat** (decisiones, alertas, números del mes y resumen; v1.8.10, D113, D117): las únicas formas permitidas son **«ACOS de Sponsored Products <x>%»**, **«TACOS de Sponsored Products <x>%»**, **«ACOS de marca (SB/SD) <x>%»** y **«ACOS total de la cuenta <x>%»**. El rótulo va **pegado** a cada palabra ACOS o TACOS, antes de su cifra, también cuando hay varias cifras seguidas. Las plantillas de texto de las decisiones y de las alertas (sección 10) usan estas formas.
- Todo monto de publicidad dice su base: «con IVA» o «sin IVA».


**Base de la retención (v1.8.3, D71):** el porcentaje y su base salen de la plantilla: base = **suma de V de la tabla ÷ (1 + tasa)**, calculada una vez y redondeada a centavos (no se suman bases por renglón). Si se escribe en el chat, se copia de la página.


**Tono (v1.8.3, D72):** saludo y cierre **neutros**: no se usa el nombre del perfil de la cuenta ni apodos si el vendedor no se presentó así. En el chat con el vendedor **no** se usa jerga interna: ni nombres de equipos o agentes internos, ni números de defecto, ni estados internos («pendiente en la ficha», «validación del contador»). Si hace falta nombrar la ficha, es «ficha de parámetros fiscales» (v1.8.4, D79). **Tampoco** nombres propios de sistemas o lugares de almacenamiento que vengan de tu contexto (línea de reglas al inicio). **El mensaje del diagnóstico termina con el bloque A de la sección 15** (resumen + pregunta de guardado) y **no lleva ninguna frase sobre si quedó guardado**; esa frase solo existe en el bloque B, en el turno siguiente, después de la respuesta del vendedor.


### Las cinco preguntas antes de entregar


1. ¿Le habla a alguien que **ya vende**? 2. ¿Muestra utilidad y control, no vanidad? 3. ¿Encontró una fuga o dinero por validar que el vendedor no vería fácil? 4. ¿Demuestra por qué hace falta un sistema completo? 5. ¿Evita promesas de dinero, cifras de trayectoria, ACOS objetivo o campañas específicas que los datos no prueban? **Si alguna sale que no, se corrige antes de entregar.**


---


## 14. Plantilla del artefacto — se usa tal cual


**Procedimiento:**


1. Calcular con los reportes (secciones 2 a 8) los datos por producto, hijos, cargos, cobros y órdenes.
2. Copiar la plantilla **completa** a un archivo `.html` y reemplazar **solo** el bloque entre `/* ===== DATOS` y `/* ===== FIN DATOS ===== */` por los datos del vendedor. **No se toca el CSS, el HTML ni el resto del JS.** Si hace falta otra columna o bloque, se avisa al dueño de la skill para una versión nueva; no se improvisa.
   - **Escapar «</» (v1.8.1, D62):** dentro de `DATA`, **«</» se escribe «<\/»** en cualquier texto (nombre de producto, de tienda, de cargo, notas, avisos). Ejemplo: `'Tienda </b>'` se escribe `'Tienda <\/b>'`. Si no, el navegador cierra el `<script>` antes de tiempo y la página sale vacía. En la página se ve igual.
   - **Solo números en los campos numéricos (v1.8.1, D63):** los montos, unidades y tasas van como números de JavaScript: sin comillas, sin comas de miles, sin «$» (`2990.00`, no `'2990.00'` ni `'2,990'`). Cada producto lleva sus 20 campos (cada hijo, 21); `pubAsignada`, `ivaTasa`, `sb.pub` y `sb.va` siempre van. Ningún campo se deja vacío ni en `null`. Si algún valor no es número, la plantilla se detiene: «Alto: DATA incompleto o con valores que no son números. No calculé nada.» y lista renglón y campo. Se corrige `DATA`, no la plantilla.
3. Probar (sección 10, «Antes de publicar») y publicar con `capabilities: {downloads: true}`.


Campos de `DATA`: `tienda`, `mes`, `periodo`, `moneda`, `muestra`, `marca` (nombre de la tienda del vendedor o vacío), `nota`; `productos` (Parent, **20 campos** en el orden del comentario; todos los costos en positivo; en MX comisión y FBA **con IVA**, tal cual el reporte; la publicidad va **sin IVA, tal cual el bulk**, y la plantilla le suma el IVA (v1.6.1); el campo «comisión %» va en 0 porque la plantilla lo recalcula como comisión ÷ ventas); `hijos` (opcional, `[parent, nombre, …20 campos]`); `sin` (`[nombre, publicidad, ventas con ads, tipo]`; tipo `'na'` para «Sponsored Products no asignable a SKU», que se muestra «NO ASIGNABLE»; vacío para sin venta); `sb` (publicidad de marca; `pub` sin IVA, tal cual el bulk); `cargos` (`[nombre, monto negativo tal cual el reporte, nota, etiqueta]`; etiqueta `'isr'` en el renglón de ISR, `'pub'` en el cargo de publicidad, vacía en los demás); `pubAsignada` (positivo = Gasto SP total del bulk, **sin IVA**; solo para comprobar la suma); `ivaTasa` (`0.16`; `0.08` solo con región fronteriza confirmada por el vendedor; sección 2); `isrConfirmado` (`true`, o `false` si el cargo sin descripción está POR CONFIRMAR); `avisos` (textos de los avisos grandes de la sección 12 —falta un archivo, descuadres—; la plantilla agrega sola los de costo faltante y publicidad); `rev` (tarjetas de revisión: `[título, texto, etiqueta, ok]`; siempre incluye «Cobro de publicidad vs gasto»); `ordenes` (`[Order ID, fecha, SKU, concepto, cobrado, esperado, diferencia, etiqueta, unidades, ASIN, base del esperado, validación previa, recomendación, texto del caso, tipo]`; los campos 10 a 15 son de la v1.8.5 (C1) y son texto; tipo `'fba'` o `'com'`; solo órdenes con diferencia positiva, montos tal cual el reporte).


~~~html
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Profit AI System Diagnóstico Amazon</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root{
  color-scheme:dark;
  --bg:#0A0A0A; --panel:#111111; --panel2:#171717; --line:#222222; --line2:#333333;
  --accent:#FF6B00; --accent-soft:#FFB347; --on-accent:#0A0A0A;
  --fg:#FFFFFF; --fg2:#A0A0A0; --fg3:#666666;
  --ok:#35B37E; --warn:#E5A03C; --bad:#E5484D;
  --ui:'Inter',system-ui,-apple-system,'Segoe UI',sans-serif;
  --mono:'JetBrains Mono',ui-monospace,Menlo,Consolas,monospace;
}
*{box-sizing:border-box}
body{background:var(--bg);color:var(--fg);font-family:var(--ui);font-size:14px;line-height:1.55;margin:0}
.num{font-family:var(--mono);font-variant-numeric:tabular-nums}
.neg{color:var(--bad)}
.gut{padding-inline:max(16px,3vw)}
.wrap{width:100%;max-width:1280px;margin:0 auto;min-width:0}
section,main,.gut{min-width:0}
.tw{max-width:100%}
h1,h2,h3,p{margin:0;text-wrap:balance}
.bar{position:sticky;top:env(safe-area-inset-top,0px);z-index:20;background:rgba(10,10,10,.94);border-bottom:1px solid var(--line);backdrop-filter:blur(6px)}
.bar .wrap{display:flex;align-items:center;gap:12px;padding-block:9px}
.bar .nm{font-weight:800;letter-spacing:.06em;font-size:13px;white-space:nowrap}
.bar .nm i{font-style:normal;color:var(--accent)}
.bar .sub{color:var(--fg2);font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}
.bar .sp{flex:1}
.bar .mu:empty{display:none}
.bar .mu{font-family:var(--mono);font-size:10.5px;letter-spacing:.12em;color:var(--on-accent);background:var(--accent-soft);padding:3px 8px;border-radius:3px;font-weight:700;white-space:nowrap}
.logo{width:30px;height:30px;flex:none;display:block}
.hero{border-bottom:1px solid var(--line);position:relative;padding-block:34px 30px}
.hero::before{content:'';position:absolute;left:0;right:0;top:0;height:3px;background:var(--accent)}
.lock{display:flex;align-items:center;gap:16px;flex-wrap:wrap}
.lock .logo{width:68px;height:68px}
.lock .wm{display:flex;flex-direction:column;line-height:1}
.lock .wm b{font-size:clamp(34px,6vw,60px);font-weight:900;letter-spacing:-.02em}
.lock .wm span{font-family:var(--mono);font-weight:700;color:var(--accent);letter-spacing:.42em;font-size:clamp(12px,1.9vw,19px);margin-top:8px}
.hero h1{font-size:clamp(20px,3vw,30px);font-weight:700;margin-top:26px;letter-spacing:-.01em}
.hero .tag{color:var(--fg2);margin-top:6px;font-size:15px;max-width:70ch}
.hero .tag b{color:var(--fg)}
.facts{display:flex;flex-wrap:wrap;gap:8px 10px;margin-top:20px}
.fact{border:1px solid var(--line2);background:var(--panel);padding:6px 12px;border-radius:4px;font-size:12px;color:var(--fg2)}
.fact b{color:var(--fg);font-weight:600}
.fact.br{border-color:var(--accent);color:var(--accent-soft)}
.fact.br b{color:var(--accent-soft)}
main{display:flex;flex-direction:column;gap:44px;padding-block:32px 40px}
.sh{display:flex;flex-direction:column;gap:4px;margin-bottom:16px}
.eyebrow{font-size:11px;letter-spacing:.16em;text-transform:uppercase;color:var(--accent);font-weight:700}
.sh h2{font-size:22px;font-weight:800;letter-spacing:-.01em}
.sh p{color:var(--fg2);max-width:78ch}
.ctl{display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;margin-bottom:12px}
.seg{display:inline-flex;border:1px solid var(--line2);border-radius:6px;padding:3px;background:var(--panel)}
.seg button{font-family:var(--ui);font-size:13px;font-weight:600;color:var(--fg2);background:transparent;border:0;padding:8px 16px;border-radius:4px;cursor:pointer;display:flex;gap:8px;align-items:center}
.seg button .c{font-family:var(--mono);font-size:11px;color:var(--fg3)}
.seg button[aria-selected="true"]{background:var(--accent);color:var(--on-accent)}
.seg button[aria-selected="true"] .c{color:var(--on-accent)}
.seg.sm button{font-size:12px;padding:6px 12px}
button:focus-visible,th.sort:focus-visible{outline:2px solid var(--accent-soft);outline-offset:2px}
.callout{border:1px solid var(--warn);background:#1a1407;border-radius:4px;padding:11px 14px;font-size:13px;color:#d9cdb3;display:flex;gap:12px;align-items:center;justify-content:space-between;flex-wrap:wrap;margin-bottom:12px}
.callout b{color:var(--fg)}
.lk{font-family:var(--ui);background:transparent;border:1px solid var(--warn);color:var(--warn);padding:5px 12px;border-radius:4px;font-weight:600;font-size:12px;cursor:pointer}
.tw{overflow:auto;max-height:76vh;border:1px solid var(--line);border-radius:6px;background:var(--panel)}
table.big{border-collapse:separate;border-spacing:0;font-size:12.5px;min-width:100%}
table.big th,table.big td{padding:8px 11px;white-space:nowrap;text-align:right;border-bottom:1px solid var(--line);border-right:1px solid #1a1a1a;background:var(--panel)}
table.big thead th{position:sticky;background:#0e0e0e;color:var(--fg2);font-weight:600;font-size:11.5px;z-index:2}
table.big thead tr:first-child th{top:0;color:var(--accent);letter-spacing:.12em;font-size:10.5px;text-align:center;border-bottom:1px solid var(--line2);z-index:3;font-weight:700}
table.big thead tr:nth-child(2) th{top:29px;border-bottom:1px solid var(--line2)}
table.big th.sort{cursor:pointer;user-select:none}
table.big th.sort:hover{color:var(--fg)}
table.big th.sort[data-d="1"]::after{content:' ▲';color:var(--accent)}
table.big th.sort[data-d="-1"]::after{content:' ▼';color:var(--accent)}
table.big td.pn,table.big th.pn{position:sticky;left:0;text-align:left;z-index:1;min-width:170px;max-width:260px;white-space:normal;border-right:1px solid var(--line2)}
table.big thead th.pn{z-index:4}
table.big td.pn{font-weight:600}
table.big td small.sob{display:block;font-size:10px;font-weight:600;color:var(--warn);white-space:nowrap}
table.big td.pn small{display:block;font-weight:500;font-size:11px;color:var(--fg3)}
table.big td.pn .pill{display:inline-block;margin-top:3px;font-size:10px;font-weight:700;color:var(--warn);border:1px solid var(--warn);border-radius:99px;padding:1px 7px}
table.big td.acc{white-space:normal;min-width:190px;max-width:240px;text-align:left;color:var(--fg2);font-size:12px}
table.big tr.sub td{background:var(--panel2);font-weight:700;border-top:1px solid var(--line2)}
table.big tr.tot td{background:#1b1208;font-weight:700;border-top:1px solid var(--accent)}
table.big tr.sub td.pn,table.big tr.tot td.pn{background:inherit}
table.big tr.nv td{color:var(--fg3)}
.sem{display:inline-block;font-size:10.5px;font-weight:800;padding:2px 8px;border-radius:3px;letter-spacing:.03em;color:#0A0A0A}
.s-ss{background:#2FD38F}.s-sano{background:var(--ok)}.s-ac{background:#B9C24A}.s-rev{background:var(--warn)}.s-pel{background:#F0714F}.s-pi{background:var(--bad);color:#fff}
.vol{font-size:10.5px;font-weight:700;color:var(--fg2);letter-spacing:.07em}
.vol.core{color:var(--accent-soft)}
.legend{display:flex;flex-wrap:wrap;gap:8px 16px;align-items:center;margin-top:12px;font-size:12px;color:var(--fg2)}
.legend .g{display:flex;gap:6px;align-items:center}
.legend .t{color:var(--fg3);font-size:11px}
.ct{white-space:pre-wrap;font-family:inherit;font-size:12px;max-width:420px;margin:6px 0 0}
.avm summary{cursor:pointer;color:var(--warn);font-weight:600;font-size:13px;padding:4px 0}
.avm .warnbox{margin-top:8px}
.note{font-size:12px;color:var(--fg3);margin-top:8px;max-width:110ch}
.chg{background:var(--panel);border:1px solid var(--line);border-radius:6px;overflow:hidden}
.chg h3{margin:0;padding:12px 16px;background:#1b1208;border-bottom:1px solid var(--accent);color:var(--accent-soft);font-size:12px;letter-spacing:.12em;font-weight:800}
.chg .r{display:flex;justify-content:space-between;gap:16px;padding:10px 16px;border-bottom:1px solid var(--line);font-size:13.5px;color:var(--fg)}
.chg .r span:last-child{font-family:var(--mono);font-variant-numeric:tabular-nums;white-space:nowrap}
.chg .r small{color:var(--fg3);font-size:11.5px;margin-left:6px}
.chg .r.cr span:last-child{color:var(--ok)}
.chg .r.tt{background:#1b1208;font-weight:800;border-top:1px solid var(--accent);border-bottom:0}
.chg.sb{margin-top:14px}
.chg.cj{border:1px dashed var(--ok);background:#0d1712}
.chg.cj h3{background:#0f2018;border-bottom:1px solid var(--ok);color:#7FE0B0}
.chg.cj .r.tt{background:#0f2018;border-top:1px solid var(--ok)}
.chg.cj .r.liq{background:#0f2018;font-weight:700}
.chg .sbx{display:flex;flex-wrap:wrap;gap:8px 28px;padding:12px 16px;font-size:13.5px}
.chg .sbx b{font-family:var(--mono);font-variant-numeric:tabular-nums}
.pay{background:var(--panel);border:1px solid var(--line);border-radius:6px;padding:20px;display:flex;flex-direction:column;gap:16px}
.pay .top{display:flex;flex-wrap:wrap;gap:16px;align-items:center;justify-content:space-between}
.pay .big{font-family:var(--mono);font-size:36px;font-weight:700;color:var(--accent-soft);line-height:1.1}
.pay .big small{display:block;font-family:var(--ui);font-size:12px;font-weight:500;color:var(--fg2);margin-top:4px}
.btn{font-family:var(--ui);font-weight:800;font-size:14px;background:var(--accent);color:var(--on-accent);border:0;padding:13px 22px;border-radius:5px;cursor:pointer;display:inline-flex;align-items:center;gap:10px}
.btn[disabled]{opacity:.5;cursor:default}
.btn svg{width:18px;height:18px}
.msg{font-size:12.5px;color:var(--fg2);min-height:18px}
table.s{border-collapse:collapse;width:100%;font-size:13px}
table.s th,table.s td{padding:10px 12px;border-bottom:1px solid var(--line);text-align:right;white-space:nowrap}
table.s th:first-child,table.s td:first-child{text-align:left}
table.s td.l,table.s th.l{text-align:left;white-space:normal}
table.s th{font-weight:600;color:var(--fg2);font-size:11.5px;letter-spacing:.04em}
.chip{display:inline-block;font-size:11px;font-weight:600;border:1px solid var(--warn);color:var(--warn);padding:2px 9px;border-radius:99px}
.chip.ok{border-color:var(--line2);color:var(--fg2)}
.sc{overflow-x:auto;max-width:100%}
.warnbox{border-left:3px solid var(--accent);background:var(--panel2);padding:12px 14px;font-size:13px;color:var(--fg2);border-radius:0 4px 4px 0}
.warnbox b{color:var(--fg)}
.chk{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:10px}
.chk div{border:1px solid var(--line);border-radius:4px;padding:10px 12px;font-size:12.5px;color:var(--fg2);display:flex;flex-direction:column;gap:3px}
.chk b{color:var(--fg);font-size:12.5px}
footer{border-top:1px solid var(--line);padding-block:26px 40px}
footer .wrap{display:flex;flex-wrap:wrap;gap:16px;align-items:center;justify-content:space-between}
footer .l{display:flex;align-items:center;gap:12px}
footer .l .logo{width:38px;height:38px}
footer .nm{font-weight:900;letter-spacing:.05em;font-size:15px}
footer .nm i{font-style:normal;color:var(--accent)}
footer .by{color:var(--fg2);font-size:12px}
footer .pf{font-weight:700;color:var(--accent-soft);font-size:13px;border:1px solid var(--accent);padding:7px 14px;border-radius:4px}
@media (max-width:640px){.bar .sub{display:none}.lock .logo{width:52px;height:52px}}
</style>


<svg width="0" height="0" style="position:absolute" aria-hidden="true">
  <symbol id="mark" viewBox="0 0 64 64">
    <rect width="64" height="64" rx="12" fill="#FF6B00"/>
    <rect x="12" y="38" width="9" height="14" rx="1.5" fill="#0A0A0A"/>
    <rect x="27" y="29" width="9" height="23" rx="1.5" fill="#0A0A0A"/>
    <rect x="42" y="18" width="9" height="34" rx="1.5" fill="#0A0A0A"/>
    <path d="M12 27 L28 17 L36 21 L52 9" fill="none" stroke="#0A0A0A" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M44 9 H52 V17" fill="none" stroke="#0A0A0A" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
  </symbol>
</svg>


<div class="bar gut">
  <div class="wrap">
    <svg class="logo" aria-hidden="true"><use href="#mark"/></svg>
    <span class="nm">PROFIT <i>AI SYSTEM</i></span>
    <span class="sub" id="bsub">Diagnóstico de Rentabilidad Amazon · por Gerardo Villa</span>
    <span class="sp"></span>
    <span class="mu" id="mu"></span>
  </div>
</div>


<header class="hero gut">
  <div class="wrap">
    <div class="lock">
      <svg class="logo" role="img" aria-label="Profit AI System"><use href="#mark"/></svg>
      <div class="wm"><b>PROFIT</b><span>AI SYSTEM</span></div>
    </div>
    <h1>Diagnóstico de Rentabilidad Amazon · por Gerardo Villa</h1>
    <p class="tag"><b>Seller Central te da datos. Este diagnóstico te da decisiones.</b> Qué producto deja dinero, cuál se lo lleva y qué cobros de Amazon merecen revisión.</p>
    <div class="facts" id="facts"></div>
    <div class="facts"><span class="fact">Corrió en tu propia cuenta de Claude. Ni Summa ni Gerardo ven tus reportes.</span></div>
  </div>
</header>


<main class="gut">
<div class="wrap" style="display:flex;flex-direction:column;gap:44px">


<section id="productos" aria-label="Rentabilidad por producto">
  <div class="sh">
    <span class="eyebrow">1 · Tus productos</span>
    <h2>Qué producto deja dinero y cuál se lo lleva</h2>
    <p>Empieza por Parent. Cambia a Child cuando un Parent esconda una variante que arrastra el resultado.</p>
  </div>
  <div id="avisos" style="display:flex;flex-direction:column;gap:8px"></div>
  <div class="ctl">
    <div class="seg" role="tablist" aria-label="Nivel de producto">
      <button role="tab" id="tp" aria-selected="true" data-view="parent">Parent <span class="c" id="cp"></span></button>
      <button role="tab" id="tc" aria-selected="false" data-view="child">Child <span class="c" id="cc"></span></button>
    </div>
    <div class="seg sm" role="group" aria-label="Columnas">
      <button aria-selected="true" data-cols="key">Columnas clave</button>
      <button aria-selected="false" data-cols="all">Todas las columnas</button>
    </div>
  </div>
  <div id="co"></div>
  <div class="tw"><table class="big" id="big"></table></div>
  <div class="legend" id="legend"></div>
  <p class="note">ACOS y TACOS de la tabla miden solo Sponsored Products (gasto y ventas con IVA; el ACOS total de la cuenta está en el bloque de marca); la publicidad de marca se muestra aparte, no baja a producto y ya está dentro de los cargos de cuenta. La contribución del canal está al final de «Cargos de cuenta»: no sumes la tabla con los cargos a mano. Los porcentajes se recalculan desde los totales. Haz clic en un encabezado para ordenar. Los subtotales no llevan Volumen ni Acción.</p>
</section>


<section id="cargos" aria-label="Cargos de cuenta">
  <div class="sh"><span class="eyebrow">2 · Cargos de cuenta</span><h2>Lo que Amazon cobra y no baja a ningún producto</h2></div>
  <div id="cg"></div>
</section>


<section id="caja" aria-label="Caja del mes, reporte aparte">
  <div class="sh"><span class="eyebrow" style="color:var(--ok)">3 · Caja del mes · reporte aparte</span><h2>Cuánto dinero dejó el mes, aparte de la contribución</h2><p>No se suma ni se compara con la contribución del canal: es otra pregunta. Aquí va el ISR que Amazon cobró este mes y no el devengado.</p></div>
  <div id="cj"></div>
</section>


<section id="cobros" aria-label="Cobros por validar">
  <div class="sh">
    <span class="eyebrow">4 · Cobros de Amazon</span>
    <h2>Lo que Amazon pudo haberte cobrado de más</h2>
    <p>Solo el mes analizado. Cada renglón es una posible diferencia que hay que validar, no un reembolso.</p>
  </div>
  <div class="pay">
    <div class="top">
      <div class="big num"><span id="vt"></span><small id="vs"></small></div>
      <div style="display:flex;flex-direction:column;gap:8px;align-items:flex-start">
        <button class="btn" id="dl" type="button" disabled>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v12m0 0l-5-5m5 5l5-5M4 20h16"/></svg>
          Descargar expediente de cobros (CSV)
        </button>
        <span class="msg" id="dm" role="status"></span>
        <details><summary style="cursor:pointer;color:var(--fg2);font-size:12.5px">¿No se descarga? Ver el CSV para copiarlo</summary><textarea id="csvt" readonly style="width:min(560px,90vw);height:140px;background:var(--panel2);color:var(--fg);border:1px solid var(--line2);font-family:var(--mono);font-size:11px"></textarea></details>
      </div>
    </div>
    <div class="warnbox">Vimos <b id="vt2"></b> que Amazon podría haberte cobrado de más en el mes analizado. Aún hay que revisar producto por producto antes de reclamarlo. <b>No es dinero garantizado.</b> Si se confirma, ya tienes la información para pedirle a Amazon que revise el cobro.</div>
    <div class="sc"><table class="s" id="vtab"></table></div>
    <div class="chk" id="rev"></div>
    <p class="note" style="margin:0">Ruta del caso: Ayuda › Obtener soporte › Vender en Amazon › <b>Reconcile Charges</b> › Review Fees › Order ID › Contact an associate › pestaña <b>Email</b> (nunca por chat: necesitas adjuntos y rastro escrito). Si un SKU cobra de más de forma sistemática, suele ser peso o dimensiones mal medidos: usa FBA product weights and dimensions. Sistema que resuelve esto: Auditoría y Recuperación Amazon. No se manda nada a Amazon sin tu OK.</p>
  </div>
</section>


</div>
</main>


<footer class="gut">
  <div class="wrap">
    <div class="l">
      <svg class="logo" aria-hidden="true"><use href="#mark"/></svg>
      <div><div class="nm">PROFIT <i>AI SYSTEM</i></div><div class="by">Diagnóstico de Rentabilidad Amazon · por Gerardo Villa</div></div>
    </div>
    <div class="l" id="contacto"></div>
  </div>
</footer>


<script>
(function(){
'use strict';
var $=function(i){return document.getElementById(i)};
/* v1.8.1 (D64): se redondea antes de formatear: primero a centavos (quita el error de punto flotante, 28,661.4999 → 28,661.50) y luego mitad hacia arriba (28,661.50 → $28,662), no redondeo bancario */
var fm=function(n,d){d=d==null?0:d;var a=Math.abs(n);if(d<=2){a=Math.round(a*100+1e-6)/100;if(d<2){var p=Math.pow(10,d);a=Math.floor(a*p+0.5+1e-9)/p}}var s=a.toLocaleString('es-MX',{minimumFractionDigits:d,maximumFractionDigits:d});return (n<0?'-':'')+'$'+s};
var fp=function(n,d){d=d==null?1:d;return (n*100).toFixed(d)+'%'};
/* v1.7.1 (D56): porcentaje de la retención con 2 decimales redondeados (4%, 8% y 16% exactos se ven «4.00%», «8.00%», «16.00%»). El alto se decide en pesos (D51) y el aviso dice el rango en pesos (D55) */
var fpt=function(n){return (Math.round(n*1e6)/1e4).toFixed(2)+'%'};
var neg=function(n,h){return n<0?'<span class="neg">'+h+'</span>':h};
var hx=function(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;')};


/* ===== DATOS: la skill reemplaza SOLO este bloque con los números del vendedor ===== */
var DATA={
 tienda:'Amazon México', mes:'agosto 2026', periodo:'1 a 31 de agosto de 2026', moneda:'MXN', muestra:false,
 marca:'', /* nombre de la tienda o marca del vendedor, tal como lo escribió; vacío si no lo dio */
 nota:'Costo de producto puesto en tu bodega, confirmado por ti',
 /* productos (Parent): 20 campos en este orden (sección 3 de la skill):
    [nombre, uds de pedido, pub SP (gasto del bulk TAL CUAL, SIN IVA: la plantilla le suma el IVA), ventas con ads, ventas (MX con IVA), costo unit, comisión % (poner 0: la plantilla lo recalcula), comisión $ (MX: TAL CUAL el reporte, con IVA), FBA $/u (con IVA en MX), FBA total (MX: TAL CUAL el reporte, con IVA), costo producto (0 si no hay costo), devoluciones (positivo = costo), ajustes y otros (con signo), retención de IVA 8% (positivo, tal cual el reporte), ISR devengado (positivo), FBA debería ser, dif FBA, por validar $ (estos tres TAL CUAL el reporte, con IVA en MX), uds a revisar, uds netas]
    v1.6 (D3): en MX TODO va con IVA, en una sola base. v1.6.1 (D41): la publicidad se pone SIN IVA, tal cual el bulk; la plantilla la multiplica por (1 + ivaTasa).
    Todos los costos van en POSITIVO. Solo 'ajustes y otros' y 'dif FBA' llevan signo. Fórmulas: sección 3.2 y 4 de la skill. */
 productos:[],
 /* hijos (Child), opcional: [parent, nombre, ...mismos 20 campos] */
 hijos:[],
 /* sin venta / sin clasificar: [nombre, publicidad (tal cual el bulk, SIN IVA), ventas con ads, tipo] · tipo: 'na' = no asignable (p. ej. SP no asignable a SKU), '' = sin venta */
 sin:[],
 /* publicidad de marca SB/SD: no baja a producto. pub = gasto del bulk TAL CUAL, SIN IVA (la plantilla le suma el IVA) */
 sb:{pub:0,va:0},
 /* cargos de cuenta, de mayor a menor: [nombre, monto negativo tal cual el reporte, nota opcional, etiqueta] · etiqueta: 'isr' en el renglón de ISR, 'pub' en el cargo de publicidad, '' en los demás */
 cargos:[],
 pubAsignada:0, /* gasto SP total del bulk TAL CUAL, SIN IVA (Σ pub de los SKU + SP no asignable). Solo se usa para comprobar; la plantilla recalcula la publicidad asignada con IVA */
 ivaTasa:0.16, /* v1.6.1 (D38): tasa de IVA del vendedor: 0.16 general; 0.08 SOLO si el vendedor confirmó que vende con el estímulo de región fronteriza. */
 isrConfirmado:true, /* false si el cargo sin descripción no se pudo confirmar como ISR (sección 2) */
 avisos:[], /* avisos grandes de la skill (falta un archivo, descuadres…), uno por texto; se muestran arriba de la tabla */
 /* revisión de cobros: [título, texto, etiqueta, ok(true/false)] */
 rev:[],
 /* detalle por orden (cobros por validar), tal cual el reporte (con IVA en MX): [Order ID, fecha, SKU, concepto, cobrado, esperado, diferencia, etiqueta, unidades] */
 ordenes:[]
};
/* ===== FIN DATOS ===== */
/* v1.7.1 (D59): respaldo. Si la moneda no es MXN, la plantilla se detiene: esta skill es solo para Amazon México */
if(String(DATA.moneda==null?'':DATA.moneda).trim().toUpperCase()!=='MXN'){var _m=String(DATA.moneda==null?'':DATA.moneda).replace(/[&<>"']/g,'');document.body.innerHTML='<div class="warnbox" style="margin:24px"><b>Alto: esta herramienta es solo para Amazon México.</b> Los datos vienen en moneda «'+_m+'», no en pesos mexicanos (MXN). No calculé nada. Si tu tienda es de Amazon Estados Unidos, se analiza con otra herramienta.</div>';document.body.setAttribute('data-alto','moneda');return;}
/* v1.8.1 (D63): alto si algún valor numérico de DATA no es número (texto, «2,990», columna faltante, valor vacío, null, NaN). No se calcula nada */
var DATA_ERR=(function(){var e=[],nu=function(v){return typeof v==='number'&&isFinite(v)},
 F=['uds de pedido','pub SP','ventas con ads','ventas','costo unit','comisión %','comisión $','FBA $/u','FBA total','costo producto','devoluciones','ajustes y otros','retención de IVA','ISR devengado','FBA debería ser','dif FBA','por validar $','uds a revisar','uds netas'],
 sh=function(v){return v===undefined?'vacío o falta':v===null?'null':typeof v==='string'?'«'+v+'» (texto)':String(v)},
 fila=function(lista,r,k,nom,off){if(!Array.isArray(r)){e.push(lista+' renglón '+(k+1)+': no es una lista');return}
  if(r.length!==20+off)e.push(lista+' renglón '+(k+1)+' «'+nom+'»: trae '+r.length+' campos y deben ser '+(20+off));
  for(var c=1;c<20;c++){if(!(c+off in r)||!nu(r[c+off]))e.push(lista+' «'+nom+'», campo '+(c+1)+' ('+F[c-1]+'): '+sh(r[c+off]))}},
 arr=function(k){if(!Array.isArray(DATA[k])){e.push(k+': falta o no es una lista');return []}return DATA[k]};
 arr('productos').forEach(function(r,k){fila('productos',r,k,Array.isArray(r)?r[0]:'',0)});
 (DATA.hijos==null?[]:arr('hijos')).forEach(function(r,k){fila('hijos',r,k,Array.isArray(r)?r[0]+' · '+r[1]:'',1)});
 arr('sin').forEach(function(r,k){if(!Array.isArray(r)){e.push('sin renglón '+(k+1)+': no es una lista');return}[1,2].forEach(function(c){if(!nu(r[c]))e.push('sin «'+r[0]+'», campo '+(c+1)+' ('+(c===1?'publicidad':'ventas con ads')+'): '+sh(r[c]))})});
 if(!DATA.sb||typeof DATA.sb!=='object')e.push('sb: falta');else ['pub','va'].forEach(function(c){if(!nu(DATA.sb[c]))e.push('sb.'+c+': '+sh(DATA.sb[c]))});
 arr('cargos').forEach(function(r,k){if(!Array.isArray(r)){e.push('cargos renglón '+(k+1)+': no es una lista');return}if(!nu(r[1]))e.push('cargos «'+r[0]+'», monto: '+sh(r[1]))});
 (DATA.ordenes==null?[]:arr('ordenes')).forEach(function(r,k){if(!Array.isArray(r)){e.push('ordenes renglón '+(k+1)+': no es una lista');return}[[4,'cobrado'],[5,'esperado'],[6,'diferencia'],[8,'unidades']].forEach(function(c){if(!nu(r[c[0]]))e.push('ordenes «'+r[0]+'», '+c[1]+': '+sh(r[c[0]]))})});
 if(!nu(DATA.pubAsignada))e.push('pubAsignada: '+sh(DATA.pubAsignada));
 if(!nu(DATA.ivaTasa))e.push('ivaTasa: '+sh(DATA.ivaTasa));
 if(!Array.isArray(DATA.rev))e.push('rev: falta o no es una lista');
 return e})();
if(DATA_ERR.length){document.body.innerHTML='<div class="warnbox" style="margin:24px"><b>Alto: DATA incompleto o con valores que no son números.</b> No calculé nada. Hay que corregir el bloque DATA (los números van sin comas de miles, sin «$» y sin comillas; cada producto lleva sus 20 campos) y volver a armar la página. Revisa:<ul>'+DATA_ERR.slice(0,30).map(function(x){return '<li>'+hx(x)+'</li>'}).join('')+'</ul>'+(DATA_ERR.length>30?'<p>…y '+(DATA_ERR.length-30)+' más.</p>':'')+'</div>';document.body.setAttribute('data-alto','datos');return;}
/* v1.7: la skill es solo para Amazon México */
/* v1.6.1 (D38): tasa de IVA parametrizada (0.16 general; 0.08 región fronteriza confirmada). FIVA es el único factor de IVA de toda la plantilla */
var IVA_T=(DATA.ivaTasa==null?0.16:+DATA.ivaTasa), FIVA=1+IVA_T, IVA_RARA=!(Math.abs(IVA_T-0.16)<1e-9||Math.abs(IVA_T-0.08)<1e-9);
var FTXT=FIVA.toFixed(2);
/* v1.6.2 (D43): la factura de Amazon Ads es de Amazon, a la tasa general (16%), aunque el vendedor sea de región fronteriza. ivaTasa solo toca las bases de impuestos del vendedor */
var FPUB=1.16, PTXT=FPUB.toFixed(2);
var c2=function(n){return Math.round((n+(n>=0?1e-9:-1e-9))*100)/100};
/* v1.6.1 (D41): la publicidad llega SIN IVA, tal cual el bulk; aquí se le suma el IVA, renglón por renglón, redondeado a centavos */
var conIva=function(n){return c2((+n||0)*FPUB)};
var PUB_RAW=DATA.productos.reduce(function(a,r){return a+(+r[2]||0)},0)+DATA.sin.reduce(function(a,r){return a+(+r[1]||0)},0);
var P=DATA.productos.map(function(r){var x=r.slice();x[2]=conIva(r[2]);x[3]=conIva(r[3]);
  /* v1.8.4 (D81): si el Parent trae sus variantes y suman lo mismo, el IVA de la publicidad se redondea por variante (SKU) y el Parent es la suma; así cuadra con el total por SKU */
  var hs=(DATA.hijos||[]).filter(function(h){return h[0]===r[0]});
  if(hs.length>1){var sp=hs.reduce(function(a,h){return a+(+h[3]||0)},0),sv=hs.reduce(function(a,h){return a+(+h[4]||0)},0);
    if(Math.abs(sp-(+r[2]||0))<0.005)x[2]=c2(hs.reduce(function(a,h){return a+conIva(h[3])},0));
    if(Math.abs(sv-(+r[3]||0))<0.005)x[3]=c2(hs.reduce(function(a,h){return a+conIva(h[4])},0))}
  return x}); /* v1.8.3 (E3, Gerardo 20-oct-2026): IVA al gasto Y a las ventas con ads; el ACOS no cambia por el IVA */
var NA_NEG=0; /* v1.8.3 (D69): un «no asignable» negativo no suma contribución */
var SIN=DATA.sin.map(function(r){var x=r.slice();x[1]=conIva(r[1]);x[2]=conIva(r[2]);if(r[3]==='na'&&x[1]<0){NA_NEG+=x[1];x[1]=0}return x});
var HIJOS=(DATA.hijos||[]).map(function(h){var x=h.slice();x[3]=conIva(h[3]);x[4]=conIva(h[4]);return x});
var SBD={pub:conIva(DATA.sb.pub),va:conIva(DATA.sb.va)};
/* v1.7 (Gerardo, 19-oct-2026 10:01): ya no se pregunta cómo se paga la publicidad. La publicidad de la rentabilidad sale SIEMPRE del archivo de Ads × 1.16 */


function ent(o){
  o.acos=o.va&&o.pub? o.pub/o.va:null; o.tacos=o.v&&o.pub? o.pub/o.v:null; o.precio=o.u? o.v/o.u:null;
  o.ct=o.c$+o.ft+o.cpr; o.ub=o.v-o.ct; o.un=o.ub-o.pub; o.pu=o.v? o.un/o.v:null;
  o.con=o.un-o.dev+o.aj-o.iva-o.isr; o.pf=o.v>0? o.con/o.v:null; o.cx=o.unet>0? o.con/o.unet:null;
  o.nosale=!(o.v>0)||!(o.unet>0); o.nocost=!o.nosale&&!(o.cpr>0);
  o.ret=(o.nosale||o.nocost)? null : o.con/o.cpr; /* v1.4: sin costo o sin venta neta no hay retorno (D1, D11) */
  o.cp=o.v>0? o.c$/o.v:null; /* v1.6 (D3): comisión % = comisión con IVA ÷ ventas con IVA en MX (misma base). Una sola fórmula para productos, hijos y subtotales */
  o.fu=o.u>0? o.ft/o.u:o.fu; return o;
}
var mk=function(r,n){return ent({n:n,u:r[1],pub:r[2],va:r[3],v:r[4],cu:r[5],cp:r[6],c$:r[7],fu:r[8],ft:r[9],cpr:r[10],dev:r[11],aj:r[12],iva:r[13],isr:r[14],fd:r[15],df:r[16],val:r[17],vu:r[18],unet:(r[19]==null?r[1]:r[19])})};
var T=P.map(function(r){return mk(r,r[0])});
var sumK=function(a,k){return a.reduce(function(s,r){return s+r[k]},0)};
var sinPub=SIN.reduce(function(a,r){return a+r[1]},0), sinVa=SIN.reduce(function(a,r){return a+r[2]},0);
var S={n:'Subtotal productos (solo Sponsored Products)',u:sumK(T,'u'),pub:sumK(T,'pub')+sinPub,va:sumK(T,'va')+sinVa,v:sumK(T,'v'),c$:sumK(T,'c$'),ft:sumK(T,'ft'),cpr:sumK(T,'cpr'),dev:sumK(T,'dev'),aj:sumK(T,'aj'),iva:sumK(T,'iva'),isr:sumK(T,'isr'),fd:sumK(T,'fd'),df:sumK(T,'df'),val:sumK(T,'val'),vu:sumK(T,'vu'),unet:sumK(T,'unet')};
var UPOS=T.reduce(function(a,r){return a+(r.unet>0?r.unet:0)},0);
S.unet=UPOS; S.cu=UPOS>0? S.cpr/UPOS:null; ent(S); /* v1.4 (D11): el costo unitario del subtotal usa solo unidades netas positivas */ S.tot=true;
var N_SIN_COSTO=T.filter(function(r){return r.nocost}).length, FALTA_COSTO=N_SIN_COSTO>0;
if(FALTA_COSTO){S.ret=null} /* v1.4: si algún producto con venta no tiene costo, el retorno del subtotal no se calcula (D1) */
var CONTOT=S.con;
/* v1.6.1 (D41): publicidad asignada con IVA = Σ PUB (con IVA) + SP no asignable (con IVA), calculada aquí */
var PUB_ASIG=c2(sumK(T,'pub')+sinPub);
var PUB_DESC=DATA.pubAsignada!=null&&Math.abs(PUB_RAW-DATA.pubAsignada)>0.005; /* el total SP del bulk no es la suma de los renglones */
/* v1.6.1 (D38): retención de IVA y base del ISR con la tasa del vendedor */
var VSIN=S.v/FIVA;
/* v1.6.3 (D50): con una tasa de IVA no válida no se corren las revisiones de retención ni de ISR. D48 (retención en 0): opción B desde v1.7 (aviso y POR VALIDAR) */
var RET_PCT=(!IVA_RARA&&VSIN>0&&S.iva>0)?S.iva/VSIN:null;
/* v1.6.3 (D51): los bordes se comparan en pesos, con tolerancia de medio centavo */
var enRet=function(a,b){return S.iva>=a*VSIN-0.005&&S.iva<=b*VSIN+0.005};
/* v1.6.4 (D55): rango en pesos de la retención esperada, al centavo, para mostrarlo junto al porcentaje */
/* v1.8 (D60): el rango en pesos se calcula para la franja que corresponde (8% o 4%), con la misma tolerancia de medio centavo que decide el alto */
var RANGO_PESOS=function(a,b){return [Math.ceil(Math.round((a*VSIN-0.005)*1e6)/1e4)/100,Math.floor(Math.round((b*VSIN+0.005)*1e6)/1e4)/100]};
var txtRango=function(a,b){var r=RANGO_PESOS(a,b);return 'de '+fm(r[0],2)+' a '+fm(r[1],2)};
/* v1.8.1 (D61): con la tasa general (16%), el aviso de retención rara también dice el rango de región fronteriza (4%), para que se vea aunque la retención quede a un centavo de esa franja */
var RET_RANGO=function(){return ' (retención '+fm(S.iva,2)+': fuera del rango esperado con '+fp(RET_ESP,2)+', '+txtRango(RET_ESP-0.001,RET_ESP+0.001)+(Math.abs(IVA_T-0.16)<1e-9?'; el de región fronteriza, 4.00%, es '+txtRango(0.039,0.041):'')+')'};
var RANGO_FRONT=function(){return ' (retención '+fm(S.iva,2)+': dentro del rango de región fronteriza, 4.00%, '+txtRango(0.039,0.041)+'; con 8.00% tendría que estar '+txtRango(0.079,0.081)+')'};
var RANGO_MEZCLA=function(){return ' (retención '+fm(S.iva,2)+': entre el rango de región fronteriza, 4.00%, '+txtRango(0.039,0.041)+', y el de 8.00%, '+txtRango(0.079,0.081)+')'};
var RET_ESP=IVA_T/2; /* LIVA 18-J fr. II a): 50% del IVA cobrado → 8% (general) o 4% (fronteriza) de la venta sin IVA */
var RET_OK=RET_PCT!=null&&enRet(RET_ESP-0.001,RET_ESP+0.001);
var FRONT_SOSP=RET_PCT!=null&&!RET_OK&&Math.abs(IVA_T-0.16)<1e-9&&enRet(0.039,0.041);
var RET_MEZCLA=RET_PCT!=null&&!RET_OK&&!FRONT_SOSP&&S.iva>0.041*VSIN+0.005&&S.iva<0.079*VSIN-0.005; /* v1.6.2 (D43): entre 4% y 8%: ventas con y sin estímulo de región fronteriza */
var RET_RARA=RET_PCT!=null&&!RET_OK&&!FRONT_SOSP&&!RET_MEZCLA;
/* v1.7 (D48, opción B de Gerardo, 19-oct-2026 10:01): retención de IVA en 0 → aviso y canal POR VALIDAR; las decisiones se quedan */
var RET_CERO=!IVA_RARA&&VSIN>0&&Math.abs(S.iva)<0.005;
var ISR_ESP=T.reduce(function(a,r){return a+(r.isr?c2(r.v*0.025/FIVA):0)},0);
var ISR_DESC=!IVA_RARA&&Math.abs(S.isr-ISR_ESP)>0.01*Math.max(1,T.length);
/* v1.4 (D2): el volumen se mide contra la suma de contribuciones POSITIVAS de los productos; si ninguna es positiva, contra las ventas */
/* v1.5 (D22): los renglones sin costo o sin venta neta NO entran a ninguna de las dos bases */
var OKR=T.filter(function(r){return !r.nocost&&!r.nosale});
var POSBASE=OKR.reduce(function(a,r){return a+(r.con>0?r.con:0)},0), VBASE=OKR.reduce(function(a,r){return a+(r.v>0?r.v:0)},0);
var SB={n:'Publicidad de marca (SB/SD): se resta en los cargos de cuenta con el gasto del archivo de Ads, no la restes otra vez',pub:SBD.pub,va:SBD.va,sbrow:true};


function salud(r){if(r==null||isNaN(r))return '';return r<.20?'PIERDE':r<.45?'PELIGRO':r<.70?'REVISAR':r<1?'ACEPTABLE':r<1.5?'SANO':'SÚPER SANO'}
function tier(r){var s=POSBASE>0? r.con/POSBASE : (VBASE>0? r.v/VBASE : 0);return s>=.10?'CORE':s>=.02?'RELEVANTE':s>=.005?'MARGINAL':'RUIDO'}
function accion(roi,t,pub,sv,tacos){
  if(roi==null||isNaN(roi)||!t)return '';
  var g=(t==='CORE'||t==='RELEVANTE')||sv>=.03;
  if(roi<.20)return g?'PARAR VENTAS YA':'DESCONTINUAR';
  if(roi<.45){if(t==='CORE')return 'EMERGENCIA: volumen drenando caja';return g?'Cortar publicidad y arreglar precio o empaque':'DESCONTINUAR'}
  if(roi<.70){if(t==='CORE')return 'EMERGENCIA: volumen drenando caja';return g?'Cortar publicidad y arreglar precio o empaque':'Cortar publicidad y revisar precio'}
  if(roi<1){if(t==='CORE')return 'Arreglar antes de crecer: precio o publicidad';if(t==='RELEVANTE')return 'Subir precio 5-10% y medir';return 'Dejar quieto: no merece presupuesto'}
  if(t==='CORE')return 'Proteger stock y subir publicidad';
  if(t==='RELEVANTE')return 'ESCALAR FUERTE: aquí va el presupuesto';
  if(tacos==null||tacos<.05)return 'PROBAR: rentable con publicidad limitada'; /* v1.4 (D10): umbral relativo, TACOS < 5% */
  return 'Ya se empujó con presupuesto y no jaló';
}
function clasifica(r){
  if(r.nosale||r.nocost){r.s='';r.t='';r.a='';r.etq=r.nosale?'SIN VENTA NETA':'SIN COSTO';return}
  r.s=salud(r.ret);r.t=tier(r);r.a=accion(r.ret,r.t,r.pub,VBASE>0?r.v/VBASE:0,r.tacos)}
T.forEach(clasifica);
S.s=salud(S.ret);
/* v1.5 (D20): las 3 decisiones con la regla fija de la sección 7. «Grande» = CORE, RELEVANTE o 3% o más de las ventas (la misma regla que usa accion) */
function grande(r){return r.t==='CORE'||r.t==='RELEVANTE'||(VBASE>0&&r.v/VBASE>=.03)}
function mejorDe(a,f){return a.slice().sort(function(x,y){var d=f(x,y);return d!==0?d:(y.v-x.v)})[0]||null}
var CANDS=T.filter(function(r){return r.ret!=null&&r.s});
var MALOS=['REVISAR','PELIGRO','PIERDE'];
/* v1.5.1 (D26): Proteger y Arreglar solo CORE o RELEVANTE (igual que la acción de la tabla). Detener fuga: ver D_FUGA (v1.5.2, D29) */
function cr(r){return r.t==='CORE'||r.t==='RELEVANTE'}
var D_PROT=mejorDe(CANDS.filter(function(r){return cr(r)&&(r.s==='SANO'||r.s==='SÚPER SANO')}),function(x,y){return y.con-x.con});
var D_ARR=mejorDe(CANDS.filter(function(r){return cr(r)&&r.s==='ACEPTABLE'}),function(x,y){return y.con-x.con});
var FUGAS=CANDS.filter(function(r){return grande(r)&&MALOS.indexOf(r.s)>=0});
var D_FUGA=mejorDe(FUGAS,function(x,y){return x.ret-y.ret}); /* v1.5.2 (D29): Detener fuga elige entre los mismos renglones que las alertas (grande en REVISAR, PELIGRO o PIERDE); ahí la tabla dice «Cortar publicidad…» o «PARAR VENTAS YA» */
var D_ALERTAS=FUGAS.filter(function(r){return r!==D_FUGA}).sort(function(x,y){return x.ret-y.ret||y.v-x.v});
var DECISIONES={proteger:D_PROT?D_PROT.n:'no aplica este mes',arreglar:D_ARR?D_ARR.n:'no aplica este mes',detener:D_FUGA?D_FUGA.n:'no aplica este mes',alertas:D_ALERTAS.map(function(r){return r.n})};
/* v1.6.2 (D46): con el alto de la retención (4%, mezcla 4–8% u otro porcentaje) no se dan decisiones */
var ALTO_RET=FRONT_SOSP||RET_MEZCLA||RET_RARA||IVA_RARA; /* v1.6.3 (D50): tasa no válida → también POR VALIDAR */
if(ALTO_RET)DECISIONES={proteger:'POR VALIDAR',arreglar:'POR VALIDAR',detener:'POR VALIDAR',alertas:[]};


/* variantes */
var KIDS=[];
T.forEach(function(p){
  var hs=HIJOS.filter(function(h){return h[0]===p.n});
  if(!hs.length){var k=ent(Object.assign({},p));k.n=p.n+' · Variante 1';k.parent=p.n;k.single=true;clasifica(k);p.kids=[k];KIDS.push(k);return}
  p.kids=hs.map(function(h){var k=mk(h.slice(1),p.n+' · '+h[1]);k.parent=p.n;clasifica(k);KIDS.push(k);return k});
  var ks=p.kids.filter(function(k){return k.ret!=null});var rs=ks.map(function(k){return k.ret});p.rango=rs.length>1?Math.max.apply(null,rs)-Math.min.apply(null,rs):0;
  if(p.rango>.40){p.flag=true;p.peor=ks.reduce(function(a,k){return k.ret<a.ret?k:a});p.mejor=ks.reduce(function(a,k){return k.ret>a.ret?k:a})}
});
/* v1.8.4 (D82): un Parent «Decidir por Child» no lleva acción de familia y no entra a las 3 decisiones; entran sus variantes, cada una con su retorno */
T.forEach(function(p){if(p.flag){p.a='';p.porChild=true}});
CANDS=[];T.forEach(function(r){if(r.porChild){r.kids.forEach(function(k){if(k.ret!=null&&k.s)CANDS.push(k)})}else if(r.ret!=null&&r.s)CANDS.push(r)});
D_PROT=mejorDe(CANDS.filter(function(r){return cr(r)&&(r.s==='SANO'||r.s==='SÚPER SANO')}),function(x,y){return y.con-x.con});
D_ARR=mejorDe(CANDS.filter(function(r){return cr(r)&&r.s==='ACEPTABLE'}),function(x,y){return y.con-x.con});
FUGAS=CANDS.filter(function(r){return grande(r)&&MALOS.indexOf(r.s)>=0});
D_FUGA=mejorDe(FUGAS,function(x,y){return x.ret-y.ret});
D_ALERTAS=FUGAS.filter(function(r){return r!==D_FUGA}).sort(function(x,y){return x.ret-y.ret||y.v-x.v});
DECISIONES={proteger:D_PROT?D_PROT.n:'no aplica este mes',arreglar:D_ARR?D_ARR.n:'no aplica este mes',detener:D_FUGA?D_FUGA.n:'no aplica este mes',alertas:D_ALERTAS.map(function(r){return r.n})};
if(ALTO_RET)DECISIONES={proteger:'POR VALIDAR',arreglar:'POR VALIDAR',detener:'POR VALIDAR',alertas:[]};


/* columnas */
var SEMC={'SÚPER SANO':'s-ss','SANO':'s-sano','ACEPTABLE':'s-ac','REVISAR':'s-rev','PELIGRO':'s-pel','PIERDE':'s-pi'};
var m$=function(n){return n==null||isNaN(n)?['','']:[n,neg(n,fm(n))]};
var mp=function(n,d){return n==null||isNaN(n)?['','']:[n,neg(n,fp(n,d==null?1:d))]};
var m2=function(n){return n==null||isNaN(n)?['','']:[n,neg(n,fm(n,2))]};
var BIVA=' (con IVA)'; /* v1.6 (D3): una sola base, con IVA */
var GAT='ATENCIÓN · tal cual el reporte, con IVA'; /* v1.5 (D23) y v1.5.1 (D27): los campos de atención en la misma base, sin dividir, y con el FBA cobrado al lado */
var COLS=[
 {g:'PRODUCTO',l:'Producto',k:1,t:'pn'},
 {g:'PRODUCTO',l:'Unidades',k:1,get:function(r){return [r.u,r.u==null?'':r.u.toLocaleString('es-MX')]}},
 {g:'DECISIÓN',l:'Retorno s/ costo',k:1,get:function(r){return mp(r.ret)}},
 {g:'DECISIÓN',l:'Salud del costo',k:1,t:'t',get:function(r){if(r.etq)return [r.etq,'<span class="sem" style="background:#444;color:#ddd">'+r.etq+'</span>'];return [r.s,r.s?'<span class="sem '+SEMC[r.s]+'">'+r.s+'</span>':'']}},
 {g:'DECISIÓN',l:'Volumen',k:1,t:'t',get:function(r){return [r.t,r.t?'<span class="vol'+(r.t==='CORE'?' core':'')+'">'+r.t+'</span>':'']}},
 {g:'DECISIÓN',l:'Acción',k:1,t:'a',get:function(r){if(r.porChild)return ['Decidir por Child','Decidir por Child: ver la acción de cada variante']; /* v1.8.4 (D82) */return [r.a,r.a||(r.etq==='SIN COSTO'?'Sin costo: no se decide':r.etq?'Reembolso o ajuste sin venta del mes: no se decide':'')]}},
 {g:'PUBLICIDAD'+BIVA,l:'Publicidad',k:1,get:function(r){return r.pub?m$(-r.pub):['','']}},
 {g:'PUBLICIDAD'+BIVA,l:'Ventas con ads',k:0,get:function(r){return r.va?m$(r.va):['','']}},
 {g:'PUBLICIDAD'+BIVA,l:'ACOS SP',k:1,get:function(r){return mp(r.acos)}},
 {g:'VENTA'+BIVA,l:'Ventas totales',k:1,get:function(r){return m$(r.v)}},
 {g:'VENTA'+BIVA,l:'TACOS SP',k:1,get:function(r){return mp(r.tacos)}},
 {g:'VENTA'+BIVA,l:'Precio prom.',k:0,get:function(r){return m2(r.precio)}},
 {g:'COSTOS',l:'Costo unit.',k:0,get:function(r){return m2(r.cu)}},
 {g:'COSTOS',l:'Comisión ref. %'+(' (con IVA ÷ venta con IVA)'),k:0,get:function(r){return mp(r.cp)}},
 {g:'COSTOS',l:'Comisión ref. $'+BIVA,k:0,get:function(r){return m$(-r.c$)}},
 {g:'COSTOS',l:'Tarifa FBA $/u'+BIVA,k:0,get:function(r){return m2(r.fu)}},
 {g:'COSTOS',l:'Costo FBA total'+(' (con IVA, entra a la contribución)'),k:0,get:function(r){return m$(-r.ft)}},
 {g:'COSTOS',l:'Costo producto',k:0,get:function(r){return m$(-r.cpr)}},
 {g:'COSTOS',l:'Costo total',k:0,get:function(r){return m$(-r.ct)}},
 {g:'UTILIDAD',l:'Util. bruta',k:0,get:function(r){return m$(r.ub)}},
 {g:'UTILIDAD',l:'Util. tras publicidad',k:1,get:function(r){return m$(r.un)}},
 {g:'UTILIDAD',l:'% utilidad',k:0,get:function(r){return mp(r.pu)}},
 {g:'AJUSTES DEL REPORTE',l:'Devoluciones',k:0,get:function(r){return r.dev?m$(-r.dev):['','']}},
 {g:'AJUSTES DEL REPORTE',l:'Ajustes y otros',k:0,get:function(r){return r.aj?m$(r.aj):['','']}},
 {g:'RETENCIONES',l:'Retención de IVA ('+(IVA_T===0.08?'4%':'8%')+')',k:0,get:function(r){return m$(-r.iva)}},
 {g:'RETENCIONES',l:'ISR devengado (por producto)',k:0,get:function(r){return m$(-r.isr)}},
 {g:'RESULTADO FINAL',l:'Contribución del producto',k:1,get:function(r){return m$(r.con)}},
 {g:'RESULTADO FINAL',l:'% final',k:1,get:function(r){return mp(r.pf)}},
 {g:'RESULTADO FINAL',l:'Contribución $/u neta',k:0,get:function(r){return m2(r.cx)}},
 {g:GAT,l:'FBA cobrado',k:0,get:function(r){return (r.fd||r.df)?m$(-(r.fd+r.df)):['','']}},
 {g:GAT,l:'FBA debería ser',k:0,get:function(r){return m$(-r.fd)}},
 {g:GAT,l:'Dif. FBA',k:0,get:function(r){return m$(r.df)}},
 {g:GAT,l:'Por validar',k:1,get:function(r){return r.val?m$(r.val):['','']}}
];
var st={view:'parent',cols:'key',sk:null,sd:-1};
/* v1.8.3 (D75, D73): en «Columnas clave» van primero el resultado y lo por validar, para que se vean sin scroll en escritorio; si ningún producto tiene costo, las columnas de DECISIÓN se quitan (dirían lo mismo en todos los renglones) */
var KEYORD=['Producto','Unidades','Contribución del producto','% final','Por validar','Retorno s/ costo','Salud del costo','Volumen','Acción','Ventas totales','Publicidad','ACOS SP','TACOS SP','Util. tras publicidad'];
var SIN_DEC=T.length>0&&T.every(function(r){return r.nocost||r.nosale})&&T.some(function(r){return r.nocost});
var visCols=function(){var v=COLS.map(function(c,i){return {c:c,i:i}}).filter(function(x){return st.cols==='all'||x.c.k});if(st.cols==='all')return v;v=v.filter(function(x){return !(SIN_DEC&&x.c.g==='DECISIÓN')});return v.sort(function(a,b){var p=KEYORD.indexOf(a.c.l),q=KEYORD.indexOf(b.c.l);return (p<0?99:p)-(q<0?99:q)})};


function cell(r,c,i,isFirst){
  var cls=c.t==='pn'?'pn':c.t==='a'?'acc':'num';
  if(c.t==='pn'){
    var h=hx(r.n);
    if(r.parent){h=hx(r.n.split(' · ')[1])+'<small>'+hx(r.parent)+'</small>'}
    else if(r.kids&&r.kids.length>0&&!r.tot){h=hx(r.n)+'<small>'+(r.kids.length===1?'1 variante':r.kids.length+' variantes')+'</small>'+(r.flag?'<span class="pill">Decidir por Child</span>':'')}
    return '<td class="pn">'+h+'</td>';
  }
  var v=c.get(r);
  if((r.tot||r.sbrow)&&(c.t==='t'||c.t==='a')&&!(r.tot&&c.l==='Salud del costo'))v=['',''];
  if(r.tot&&c.l==='Salud del costo'&&FALTA_COSTO)v=['','<span class="sem" style="background:#444;color:#ddd">FALTA COSTO</span>'];
  if(r.tot&&FALTA_COSTO&&['Util. bruta','Util. tras publicidad','% utilidad','Contribución del producto','% final','Contribución $/u neta'].indexOf(c.l)>=0&&v[1]!=='')v=[v[0],v[1]+'<small class="sob">sobrestimado: falta costo</small>']; /* v1.8.3 (D76, E2) */
  return '<td class="'+cls+'" data-v="'+(v[0]==null?'':(typeof v[0]==='number'?v[0]:''))+'">'+v[1]+'</td>';
}
function rowHtml(r,cls){
  var vc=visCols();
  return '<tr class="'+(cls||'')+'">'+vc.map(function(x,j){return cell(r,x.c,x.i,j===0)}).join('')+'</tr>';
}
function noVenta(s,n){
  var vc=visCols();
  return '<tr class="nv">'+vc.map(function(x){
    var l=x.c.l;
    if(x.c.t==='pn')return '<td class="pn">'+hx(s[0])+'</td>';
    if(l==='Unidades')return '<td class="num">0</td>';
    if(l==='Publicidad')return '<td class="num neg">'+fm(-s[1])+'</td>';
    if(l==='Ventas con ads')return '<td class="num">'+fm(s[2])+'</td>';
    if(l==='Util. tras publicidad'||l==='Contribución del producto')return '<td class="num neg">'+fm(-s[1])+'</td>';
    if(l==='Salud del costo')return '<td><span class="sem" style="background:#444;color:#ddd">'+(s[3]==='na'?'NO ASIGNABLE':'SIN VENTA')+'</span></td>';
    return '<td></td>';
  }).join('')+'</tr>';
}
function sortRows(rows){
  if(!st.sk)return rows;
  var c=COLS[st.sk];
  var key=function(r){var v=c.t==='pn'?r.n:c.get(r)[0];return v};
  return rows.slice().sort(function(a,b){
    var x=key(a),y=key(b);
    if(typeof x==='string'||typeof y==='string'){return st.sd*(String(x).localeCompare(String(y)))}
    if(x===''||x==null||isNaN(x))x=-Infinity; if(y===''||y==null||isNaN(y))y=-Infinity;
    return -st.sd*(y-x);
  });
}
function render(){
  var vc=visCols();
  var gr=[];vc.forEach(function(x){var g=(st.cols==='key'&&x.c.g===GAT)?'ATENCIÓN':x.c.g; /* v1.8.3 (D75): en columnas clave el grupo va corto para no ensanchar la tabla */if(gr.length&&gr[gr.length-1][0]===g)gr[gr.length-1][1]++;else gr.push([g,1])});
  var th1='<tr>'+gr.map(function(g,i){return '<th colspan="'+g[1]+'"'+(i===0?' class="pn"':'')+'>'+g[0]+'</th>'}).join('')+'</tr>';
  var th2='<tr>'+vc.map(function(x){var c=x.c;var so=c.t!=='t'&&c.t!=='a';return '<th class="'+(c.t==='pn'?'pn ':'')+(so?'sort':'')+'"'+(so?' tabindex="0" data-i="'+x.i+'"'+(st.sk===x.i?' data-d="'+st.sd+'"':''):'')+'>'+c.l+'</th>'}).join('')+'</tr>';
  var body='';
  var parents=T.slice().sort(function(a,b){return b.con-a.con});
  if(st.view==='parent'){
    sortRows(parents).forEach(function(r){body+=rowHtml(r)});
  }else{
    if(st.sk){sortRows(KIDS).forEach(function(r){body+=rowHtml(r)})}
    else parents.forEach(function(p){
      p.kids.slice().sort(function(a,b){return b.con-a.con}).forEach(function(k){body+=rowHtml(k)});
    });
  }
  SIN.forEach(function(s){body+=noVenta(s)});
  body+=rowHtml(S,'sub');
  body+='<tr class="sub">'+vc.map(function(x){var l=x.c.l;
    if(x.c.t==='pn')return '<td class="pn">'+hx(SB.n)+'</td>';
    if(l==='Publicidad')return '<td class="num neg">'+fm(-SB.pub)+'</td>';
    if(l==='Ventas con ads')return '<td class="num">'+fm(SB.va)+'</td>';
    /* v1.8.10 (decisión de Gerardo): el renglón de marca deja en blanco «ACOS SP» y «TACOS SP»; el ACOS de marca va solo en el bloque PUBLICIDAD DE MARCA */
    return '<td></td>'}).join('')+'</tr>';
  $('big').innerHTML='<thead>'+th1+th2+'</thead><tbody>'+body+'</tbody>';
  $('big').querySelectorAll('th.sort').forEach(function(th){
    var i=+th.getAttribute('data-i');
    var go=function(){if(st.sk===i){st.sd=-st.sd}else{st.sk=i;st.sd=-1}render()};
    th.addEventListener('click',go);
    th.addEventListener('keydown',function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();go()}});
  });
  var fl=T.filter(function(p){return p.flag});
  if(st.view==='parent'&&fl.length){
    var p=fl[0];
    $('co').innerHTML='<div class="callout"><span><b>'+hx(p.n)+'</b>: sus variantes van de <b class="num">'+fp(p.peor.ret,0)+'</b> a <b class="num">'+fp(p.mejor.ret,0)+'</b> de retorno sobre costo. El promedio del Parent esconde el problema: <b>decide por Child, no por Parent.</b> Arrastra '+hx(p.peor.n.split(' · ')[1])+' ('+p.peor.u+' unidades, retorno '+fp(p.peor.ret,0)+').</span><button class="lk" type="button" id="go">Ver Child</button></div>';
    $('go').addEventListener('click',function(){setView('child')});
  }else{$('co').innerHTML=''}
}
function setView(v){st.view=v;st.sk=null;$('tp').setAttribute('aria-selected',v==='parent');$('tc').setAttribute('aria-selected',v==='child');render()}
$('tp').addEventListener('click',function(){setView('parent')});
$('tc').addEventListener('click',function(){setView('child')});
document.querySelectorAll('[data-cols]').forEach(function(b){b.addEventListener('click',function(){
  st.cols=b.getAttribute('data-cols');document.querySelectorAll('[data-cols]').forEach(function(x){x.setAttribute('aria-selected',x===b)});render()})});
$('cp').textContent=T.length; $('cc').textContent=KIDS.length;


var bands=[['SÚPER SANO','s-ss','150%+'],['SANO','s-sano','100-149%'],['ACEPTABLE','s-ac','70-99%'],['REVISAR','s-rev','45-69%'],['PELIGRO','s-pel','20-44%'],['PIERDE','s-pi','<20%']];
$('legend').innerHTML='<span class="t">RETORNO SOBRE COSTO: lo que deja cada peso invertido en producto</span>'+bands.map(function(b){return '<span class="g"><span class="sem '+b[1]+'">'+b[0]+'</span><span class="num">'+b[2]+'</span></span>'}).join('')+
 '<span class="t">VOLUMEN (parte de la contribución positiva de los productos)</span><span class="g"><span class="vol core">CORE</span><span class="num">10%+</span></span><span class="g"><span class="vol">RELEVANTE</span><span class="num">2-10%</span></span><span class="g"><span class="vol">MARGINAL</span><span class="num">0.5-2%</span></span><span class="g"><span class="vol">RUIDO</span><span class="num">&lt;0.5%</span></span>';


/* cobros */
var ORDS=DATA.ordenes||[];
var VR, vtot, vun, DESC_VAL=null;
if(ORDS.length){ /* v1.4 (D6): el titular sale de las mismas órdenes que el CSV */
  var g={};ORDS.forEach(function(o){var d=+o[6];if(!(d>0))return;if(o[14]==='com')return; /* v1.8.5 (C1): el titular y el cuadre 10 son solo de FBA; la comisión va en la tabla de casos pero no se suma al titular */var k=o[2];if(!g[k])g[k]={n:k,val:0,vu:0};g[k].val+=d;g[k].vu+=(+o[8]||0)});
  VR=Object.keys(g).map(function(k){return g[k]}).sort(function(a,b){return b.val-a.val});
  vtot=sumK(VR,'val'); vun=sumK(VR,'vu');
  var vprod=sumK(T,'val'); if(Math.abs(vprod-vtot)>0.005)DESC_VAL=vprod;
}else{
  VR=T.filter(function(r){return r.val>0}).sort(function(a,b){return b.val-a.val});
  vtot=sumK(VR,'val'); vun=sumK(VR,'vu');
}
$('vt').innerHTML=fm(vtot,2)+'<small>posible diferencia · '+VR.length+' productos · '+vun+' unidades · tal cual el reporte'+(' (con IVA)')+'</small>'+(DESC_VAL!=null?'<small style="color:var(--bad)">Descuadre: la tabla de productos suma '+fm(DESC_VAL,2)+' por validar. Revisar antes de reclamar.</small>':'');
$('vt2').textContent=fm(vtot,2);
/* v1.8.5 (C1): con órdenes, la sección entrega una tabla de casos por orden, con el texto listo para pegar a Soporte al Vendedor */
var BASE_STD='Tarifa FBA de la orden (menos el envío y la envoltura de regalo que pagó el comprador × 1.16) vs la tarifa más frecuente del propio SKU en su banda de precio ($299 o más / menos de $299)';
var BASE_COM='Comisión de la orden y SKU vs la tasa más frecuente del propio SKU en su banda de precio, con el precio después de promociones (banda por confirmar con Amazon)';
function caseTxt(o){if(o[13])return String(o[13]);var com=o[14]==='com';
  return 'Hola, equipo de Soporte al Vendedor:\n\nLes pido revisar '+(com?'la tarifa por referencia (comisión)':'la tarifa de logística de Amazon (FBA)')+' del pedido '+o[0]+' (SKU '+o[2]+(o[9]?', ASIN '+o[9]:'')+', '+(o[8]==null?'':o[8]+(o[8]==1?' unidad':' unidades'))+', fecha '+o[1]+').\n\n'+
   'En mi reporte de transacciones de '+DATA.mes+', este pedido tiene '+(com?'una comisión':'una tarifa FBA')+' de '+fm(+o[4],2)+' '+DATA.moneda+'. Esperaba '+fm(+o[5],2)+' '+DATA.moneda+': '+(o[10]||(com?BASE_COM:BASE_STD))+'. La diferencia es de '+fm(+o[6],2)+' '+DATA.moneda+'. Todos los montos son tal cual el reporte, con IVA incluido.\n\n'+
   'Les pido por favor:\n1. Confirmar cómo se calculó '+(com?'la comisión de este pedido y sobre qué precio':'la tarifa FBA de este pedido y qué incluye')+'.\n2. Si no corresponde, revisar la tarifa y reembolsar la diferencia.\n\nGracias.'}
if(ORDS.length){
 $('vtab').innerHTML='<thead><tr><th>Order ID</th><th>SKU / ASIN</th><th>Fecha</th><th class="l">Concepto</th><th>Cobrado</th><th>Esperado</th><th>Diferencia</th><th class="l">Validación previa</th><th class="l">Recomendación</th><th class="l">Texto del caso</th></tr></thead><tbody>'+
  ORDS.filter(function(o){return +o[6]>0}).map(function(o){return '<tr><td><b>'+hx(o[0])+'</b></td><td>'+hx(o[2])+(o[9]?'<small>'+hx(o[9])+'</small>':'<small>ASIN: no sé</small>')+'</td><td>'+hx(o[1])+'</td><td class="l">'+hx(o[3])+'<small>'+hx(o[10]||(o[14]==='com'?BASE_COM:BASE_STD))+'</small></td><td class="num">'+fm(+o[4],2)+'</td><td class="num">'+fm(+o[5],2)+'</td><td class="num">'+fm(+o[6],2)+'</td><td class="l">'+hx(o[11]||'Sin explicación en el reporte')+'</td><td class="l"><span class="chip">'+hx(o[12]||o[7]||'Validar antes de actuar')+'</span></td><td class="l"><details><summary style="cursor:pointer">Ver texto</summary><pre class="ct">'+hx(caseTxt(o))+'</pre></details></td></tr>'}).join('')+'</tbody>';
}else
$('vtab').innerHTML='<thead><tr><th>Producto</th><th class="l">Qué se comparó</th><th>Unidades a revisar</th><th>Posible diferencia</th><th class="l">Etiqueta</th></tr></thead><tbody>'+
 VR.map(function(r){return '<tr><td><b>'+hx(r.n)+'</b></td><td class="l">Tarifa FBA de la orden (menos el envío y la envoltura de regalo que pagó el comprador × 1.16) vs la tarifa más frecuente del propio SKU en su banda de precio ($299 o más / menos de $299)</td><td class="num">'+r.vu+'</td><td class="num">'+fm(r.val,2)+'</td><td class="l"><span class="chip">Validar antes de actuar</span></td></tr>'}).join('')+
 '<tr><td><b>Total</b></td><td class="l"></td><td class="num"><b>'+vun+'</b></td><td class="num"><b>'+fm(vtot,2)+'</b></td><td class="l"></td></tr></tbody>';
$('rev').innerHTML=DATA.rev.map(function(x){return '<div><b>'+hx(x[0])+'</b>'+hx(x[1])+' <span class="chip'+(x[3]?' ok':'')+'" style="align-self:flex-start">'+hx(x[2])+'</span></div>'}).join('');


/* v1.7: cargos de cuenta. TOTAL = renglones del reporte SIN el cargo de publicidad (incluido el ISR) − publicidad de marca SB/SD del archivo de Ads × 1.16.
   Sponsored Products ya está restado por producto (archivo de Ads × 1.16). El cargo de publicidad del reporte NO entra a la contribución (no importa cómo se pague): solo cuenta en la caja del mes */
/* v1.5.1 (D25): el cargo de publicidad se busca por etiqueta 'pub' y, si no hay, por nombre (c) */
var pubRows=DATA.cargos.filter(function(c){return c[3]==='pub'}), PUB_POR_NOMBRE=false;
if(!pubRows.length){pubRows=DATA.cargos.filter(function(c){return c[3]!=='isr'&&/publicidad|advertising|anuncio/i.test(String(c[0]))});PUB_POR_NOMBRE=pubRows.length>0}
var esPub=function(c){return pubRows.indexOf(c)>=0};
var cargosNoPub=DATA.cargos.filter(function(c){return !esPub(c)});
var pubCargo=-pubRows.reduce(function(a,c){return a+c[1]},0);
var cs=cargosNoPub.reduce(function(a,c){return a+c[1]},0)-SBD.pub;
var ISR_NOM=DATA.cargos.filter(function(c){return c[3]==='isr'}).map(function(c){return c[0]}).join(' + '); /* v1.8.3: el renglón de caja dice qué cargo es (p. ej. «Retención de ISR de agosto cobrada en septiembre») */
var isrAmt=DATA.cargos.reduce(function(a,c){return a+(c[3]==='isr'?c[1]:0)},0);
var GASTO_ADS=PUB_ASIG+SBD.pub; /* SP + SB + SD con IVA: la publicidad que entra a la contribución */
var VA_TOT=c2(S.va+SBD.va), ACOS_TOT=VA_TOT>0?(PUB_ASIG+SBD.pub)/VA_TOT:null; /* v1.8.3 (E4): ACOS total de la cuenta, misma base */
var PUB_DIF_COBRO=Math.round((pubCargo-GASTO_ADS)*100)/100; /* v1.7 (cuadre 11, informativo): cobro de publicidad del reporte − gasto del archivo de Ads; no cambia la contribución */
/* v1.7: cuadre 11 solo cuando el reporte trae cargo de publicidad: si el gasto del archivo de Ads (con IVA) es mayor que el cargo, se revisa (p. ej., IVA puesto dos veces). Sin cargo no aplica y no hay marca */
var PUB_INCONG=pubRows.length>0&&GASTO_ADS>pubCargo+0.005;
var INC_ADS=PUB_INCONG?' — POR VALIDAR: revisar la publicidad':'';
var INC_IVA=IVA_RARA?' — POR VALIDAR: tasa de IVA no reconocida':RET_CERO?' — POR VALIDAR: no encontré la retención de IVA':FRONT_SOSP?' — POR VALIDAR: la retención de IVA da '+fpt(RET_PCT)+' (¿región fronteriza?)':RET_MEZCLA?' — POR VALIDAR: la retención de IVA da '+fpt(RET_PCT)+' (¿ventas con y sin estímulo fronterizo?)':(RET_RARA||ISR_DESC||IVA_RARA)?' — POR VALIDAR: revisar retenciones o datos':(PUB_DESC&&!INC_ADS)?' — POR VALIDAR: revisar la publicidad':''; /* v1.6.2 (D45) */
var gastoSinIsr=cs-isrAmt, CANAL=CONTOT+gastoSinIsr, CANAL_CON=CONTOT+cs;
/* v1.6: se quitó el renglón temporal de D31 (IVA de Ads). Con una sola base, con IVA, el canal ya no cambia según cómo se pagan los Ads */
var INC=(FALTA_COSTO?' — INCOMPLETA: falta el costo de '+N_SIN_COSTO+(N_SIN_COSTO===1?' producto':' productos')+' (sobrestimada)':'')+INC_ADS+INC_IVA; /* v1.5 (D21), v1.5.1 (D25) y v1.6.1 (D38, D41) */
/* v1.6 (D3, regla 4) y v1.6.1 (D37, D40): CAJA DEL MES, reporte aparte con su propia sección. No se suma a la contribución. Usa el ISR COBRADO (cargo del mes), nunca el devengado (D4) */
var cargosSinIsr=DATA.cargos.reduce(function(a,c){return a+(c[3]==='isr'?0:c[1])},0);
var LIQ=S.v-S.c$-S.ft-S.dev+S.aj+cargosSinIsr-S.iva+isrAmt; /* lo que quedó de las liquidaciones de Amazon */
var CAJA=LIQ-S.cpr; /* v1.7: solo lo que pasó por las liquidaciones de Amazon; lo que pagues de Ads fuera de Amazon no está aquí */
var CAJA_CONC=CANAL+S.isr+isrAmt+GASTO_ADS-pubCargo; /* v1.7: + publicidad del archivo de Ads − cargo de publicidad del reporte */ /* contribución del canal + ISR devengado − ISR cobrado; ya no depende de cómo se pagan los Ads */
var CAJA_DIF=Math.round((CAJA-CAJA_CONC)*100)/100;
var cajaHtml='<div class="chg cj"><h3>CAJA DEL MES — REPORTE APARTE: LIQUIDACIONES DE AMAZON MENOS COSTO DE PRODUCTO</h3>'+
 '<div class="r"><span>Ventas del mes'+BIVA+'</span><span>'+fm(S.v,2)+'</span></div>'+
 '<div class="r"><span>Comisión y FBA cobradas'+BIVA+'</span><span>'+fm(-(S.c$+S.ft),2)+'</span></div>'+
 '<div class="r"><span>Devoluciones</span><span>'+fm(-S.dev,2)+'</span></div>'+
 '<div class="r"><span>Ajustes y otros</span><span>'+fm(S.aj,2)+'</span></div>'+
 '<div class="r"><span>Cargos de cuenta del reporte'+(', sin el ISR')+'<small>(tal cual el reporte'+BIVA+'; incluye el cargo de publicidad si Amazon lo cobró en la liquidación)</small></span><span>'+fm(cargosSinIsr,2)+'</span></div>'+
 ('<div class="r"><span>Retención de IVA ('+fp(RET_ESP,0)+')<small>(lo que Amazon retuvo en el mes; aquí cuenta como salida de dinero)</small></span><span>'+fm(-S.iva,2)+'</span></div>'+
 '<div class="r"><span>ISR cobrado este mes'+(ISR_NOM?': '+hx(ISR_NOM):'')+'<small>(cargo del mes, sobre ventas del mes anterior'+(DATA.isrConfirmado===false?'; POR CONFIRMAR':'')+')</small></span><span>'+fm(isrAmt,2)+'</span></div>')+
 '<div class="r liq"><span>Lo que quedó de las liquidaciones de Amazon<small>(lo que Amazon te depositó o te debe por el mes)</small></span><span>'+fm(LIQ,2)+'</span></div>'+
 '<div class="r"><span>Costo de producto<small>(lo pagas tú a tu proveedor; Amazon no lo cobra)</small></span><span>'+fm(-S.cpr,2)+'</span></div>'+
 '<div class="r tt"><span>RESULTADO DE CAJA DEL MES<small>(liquidaciones menos costo de producto; no es el saldo de tu banco. Si pagas publicidad fuera de Amazon, ese dinero no está aquí)</small></span><span>'+fm(CAJA,2)+'</span></div>'+
 '<div class="r"><span><small style="margin:0">No se suma a la CONTRIBUCIÓN DEL CANAL. Concilia así: canal '+fm(CANAL,2)+(' + ISR devengado por producto '+fm(S.isr,2)+' − ISR cobrado '+fm(-isrAmt,2))+' + publicidad del archivo de Ads '+fm(GASTO_ADS,2)+' − cargo de publicidad del reporte '+fm(pubCargo,2)+' = '+fm(CAJA_CONC,2)+(Math.abs(CAJA_DIF)<0.005?' (cuadra)':' · <b style="color:var(--bad)">no cuadra por '+fm(CAJA_DIF,2)+'</b>')+'</small></span><span></span></div></div>';
var canalHtml;
if(isrAmt===0){canalHtml='<div class="r tt"><span>CONTRIBUCIÓN DEL CANAL'+INC+'<small>(contribución de productos '+fm(CONTOT,2)+' + total cargos de cuenta)</small></span><span>'+fm(CANAL_CON,2)+'</span></div>'}
else if(DATA.isrConfirmado!==false){canalHtml='<div class="r"><span>Gasto compartido real (sin ISR)<small>(el ISR ya se restó por producto como ISR devengado)</small></span><span>'+fm(gastoSinIsr,2)+'</span></div><div class="r tt"><span>CONTRIBUCIÓN DEL CANAL'+INC+'<small>(contribución de productos '+fm(CONTOT,2)+' + gasto compartido sin ISR)</small></span><span>'+fm(CANAL,2)+'</span></div>'}
else{canalHtml='<div class="r"><span>Gasto compartido sin el cargo POR CONFIRMAR</span><span>'+fm(gastoSinIsr,2)+'</span></div><div class="r tt"><span>CONTRIBUCIÓN DEL CANAL · si el cargo es ISR'+INC+'</span><span>'+fm(CANAL,2)+'</span></div><div class="r tt"><span>CONTRIBUCIÓN DEL CANAL · si el cargo NO es ISR'+INC+'</span><span>'+fm(CANAL_CON,2)+'</span></div>'}
$('cg').innerHTML='<div class="chg"><h3>CARGOS QUE AMAZON NO ATA A NINGÚN PRODUCTO</h3>'+
 cargosNoPub.map(function(c){return '<div class="r"><span>'+hx(c[0])+(c[2]?'<small>('+hx(c[2])+')</small>':'')+'</span><span>'+fm(c[1],2)+'</span></div>'}).join('')+
 '<div class="r"><span>Publicidad de marca SB/SD<small>(del archivo de Ads, con IVA: gasto × '+PTXT+'; Sponsored Products ya está restada por producto)</small></span><span>'+fm(-SBD.pub,2)+'</span></div>'+(PUB_POR_NOMBRE?'<div class="r"><span><small style="margin:0">El cargo de publicidad no venía etiquetado; lo reconocí por su nombre: «'+hx(pubRows[0][0])+'». No entra aquí.</small></span><span></span></div>':'')+
 '<div class="r tt"><span>TOTAL CARGOS DE CUENTA</span><span>'+fm(cs,2)+'</span></div>'+(PUB_INCONG?'<div class="r"><span style="color:var(--bad)">Revisar: el gasto de Ads (SP + SB/SD: '+fm(GASTO_ADS,2)+') es mayor que el cargo de publicidad (los dos con IVA) ('+fm(pubCargo,2)+')</span><span></span></div>':'')+canalHtml+'<div class="r"><span><small style="margin:0">Montos tal cual el reporte'+(', con IVA')+'. La publicidad sale siempre del archivo de Ads × '+PTXT+' (productos y marca), sin importar cómo la pagues. '+(pubRows.length?'Cargo de publicidad del reporte: '+fm(-pubCargo,2)+' (no entra a la contribución; está en la caja del mes). Diferencia contra el gasto del archivo de Ads: '+fm(PUB_DIF_COBRO,2)+(Math.abs(PUB_DIF_COBRO)>=0.005?' (Validar antes de actuar)':'')+'.':'El reporte no trae cargo de publicidad.')+'</small></span><span></span></div></div>'+
 '<div class="chg sb"><h3>PUBLICIDAD DE MARCA — NO BAJA A PRODUCTO</h3><div class="sbx"><span>Gasto SB/SD'+BIVA+' <b>'+fm(SBD.pub,2)+'</b></span><span>Ventas con ads'+BIVA+' <b>'+fm(SBD.va,2)+'</b></span><span>ACOS de marca (SB/SD) <b>'+(SBD.va?fp(SBD.pub/SBD.va):'—')+'</b></span></div>'+'<div class="sbx"><span>ACOS TOTAL DE LA CUENTA (SP + SB + SD) <b id="acost">'+(ACOS_TOT==null?'—':fp(ACOS_TOT))+'</b></span><span>Gasto de Ads'+BIVA+' <b>'+fm(GASTO_ADS,2)+'</b></span><span>Ventas con ads'+BIVA+' <b>'+fm(VA_TOT,2)+'</b></span></div>'+'<div class="r"><span><small style="margin:0">El IVA va al gasto y a las ventas con ads, así que el ACOS es el mismo que el de la consola de Ads.</small></span><span></span></div></div>';
$('cj').innerHTML=cajaHtml;


$('facts').innerHTML=(DATA.marca?'<span class="fact br">Preparado para: <b>'+hx(DATA.marca)+'</b></span>':'')+'<span class="fact">Tienda: <b>'+hx(DATA.tienda)+'</b></span><span class="fact">Periodo: <b>'+hx(DATA.periodo)+'</b></span><span class="fact">'+hx(DATA.moneda)+(' · venta con IVA')+'</span><span class="fact">'+hx(DATA.nota)+'</span>'+(DATA.muestra?'<span class="fact br"><b>Muestra:</b> datos de ejemplo</span>':'');
if(DATA.muestra)$('mu').textContent='MUESTRA'; /* v1.8.3 (D74): sin muestra, el texto no existe en la página */
if(DATA.marca)$('bsub').textContent=DATA.marca+' · Diagnóstico de Rentabilidad Amazon · por Gerardo Villa'; /* v1.8.5 (D86, Gerardo 20-oct-2026): «Profit AI System» y «por Gerardo Villa» van siempre; el nombre del vendedor solo agrega «Preparado para» */
/* v1.8.5 (D86, Gerardo 20-oct-2026): bloque de contacto para dudas. Valores fijos del dueño de la skill, no de DATA. WhatsApp vacío = la línea no se muestra (nunca un número de relleno) */
var CONTACTO={email:'cursos@summaproducts.com',whatsapp:''};
$('contacto').innerHTML='<div class="by"><b>¿Dudas?</b> Correo: <a href="mailto:'+hx(CONTACTO.email)+'">'+hx(CONTACTO.email)+'</a>'+(CONTACTO.whatsapp?' · WhatsApp: '+hx(CONTACTO.whatsapp):'')+'</div>';


var esc=function(s){s=String(s);return /[",\n]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s};
function csv(){
  var h=['Producto','Concepto','Mes','Unidades a revisar','Posible diferencia ('+DATA.moneda+')','Etiqueta','Order IDs','Qué se comparó','Ruta del caso','Nota'];
  var ORD=DATA.ordenes||[];
  if(ORD.length){
    h=['Order ID','Fecha','SKU/ASIN','Concepto','Unidades','Cobrado ('+DATA.moneda+(', con IVA')+')','Esperado ('+DATA.moneda+(', con IVA')+')','Diferencia ('+DATA.moneda+(', con IVA')+')','Etiqueta','Ruta del caso','Nota','ASIN','Base del esperado','Validación previa','Recomendación','Texto del caso'];
    var rowsO=ORD.map(function(o){return [o[0],o[1],o[2],o[3],(o[8]==null?'':o[8]),(+o[4]).toFixed(2),(+o[5]).toFixed(2),(+o[6]).toFixed(2),o[7],'Ayuda > Obtener soporte > Vender en Amazon > Reconcile Charges > Review Fees > Order ID > Contact an associate > Email','Posible diferencia por validar. No es dinero garantizado: Amazon decide.',o[9]||'no sé',o[10]||(o[14]==='com'?BASE_COM:BASE_STD),o[11]||'',o[12]||'',caseTxt(o)]}); /* v1.8.5 (C1): mismos campos que la tabla de casos */
    var td=ORD.reduce(function(a,o){return a+(o[14]==='com'?0:+o[6])},0), tc=ORD.reduce(function(a,o){return a+(o[14]==='com'?+o[6]:0)},0);
    rowsO.push(['TOTAL FBA','','','','','','',td.toFixed(2),'','','','','','','','']);if(tc>0)rowsO.push(['TOTAL COMISIÓN (aparte, no se suma al titular)','','','','','','',tc.toFixed(2),'','','','','','','','']);
    return '\ufeff'+[h].concat(rowsO).map(function(r){return r.map(esc).join(',')}).join('\r\n');
  }
  var rows=VR.map(function(r){return [r.n,'Tarifa FBA por unidad arriba de la tarifa normal del SKU',DATA.mes,r.vu,r.val.toFixed(2),'Validar antes de actuar','Ver Order IDs en el reporte de transacciones','Tarifa FBA de la orden (menos el envío y la envoltura de regalo que pagó el comprador × 1.16) vs la tarifa más frecuente del SKU en su banda de precio ($299 o más / menos de $299)','Ayuda > Obtener soporte > Vender en Amazon > Reconcile Charges > Review Fees > Order ID > Contact an associate > Email','Posible diferencia por validar. No es dinero garantizado: Amazon decide.']});
  rows.push(['TOTAL','',DATA.mes,vun,vtot.toFixed(2),'','','','','']);
  return '\ufeff'+[h].concat(rows).map(function(r){return r.map(esc).join(',')}).join('\r\n');
}
$('csvt').value=csv();
var btn=$('dl');
btn.addEventListener('click',function(){
  var ds=window.__dl; if(!ds)return;
  $('dm').textContent='';
  ds.save({filename:'expediente-cobros-por-validar-'+DATA.mes.replace(/\s+/g,'-')+'.csv',data:csv()}).then(function(){
    $('dm').textContent='Listo. Revisa tu carpeta de descargas.';
  }).catch(function(e){
    var c=e&&e.code;
    $('dm').textContent=c==='declined'?'Descarga cancelada. Puedes intentarlo otra vez.':c==='rate_limited'?'Espera unos segundos e inténtalo de nuevo.':'La descarga no está disponible en esta vista.';
  });
});
$('dm').textContent='';
if(window.claude&&window.claude.use){
  window.claude.use('downloads').then(function(d){
    if(d){window.__dl=d;btn.disabled=false}else{$('dm').textContent='La descarga no está disponible en esta vista.'}
  }).catch(function(){$('dm').textContent='La descarga no está disponible en esta vista.'});
}else{$('dm').textContent='La descarga no está disponible en esta vista.'}


render();
/* v1.5: avisos grandes arriba de la tabla (D21, D24 y los que mande la skill) */
var AV=(DATA.avisos||[]).map(function(a){return hx(a)}); /* textos de la skill: se escapan */
if(FALTA_COSTO)AV.unshift('<b>Sin tus costos no puedo decirte cuánto deja cada producto realmente.</b> Falta el costo de '+N_SIN_COSTO+(N_SIN_COSTO===1?' producto':' productos')+' con venta: su contribución, el subtotal y la CONTRIBUCIÓN DEL CANAL están sobrestimados. Dame el costo unitario y lo corro completo.');
if(FRONT_SOSP)AV.push('<b>Detente antes de usar los números: la retención de IVA da '+fpt(RET_PCT)+' de la venta sin IVA, no 8%.'+RANGO_FRONT()+'</b> Eso pasa cuando vendes con el IVA de región fronteriza (8%). ¿Vendes con el estímulo de región fronteriza? Si sí, lo corro con IVA de 8% en tus impuestos (las bases se dividen entre 1.08; la publicidad sigue con el 16% de la factura de Amazon Ads). Mientras, todo está POR VALIDAR y no hay decisiones.');
if(RET_MEZCLA)AV.push('<b>Detente antes de usar los números: la retención de IVA da '+fpt(RET_PCT)+' de la venta sin IVA, entre 4% y 8%.'+RANGO_MEZCLA()+'</b> Eso pasa cuando una parte de tus ventas lleva el IVA de región fronteriza (8%) y otra el general (16%). ¿Tienes ventas con y sin el estímulo de región fronteriza? Mientras, todo está POR VALIDAR y no hay decisiones.');
if(RET_RARA)AV.push('<b>Detente antes de usar los números. Revisar la retención de IVA:</b> da '+fpt(RET_PCT)+' de la venta sin IVA'+RET_RANGO()+' y debería dar '+fp(RET_ESP,2)+'. Puede ser que no diste tu RFC a Amazon (retención del 100%), un reembolso grande o un error en los datos. Validar antes de actuar.');
/* v1.7.1 (D57): aviso fuerte cuando hay gasto en el archivo de Ads y no hay cargo de publicidad en el reporte */
var AVISO_CAJA_SIN_CARGO=true; /* v1.8: PRENDIDO por decisión de Gerardo del 19-oct-2026 a las 10:20 */
if(AVISO_CAJA_SIN_CARGO&&!pubRows.length&&GASTO_ADS>0.005)AV.push('<b>Revisa tu caja: no encontré el cargo de publicidad en el reporte.</b> Si pagaste '+fm(GASTO_ADS,2)+' de Ads con tarjeta, tu caja real es '+fm(Math.round((CAJA-GASTO_ADS)*100)/100,2)+', no '+fm(CAJA,2)+'.');
if(RET_CERO)AV.push('<b>No encontré la retención de IVA</b> (debería ser '+fp(RET_ESP,0)+' de la venta sin IVA, ≈ '+fm(Math.round(RET_ESP*VSIN*100)/100,2)+'). ¿Falta la columna? La CONTRIBUCIÓN DEL CANAL queda POR VALIDAR.');
if(ISR_DESC)AV.push('<b>Revisar el ISR devengado:</b> la tabla suma '+fm(S.isr,2)+' y el 2.5% de la venta sin IVA (venta ÷ '+FTXT+') da '+fm(ISR_ESP,2)+'. Validar antes de actuar.');
if(IVA_RARA)AV.push('<b>Detente antes de usar los números. Tasa de IVA no reconocida:</b> '+hx(DATA.ivaTasa)+'. Solo se aceptan 0.16 (general) y 0.08 (región fronteriza confirmada). No revisé la retención ni el ISR; todo queda POR VALIDAR y no hay decisiones.');
if(PUB_DESC)AV.push('<b>Revisar la publicidad:</b> el gasto SP del archivo de Ads ('+fm(DATA.pubAsignada,2)+' sin IVA) no es la suma de la publicidad por producto más la no asignable ('+fm(PUB_RAW,2)+' sin IVA). Validar antes de actuar.');
if(PUB_INCONG)AV.push('<b>Revisar la publicidad:</b> el gasto de Ads del mes (Sponsored Products + marca: '+fm(GASTO_ADS,2)+') es mayor que el cargo de publicidad del mes'+(' (los dos con IVA)')+' ('+fm(pubCargo,2)+'). Puede ser un cobro de otro mes, publicidad pagada fuera de Amazon o un error en los datos (por ejemplo, el IVA puesto dos veces). Validar antes de actuar.');
if(NA_NEG<0)AV.push('<b>El archivo de Ads trae más gasto por anuncio que el total de Sponsored Products</b> ('+fm(-NA_NEG,2)+' con IVA). Usé el gasto por anuncio, que es el mayor (versión conservadora): el renglón «no asignable» queda en $0 y no suma contribución. Validar antes de actuar.'); /* v1.8.3 (D69) */
/* v1.8.3 (D75): los dos primeros avisos a la vista; los demás, plegados */
$('avisos').innerHTML=AV.slice(0,2).map(function(a){return '<div class="warnbox">'+a+'</div>'}).join('')+(AV.length>2?'<details class="avm"><summary>Ver '+(AV.length-2)+(AV.length-2===1?' aviso más':' avisos más')+'</summary>'+AV.slice(2).map(function(a){return '<div class="warnbox">'+a+'</div>'}).join('')+'</details>':'');
document.body.setAttribute('data-orden-decisiones',JSON.stringify(['1 Proteger · Hacer hoy','2 Arreglar · Probar y medir','3 Detener fuga · Auditar o validar'])); /* v1.8.7 (D89): orden y etiquetas fijos, iguales en el chat y en el resumen */
document.body.setAttribute('data-decisiones',JSON.stringify(DECISIONES));
})();
</script>
~~~


---


## 15. Guardar el resultado (paso final obligatorio)


Al terminar, **siempre** se entrega en el chat un bloque **«Resumen para guardar»** (texto plano) con: tienda, mes, versión de la skill (la del título de esta skill, «# Diagnóstico de Rentabilidad Amazon México · vX»: es la única fuente de la versión; no se escribe otra), archivos usados (nombre y rango), Contribución de productos, Contribución del canal (con y sin ISR si no está confirmado), Gasto SP total, SB y SD (sin IVA, tal cual el archivo de Ads, rotulados así), diferencia cobro vs gasto de Ads (la de la página), por validar (FBA y comisión por separado), las 3 decisiones (en el orden fijo 1 Proteger · Hacer hoy, 2 Arreglar · Probar y medir, 3 Detener fuga · Auditar o validar; sección 10), resultado de los cuadres 1 a 12, la línea de parámetros fiscales (sección 2) y lo que faltó. **«Qué faltó» nombra «flete y aduana» siempre que falten** (sin costos, columna F vacía, F = «No» sin montos, o la pregunta sin respuesta) (v1.8.9).


**Cierre literal en dos bloques (v1.8.9).** Se copian tal cual; no se parafrasean, no se les agrega ni quita nada y no se escribe ninguna otra frase sobre guardar.


**Bloque A — última línea del mensaje del diagnóstico** (después del «Resumen para guardar»; nada va después):


> **¿Quieres que guarde este resumen y el CSV?** Puedo hacerlo solo si en esta conversación tienes conectada una carpeta tuya (por ejemplo Google Drive) o un Proyecto de Claude. Si no, cópialo tú.


En el mensaje que lleva el bloque A **no existe** ninguna frase que diga si algo quedó o no quedó guardado, aunque ya sepas que no hay conector: primero se pregunta, siempre.


**Bloque B — solo en el turno siguiente, según la respuesta:**


- **Dice que sí y hay conector:** guardar en la carpeta que el vendedor diga, con el nombre `AAAA-MM-DD — <tienda> — Diagnóstico de rentabilidad <mes>`; **volver a leer** el archivo guardado, confirmar que existe en esa carpeta y dar la liga.
- **Dice que no, dice que sí pero no hay conector, o no se pudo verificar:** el mensaje completo es, textual, una de estas dos variantes y nada más (v1.8.10, D109):
  - **Si el CSV no se pegó en el chat** (lo normal: la descarga funciona):


> No quedó guardado.
> Copia el resumen de arriba y descarga el CSV desde el artefacto.


  - **Si el CSV sí se pegó en el chat** (la descarga falló o el vendedor lo pidió):


> No quedó guardado.
> Copia el resumen y el CSV de arriba para tenerlos a la mano.
- **Nunca** se guarda nada sin que el vendedor lo pida, y nunca en una carpeta que no eligió él.


### Autoverificación antes de enviar cualquier mensaje (v1.8.9, bloqueante)


Antes de enviar, relee tu mensaje y contesta cada punto. Si uno falla, corrige el mensaje antes de enviarlo:


1. ¿Es el mensaje del diagnóstico? Entonces su última línea es el bloque A de la sección 15 y **no** contiene «quedó guardado» en ninguna forma.
2. ¿Contiene «quedó guardado»? Solo se permite en el bloque B, y la línea es exactamente «No quedó guardado.» (termina en el punto, sin «en», sin lugar).
3. ¿Aparece un nombre propio de sistema, proyecto o lugar de almacenamiento que el vendedor no escribió? Bórralo.
4. ¿Es el turno 1? Pasa la lista de control del turno 1 (sección 0), los cinco puntos.
5. ¿Afirmas algo del artefacto («sin desborde», «probado», un ancho)? Solo lo que mediste en esta conversación, con el ancho medido. Si el HTML corrió, el conteo de celdas y la medida a 1300 px **sí van** (sección 11); solo 390 px puede decir «no lo medí».
6. **¿Das una cifra que no copiaste de la página** (turno 1, montos de SKU sin costo, porcentajes, totales)? Salió de código con la fórmula completa de la sección 3, no de una sola columna ni de una muestra (v1.8.10, D115).
7. ¿Todo porcentaje va con 1 decimal (salvo la retención de IVA)? (D108) **Busca cada «ACOS» y cada «TACOS» de tu mensaje, uno por uno:** cada uno tiene que ir seguido de «de Sponsored Products», «de marca (SB/SD)» o «total de la cuenta» antes de su cifra. Si uno no lo trae, corrígelo (D113, D117).
8. ¿Pegaste un enlace o URL del artefacto? Bórralo (D112). ¿Pegaste el CSV en el chat? Solo si la descarga falló o el vendedor lo pidió (D111).
