---
name: "pas-diagnostico-rentabilidad-v1-2"
description: "v1.2 · Profit AI System · Diagnóstico de Rentabilidad Amazon (recurso de entrada). Convierte 4 reportes de Seller Central en un artefacto con branding: tabla Parent/Child, cargos de cuenta, cobros por validar con CSV. Amazon MX y USA. Úsala para diagnóstico de rentabilidad, qué producto deja dinero o qué cobros revisar."
---

# Diagnóstico de Rentabilidad Amazon · v1.2

> **Profit AI System** · Recurso de entrada · **v1.2** · 2026-10-13
> Historial: v1.0 base · v1.1 diseño con marca primero (no se publicó) · **v1.2 trae la plantilla del artefacto dentro de la skill (sección 14) y los cargos de cuenta**. La siguiente será v1.3. Si hay otra versión instalada con nombre `pas-diagnostico-rentabilidad` (sin sufijo), es la vieja: usar esta.
>
> **Qué hace:** con 4 reportes de Seller Central entrega la contribución por producto y las 3 decisiones que más mueven la utilidad del mes.  
> **Entradas:** país, mes cerrado, 4 reportes originales y costo de producto confirmado (por chat o con la plantilla `PAS_Plantilla_Costos_por_Child.xlsx`).  
> **Salida:** un artefacto con branding Profit AI System (secciones 10 y 14) y en el chat las 3 decisiones.  
> **Ejemplo de uso:** «Hazme el diagnóstico de rentabilidad de septiembre, Amazon México».  
> **Regla:** la skill propone; el vendedor revisa y decide. Nunca modifica nada en Amazon.

Seller Central te da datos. Esta skill te da decisiones.

Funciona en **Amazon México y Amazon Estados Unidos**. La tienda se pregunta al inicio, se confirma contra el propio reporte, y las reglas de impuestos se aplican solas.

**Esta skill no trae datos de ninguna tienda.** Todo número sale de los reportes que sube la persona; la plantilla de la sección 14 llega vacía.

---

## 0. El primer mensaje — se sigue al pie de la letra

Se le entrega a alguien que **no vio ningún video**. El primer mensaje tiene que funcionar solo. Nunca se abre con una lista de cuatro reportes.

### Lo primero, textual

> **Esto corre en tu propia cuenta de Claude. Tus reportes no salen de aquí, nadie más los ve, y no se guardan en ningún lado.**

### Luego, dos preguntas. Solo dos.

**Pregunta 1 — la tienda:**

> **¿Vas a analizar Amazon México o Amazon Estados Unidos?** Si vendes en las dos, escogemos una y después corremos la otra. No se mezclan: los impuestos y las comisiones son distintos.

**Pregunta 2 — el periodo:**

> **¿Qué mes quieres analizar?** Tiene que ser un **mes calendario completo y ya cerrado**. Por ejemplo: agosto 2026, del 1 al 31.

- **Mes cerrado.** El mes en curso no sirve: las liquidaciones no terminan y el análisis sale chueco sin que nadie lo note. Si pide el mes en curso, se ofrece el anterior.
- **Mes calendario completo.** Nada de «últimos 30 días». Los cargos globales (ISR en México, suscripción, almacenamiento) se cobran por mes calendario.
- El mes elegido **se repite de vuelta** para confirmarlo, y es el mismo rango para los tres reportes que llevan fechas.

**No se pide ningún archivo hasta que las dos preguntas estén contestadas.**

### Después, un reporte a la vez

Se pide el primero, se espera, se confirma que llegó bien y **hasta entonces** se pide el siguiente. Cada petición dice qué es, dónde está el botón y para qué sirve.

**El primero es siempre el de transacciones**, el único sin el cual no hay diagnóstico:

> **Reporte 1 de 4 — el más importante.** En Seller Central: **Pagos › Reports Repository › Rango de fechas › tipo Transacción**. Escoges tu mes completo, lo generas y lo descargas en **CSV**.

**Los tres errores que se nombran antes de que ocurran:**

- **No uses el botón *Download* de Transaction View.** Está topado a 600 transacciones y **corta los datos sin avisar**.
- **No es el reporte *Summary*.** Trae totales, no movimientos. Es **tipo Transacción**.
- **Bórrale las columnas con datos de tus compradores** antes de subirlo (nombre, dirección, ciudad, estado, código postal, correo, teléfono). Si llegan, **no se leen, no se copian a ningún entregable, y se avisa.**

Al llegar el archivo se confirma tienda y rango contra el CSV. Si no coincide con lo dicho, **se avisa antes de calcular** — no se corrige en silencio.

Después, de uno en uno: **Business Report por child ASIN**, **Bulk de publicidad**, **Fee Preview**. Los tres se pueden saltar; el de transacciones no.

### Si el vendedor llega sin contexto

Si escribe «hola» o cualquier cosa que no sea un archivo, tres líneas —qué hace, qué necesita, qué recibe— y se arranca con la pregunta 1. **Nunca se devuelve un manual.**

---

## Las cuatro reglas que no se rompen

**1. Ningún número se inventa.** Si un dato no está en un reporte, se pide. Si no se puede saber, se dice y por qué.

**2. El reporte detecta, el sistema corrige.** Se puede probar que hay una fuga y cuánto mueve. **No** se puede saber qué campaña, término o parte del listing es responsable. Cada hallazgo es **ALERTA** u **OPORTUNIDAD** con su cifra, nunca una orden que el dato no sostiene.

**3. Nunca se detiene.** Si falta un archivo o un costo, se entrega lo que sí se puede y se dice en grande qué falta y qué se pierde.

**4. Nunca se promete dinero.** Los cobros por validar son **posibles diferencias**. Amazon decide.

---

## 1. Lo que se le pide

Referencia interna; **al vendedor se le pide de uno en uno**.

| # | Reporte | Dónde sacarlo | Para qué sirve |
|---|---|---|---|
| 1 | **Rango de fechas · tipo Transacción** (CSV) | Pagos › Reports Repository | Ventas, comisión, FBA, devoluciones, impuestos y cargos de cuenta. Es el corazón |
| 2 | **Ventas y tráfico por página de detalle (child)** | Business Reports | Sesiones y unidades → conversión |
| 3 | **Bulk de Publicidad** (.xlsx) | Publicidad › Operaciones masivas | Gasto y ventas por ads, por SKU |
| 4 | **Vista previa de comisiones / Fee Preview** | Logística de Amazon › Pagos | Nombres, ASIN y SKU para el mapeo |

Solo el 1 es obligatorio; los demás degradan con gracia (sección 12). Mismo mes completo y cerrado en 1, 2 y 3.

### Los costos — se preguntan, nunca se estiman

Sin costos no hay retorno sobre costo, y es la mitad del valor. Se piden siempre y se insiste una vez.

- **15 SKU o menos** — en el chat, producto por producto, mostrando la lista detectada en sus reportes.
- **Más de 15 SKU** — se entrega la plantilla **`PAS_Plantilla_Costos_por_Child.xlsx`** (hoja «Costos por Child»: ASIN Child, SKU, nombre, ASIN Parent, costo unitario, ¿incluye flete y aduana? Sí/No, flete, aduana, otros costos, costo total por unidad, «Agrupar con», notas). Se llena **por Child, por ASIN o por SKU**, se sube y se cruza con el universo de SKU. Un Child sin costo se lista con nombre y monto: **no se le inventa costo.**

**Pregunta obligatoria antes de calcular:**

> «¿El costo que me das ya incluye todo lo que te cuesta tener el producto en la bodega, o el flete y la aduana van aparte?»

- **Ya puesto en bodega** → flete y aduana en **cero por definición**. **Queda prohibido volver a insinuar que faltan** o que los márgenes están inflados. Se escribe: *«el costo unitario es el costo real del producto puesto en tu bodega, confirmado por ti»*.
- **Flete y aduana aparte** → se piden; si no los tiene, se corre con aviso de márgenes inflados y ejemplo numérico.

**Si no da costos:** se corre igual (cobros, publicidad, cargos, devoluciones no dependen de costos) y arriba va:

> **Sin tus costos no puedo decirte cuánto deja cada producto realmente.** Te falta el retorno sobre costo, que dice si un producto vale la pena crecerlo o arreglarlo antes. Dame el costo unitario y lo corro completo.

### Opcional

- **Inventario FBA** — sin esto no hay rotación ni cobertura. **No se estiman con las unidades del mes.**
- **Un mes anterior** — un mes es foto, dos son tendencia.

---

## 2. Confirmar la tienda antes de calcular

Del reporte 1: columna `marketplace` y moneda. Si contradice lo dicho, se avisa y se resuelve antes de seguir.

| Tienda | Impuesto en la venta | Base de la comisión | Retenciones |
|---|---|---|---|
| **México** | IVA 16% incluido | Precio **con** IVA | IVA: 50% del trasladado · ISR: 2.5% de la venta sin IVA |
| **Estados Unidos** | Sales tax lo maneja Amazon | Precio de venta | Ninguna |

**Nunca se mencionan retenciones ni IVA en una cuenta de USA.** En USA se explica una vez por qué no hay columnas de impuesto: el *marketplace withheld tax* cancela el *product sales tax*.

### Reglas de México

`venta bruta` = lo que pagó el comprador, con IVA. `venta neta` = bruta ÷ 1.16. **Toda tasa se calcula sobre venta neta.** Si una división da ≈2.16% en vez de 2.5%, se usó la base con IVA: se rehace.

**La venta se reporta con IVA** y se dice cada vez que se muestra un porcentaje sobre venta. No se muestra columna de IVA trasladado.

**IVA retenido:** 50% del trasladado, columna `impuesto de retenciones en la plataforma`, ≈ 8% de la venta neta. Si no da 50.0%, investigar antes de reportar.

**ISR — el error que casi todos cometen.** Amazon México lo cobra como **un cargo mensual global, sin SKU y con descripción vacía**, sobre la venta del **mes anterior**. Dos cifras distintas que **nunca se suman**:

- **ISR devengado del mes analizado** — el 2.5% repartido por producto. Resta en la contribución por producto. **No salió de la cuenta este mes.**
- **ISR cobrado en el mes** — el cargo global (mes anterior). **Ese sí salió de la cuenta** y es el único que entra al bloque de caja.

> **Efectivo de impuestos del mes = IVA retenido + ISR cobrado.** Restar además el devengado cuenta el impuesto dos veces.

**Cómo confirmar que ese cargo sin descripción es el ISR:** dividirlo entre la venta neta del mes anterior. Si da ≈ 2.5%, es ISR, **no es reclamable** y **vive solo en el bloque de impuestos y en los cargos de cuenta**: no vuelve a aparecer como «cargo sin explicación» ni como dinero por validar.

**Retenciones no son costo.** Son impuesto adelantado que se acredita.

### Los tres cobros nunca se mezclan

| Cobro | Qué es | Cómo se valida |
|---|---|---|
| **Comisión por referencia** | Porcentaje por vender | Tasa real vs tarifa publicada de la categoría |
| **Tarifa FBA** | Logística por unidad | La tarifa más frecuente de ese SKU en el mes |
| **Publicidad** | SP, SB y SD | Cuadre contra la consola de Amazon Ads |

**Antes de escribir una cifra se verifica de qué campo salió.** Si dos cifras de bloques distintos coinciden casi al peso, es la misma cifra mal etiquetada.

**En México** `tarifas de venta` y `tarifas fba` **vienen con IVA**: dividir entre 1.16 antes de cualquier porcentaje.

**En USA la comisión es escalonada** (típico: 10% hasta $20, 15% en Health & Personal Care, 17% en Apparel arriba de $20). Tasas distintas entre productos no es error. El hallazgo es **dos SKU del mismo producto con tasas distintas**.

---

## 3. La cadena de contribución

```
Ventas totales   = producto + envío + promoción (viene NEGATIVA en el CSV: se suma tal cual) (+ IVA en MX)
Util. bruta      = Ventas totales − comisión por referencia − tarifa FBA − costo de producto
Util. tras ads   = Util. bruta − publicidad (solo Sponsored Products)
Contribución del producto = lo anterior + devoluciones + ajustes FBA − IVA retenido − ISR devengado
```

**No se le llama «utilidad neta» a nada de esto.** El agregado se llama **`Contribución del canal antes de retenciones`**. Son contribución, no utilidad contable.

**Cargos de cuenta** (publicidad global, suscripción, almacenamiento, servicios, ISR cobrado) van en su propio bloque (secciones 10 y 14). **No se prorratean dentro del margen de un producto, pero sí cuentan en la contribución del canal.** Se resta la publicidad ya asignada por SKU para no contarla dos veces.

### Publicidad: solo Sponsored Products baja a producto

- Las filas de producto llevan **solo SP**. ACOS y TACOS de la tabla miden únicamente SP, y así se dice.
- SB y SD van en su propio bloque, **rotulado «PUBLICIDAD DE MARCA — NO BAJA A PRODUCTO»**, y **ya están descontados una sola vez dentro de los cargos de cuenta**. Decirlo.
- **En el bulk una campaña de SB puede aparecer en dos hojas** (`Sponsored Brands Campaigns` y `SB Multi Ad Group Campaigns`). Deduplicar por Campaign ID.
- No se asume que una cuenta no tiene SB o SD: se abre el bulk y se revisa.

**La transferencia a banco NO es un costo.** Se excluye siempre y se dice.

---

## 4. Cobros que merecen validación

No depende de los costos: sale completo de los reportes.

**Lenguaje obligatorio:** **«posible diferencia»**, **«por validar»**, **«evidencia para abrir caso»**. Nunca «te deben», «vas a recuperar» ni «dinero garantizado».

| Etiqueta | Cuándo |
|---|---|
| **Evidencia para abrir caso** | Hay tarifa publicada contra la cual comparar y la desviación es consistente |
| **Validar antes de actuar** | El método es estadístico, o falta el concepto exacto |
| **Sin anomalía detectada** | Se revisó y cuadra. **Se escribe igual:** un renglón en cero prueba que se revisó |

### Comisión por referencia arriba de la tarifa publicada

Por pedido: tasa real vs tarifa publicada. Solo desviaciones **consistentes**. Lo que vuelve defendible el caso: **el mismo SKU cobrado a dos tasas en el mismo mes**. Se reporta monto **y cuántos SKU o Child ASIN**.

### Tarifa FBA fuera de rango

El Fee Preview trae la tarifa **de hoy**, no la del día de cada venta. **La referencia sale de los propios datos:** la tarifa por unidad más frecuente del SKU en el mes; las órdenes que pagaron más son el hallazgo (Order ID, fecha, unidades, exceso).

Como es estadística, **se etiqueta «validar antes de actuar»** y va **separada** de la comisión: no se suman en un titular. La referencia se construye con unidades **de las órdenes**, no netas de devoluciones.

Un SKU que cobra de más sistemáticamente suele ser **peso o dimensiones mal medidos**: ruta **FBA product weights and dimensions**.

Al pie: *«$0 de exceso significa que ninguna orden se salió de la tarifa normal de ese SKU; no significa que la tarifa normal sea la correcta.»*

### Cargos sin descripción

Antes de ponerlos por validar, la división de la sección 2. Si da ≈ 2.5%, es ISR y sale de este bloque.

### Ruta del caso

Ayuda › Obtener soporte › Vender en Amazon › **Reconcile Charges** › **Referral Fee** › **Review Fees** › Order ID › **Contact an associate** › pestaña **Email**. **Nunca por chat.** Se entrega asunto y cuerpo listos. Si a los 3 días no contestan, se responde **en el mismo caso**.

---

## 5. Cuadres — sin esto no se entrega nada

**Cada peso de los reportes termina en algún renglón.** Lo no asignable se muestra con su monto y nombre. Nunca se descarta en silencio.

| # | Qué se suma | Contra qué debe dar | Tolerancia |
|---|---|---|---|
| 1 | Todas las filas del reporte 1, sin filtrar | Contribución + costo de producto + publicidad − cargos de cuenta − transferencias | $0.00 |
| 2 | Cada `tipo` y `descripción` distintos | Total del CSV, cada tipo con destino | $0.00 |
| 3 | Ventas de SKU mapeados + sin mapear | Ventas totales del CSV | $0.00 |
| 4 | Gasto SP por SKU + no asignable + SB + SD | Gasto total en Amazon Ads | 1% |
| 5 | Filas de campaña del bulk | Campaign IDs únicos (dedup, decir cuántas y por cuánto) | exacto |
| 6 | Comisión y FBA por producto, **con IVA re-agregado en MX (×1.16)** | Totales del CSV con negativos | $0.00 |
| 7 | Unidades brutas del Business Report | Transacciones + devueltas | 6% · 1.5 días de cola |
| 8 | **Caja:** ventas − costos directos − cargos de cuenta sin ISR − IVA retenido − ISR **cobrado** | El renglón de caja publicado. Si el devengado aparece restado, falla a propósito | $0.00 |

**Si un cuadre no da, el descuadre va arriba, en el encabezado, con monto y qué no se ubicó.**

### Reglas duras

- **Join externo, siempre.** Universo de SKU = transacciones ∪ bulk ∪ Fee Preview. Un SKU sin listing activo aparece igual como `(sin listing activo)`.
- **Un tipo de transacción o cargo que no se sabe clasificar detiene el cálculo y se pregunta.** Nunca un saco de «otros».
- **Todo lo no asignable existe como renglón visible, aunque valga $0.**
- **El join con sesiones es por ASIN.** Sin venta o sin sesiones → conversión **vacía, no cero**.
- Una línea al cierre: **«N transacciones revisadas, $X conciliados, $Y sin clasificar.»**

---

## 6. El Business Report nunca va a cuadrar, y está bien

Por qué difiere: **dos relojes** (fecha del pedido vs envío/cobro), **bruto vs neto**, **cancelaciones**, **zona horaria** (transacciones en GMT-7), **definición de venta** (`Ordered Product Sales` sin envío ni promociones).

> `días de cola = (unidades Business Report − unidades transacciones − devueltas) ÷ (unidades del mes ÷ días del mes)`

**≤ 1.5 días** es rezago normal; **> 1.5** se investiga antes de entregar.

**Frase fija arriba del entregable:**

> **Este reporte mide cobros del mes, no pedidos del mes.** La diferencia de unidades se explica por devoluciones, tránsito y fechas de liquidación de Amazon.

---

## 7. Retorno sobre costo y volumen

> `Contribución por unidad = Contribución del producto ÷ unidades vendidas`
> `Retorno sobre costo = Contribución por unidad ÷ costo unitario del producto`

**Redacción obligatoria:**

> **Retorno sobre costo muestra cuánto deja cada peso invertido en producto** después de comisiones, logística, publicidad y demás costos incluidos. Un retorno de 81% significa que por cada $1 invertido, recuperaste ese $1 y además quedaron **$0.81 de contribución**. Arriba de 100% es excelente; entre 70% y 99% sigue siendo rentable, pero con menos margen para errores, descuentos o costos nuevos.

**Prohibido decir** «no se repone solo». Un retorno positivo ya recuperó el costo. **No es margen sobre venta.**

| Semáforo | Banda | Qué significa |
|---|---|---|
| **SÚPER SANO** | ≥ 150% | Regresa y deja $1.50 o más. Aquí va presupuesto e inventario |
| **SANO** | 100–149% | Regresa y deja más de otro peso. No se toca |
| **ACEPTABLE** | 70–99% | **Rentable, con oportunidad de mejora** |
| **REVISAR** | 45–69% | Deja contribución, margen de maniobra estrecho |
| **PELIGRO** | 20–44% | El capital regresa muy lento |
| **PIERDE** | < 20% | La contribución no cubre el ciclo |

**Ajuste por flete y aduana — solo si aplica.** Se omite si el costo es puesto en bodega. Si faltan y suman ~20% del costo: 295% → ~229% · 88% → ~57% · 70% → ~42% · 52% → ~27% · 25% → ~4%.

### Volumen (en pesos de contribución, % de la contribución de producto del canal)

| Tier | Banda |
|---|---|
| **CORE** | ≥ 10% |
| **RELEVANTE** | 2–10% |
| **MARGINAL** | 0.5–2% |
| **RUIDO** | < 0.5% |

### Matriz retorno × volumen

|  | CORE | RELEVANTE | MARGINAL / RUIDO |
|---|---|---|---|
| **SANO / SÚPER SANO** | Protégelo. Nunca sin stock | Escala fuerte | Rentable con inversión limitada; validar espacio para crecer |
| **ACEPTABLE** | Arréglalo antes de crecerlo | Sube precio 5–10% y mide | Déjalo quieto |
| **REVISAR / PELIGRO** | EMERGENCIA | Cortar publicidad y arreglar precio o empaque | Descontinúa, salvo venta real (entonces es ticket) |
| **PIERDE** | Para las ventas hoy | Para las ventas hoy | Sácalo del catálogo |

**TACOS:** < 5% o publicidad muy baja = vende poco porque nunca lo anunciaste (probar con presupuesto acotado). > 15% con presupuesto real = ya lo empujaste y no jaló. **De un gasto insignificante no se concluye «no hay mercado».**

La lógica de `salud`, `tier` y `accion` está implementada en la plantilla de la sección 14; **no se reescribe**.

### Reglas de cálculo

- **Subtotales y totales van SIN Volumen ni Acción.** El semáforo sí se pinta.
- En subtotales el costo unitario es **promedio ponderado por unidades**; ACOS, TACOS y todo porcentaje **se recalculan desde los totales**, jamás se suman ni se promedian.
- Todo producto en REVISAR, PELIGRO o PIERDE que sea CORE o RELEVANTE **entra a las 3 decisiones del cierre en el chat**.

### Dos límites

**El retorno no ve la velocidad** (requiere inventario real). **El ratio no ve la contribución absoluta**: contribución muy baja no absorbe costos fijos aunque se arregle el ratio.

---

## 8. Variantes, Parents y Children

Dos renglones que son **el mismo producto en otra talla** y comparten costo van en uno solo (`Producto (XL + normal)`); **qué se agrupa lo decide el vendedor** (columna «Agrupar con» de la plantilla de costos).

**Cuando los Children de un Parent no se parecen:** si el rango de retorno entre el mejor y el peor Child supera **40 puntos**, el Parent esconde el problema: marca **«Decidir por Child»**, aviso con el Child que arrastra, y **no se da instrucción general para la familia**. La plantilla ya lo calcula.

---

## 9. Alerta vs instrucción

**SÍ puede decir:** cuánto gasta y deja un producto, que su ACOS/TACOS o devoluciones están fuera de rango, que su retorno es bajo, cuánto dinero está en juego.

**NO puede decir:** «pausa la campaña X», «lleva el ACOS a 30%» (sin calcular el ACOS máximo rentable del SKU), «negativiza estos términos», «el problema es el listing».

```
ALERTA / OPORTUNIDAD: <qué pasa, en una línea>
<cifras: ventas, contribución, publicidad, retorno>
El reporte general detectó <el hecho>, pero todavía no dice <qué falta saber>.
Siguiente paso: abrir el <Sistema> para <qué abre> y decidir <qué se decide>.
```

| Problema | Sistema |
|---|---|
| Gasto publicitario ineficiente, ACOS/TACOS alto | **Sistema de Optimización de Pujas** |
| Producto rentable que no crece | **Sistema de Escalamiento y Nuevas Campañas** |
| Baja conversión, listing débil | **Sistema de Optimización de Listings e Imágenes con IA** |
| Margen, precio u oferta | **Sistema de Precio y Oferta** |
| Cobros que merecen validación | **Auditoría y Recuperación Amazon** |

---

## 10. El entregable

**Un solo artefacto**, publicado con la herramienta Artifact (privado). No Excel ni archivos sueltos; el CSV de cobros es la única descarga y sale del propio artefacto. Una sola vista oscura.

**El artefacto se construye con la plantilla de la sección 14, sin rediseñarla.** Antes: cargar `artifact-design` y `artifact-capabilities`. Publicar con `capabilities: {downloads: true}` (el CSV usa `claude.use('downloads').save(...)`; el vendedor confirma el guardado y puede declinar).

### Estructura, en este orden

0. **Marca primero:** barra fija con logomark + «PROFIT AI SYSTEM» y encabezado grande «Profit AI System · Diagnóstico de Rentabilidad Amazon · por Gerardo Villa», con tienda, periodo, moneda y la línea de privacidad *«Corrió en tu propia cuenta. Tus reportes no salieron de ahí.»*
1. **Tabla de productos:** pestañas **Parent / Child**, selector **Columnas clave / Todas**, encabezados ordenables, fila TOTAL, «Decidir por Child», leyenda de bandas.
2. **Cargos de cuenta** (abajo), con este rotulado y orden de mayor a menor cargo; los de abajo son el orden típico:
   - **CARGOS QUE AMAZON NO ATA A NINGÚN PRODUCTO**
   - Publicidad (cargo global de cuenta)
   - Tarifa de servicios Premium
   - ISR retenido de <mes anterior> (2.5% s/venta sin IVA) — *informativo, ya repartido por producto* (**solo MX**)
   - Almacenamiento mensual FBA
   - Envío con transportista asociado FBA
   - Suscripción Seller Central
   - Transporte de envíos a Amazon
   - Almacenamiento prolongado FBA
   - Retiro de inventario FBA
   - **(-) Publicidad ya asignada por producto** (en positivo)
   - **TOTAL CARGOS DE CUENTA**
   - Debajo: **PUBLICIDAD DE MARCA — NO BAJA A PRODUCTO** (gasto SB/SD, ventas SB/SD, ACOS).
3. **Cobros por validar + CSV descargable** (Order ID, fecha, SKU/ASIN, concepto, cobrado, esperado, diferencia, etiqueta; BOM UTF-8; sin datos del comprador), con el texto: *«Vimos $X que Amazon podría haberte cobrado de más en <mes>. Aún hay que revisar producto por producto antes de reclamarlo. **No es dinero garantizado.**»*

**Pie:** marca y sello **«$5M+ USD en ventas verificadas en Amazon MX/USA»**.

### Reglas del bloque de cargos

- Nombres de Amazon, tal cual del reporte 1. **Un cargo que no está en la lista entra con su propio nombre**; nunca «otros». Un cargo en $0 se queda en cero.
- **El TOTAL CARGOS DE CUENTA es la suma de todos los renglones, incluido el ISR, más la publicidad ya asignada por producto.** (Ejemplo de referencia: renglones por −$120,151.51 + ISR −$12,801.91, y +$86,257.10 de publicidad ya asignada, dan −$46,696.32.) La plantilla lo calcula.
- **El gasto compartido real (sin ISR)** = TOTAL − ISR; es el que entra a la contribución del canal y al bloque de caja (sección 11). **Tiene que cuadrar** con el cuadre 1; si no, el descuadre va arriba.
- En USA no existe el renglón de ISR.

### Qué NO va en el artefacto

Las **3 decisiones** (proteger / arreglar / detener fuga) van **en el cierre del chat**: una por línea, con producto o grupo · ventas · contribución · publicidad · retorno y la etiqueta **Hacer hoy / Probar y medir / Auditar o validar**, en formato alerta/oportunidad. El bloque de caja, la matriz, el puente y «Cómo leer esto» **no se incluyen** salvo que el vendedor los pida. **El diagnóstico no es página de venta**: una sola línea al cierre nombra el siguiente sistema.

### Muestra para captura de pantalla

Si el artefacto es de **muestra**: `DATA.muestra=true`, **sin datos de ninguna tienda real** (nombres «Producto A…», sin ASIN, SKU, Order IDs ni nombre de cuenta); si no hay datos Child, no se inventan hijos y se dice.

### Antes de publicar

- Ejecutar el HTML (Playwright o equivalente) y **contar celdas**: `<td>` de cada fila = `<th>` = suma de los `colspan`, en Parent y Child y en Clave y Todas.
- `scrollWidth` = `innerWidth` a 1300 y a 390 px.
- El **TOTAL CARGOS DE CUENTA** de la página = el calculado en el cuadre.
- Formatos: moneda con `$` y miles, negativos en rojo, porcentajes reales, nunca números crudos.

---

## 11. El bloque de caja — desglosado o no se publica

No va en el artefacto por defecto; si se pide o se usa en el chat, **desglosado**:

```
Ventas del mes (con IVA en MX)                   $X
− Costos directos por producto                   $X
− Gastos compartidos de cuenta (sin el ISR)      $X
= Contribución del canal antes de retenciones    $X
− IVA retenido sobre ventas del mes              $X
− ISR de ventas del mes anterior, cobrado ahora  $X
= Lo que quedó de las liquidaciones del mes      $X
```

> «De los cobros que Amazon procesó en <mes>, después de costos e impuestos retenidos, quedaron $X. **No es el saldo de tu banco**; resume qué dejaron las liquidaciones de Amazon de ese mes.»

El **ISR devengado** no aparece aquí (*«ISR devengado en <mes>, pendiente de cobro en <mes+1>: $X»*). Nunca «flujo neto», «P&L», «EBITDA», «utilidad neta». En USA, sin las líneas de retenciones.

**Las tres bolsas:** (1) costos directos por producto; (2) gastos compartidos de cuenta (los renglones del bloque de cargos); (3) IVA e ISR retenidos (solo MX), efecto de caja, no pérdida.

---

## 12. Cuando falta algo — nunca se detiene

| Qué falta | Qué se hace |
|---|---|
| **Costos** | Corre todo lo demás, aviso grande de qué se pierde |
| **Bulk de publicidad** | Sin ACOS ni TACOS; se omite el bloque de publicidad de marca y se dice |
| **Business Report** | Sin conversión ni cuadre de unidades; se dice |
| **Fee Preview** | Los SKU salen con su código en vez de nombre |
| **Reporte de transacciones** | **Detiene todo.** Se explica cómo bajarlo y se espera |
| **Catálogo de 1–3 SKU** | Corre; se dice que tiers y medianas no informan |
| **Mes con muy poca venta** | Se pide otro mes |
| **Mes en curso o rango partido** | No se corre; se pide el mes cerrado completo |
| **Reporte Summary** | No se corre; se repite la ruta de Reports Repository |
| **Cargo de cuenta no clasificable** | Detiene y se pregunta |

**Formato del aviso:** qué falta · qué no se pudo calcular · qué sí está · cómo conseguirlo.

---

## 13. Límites y honestidad

Esta skill **analiza y prepara. No ejecuta.** No cambia precios, no abre casos con Amazon (redacta el texto y la evidencia; nada sale sin OK explícito), no pausa campañas, no desactiva listings, no da asesoría fiscal. **Los datos del vendedor no salen de su cuenta.**

### Cierre en el chat

Cortito: **las 3 decisiones** con cifras y etiqueta, qué falta, qué se verificó. **Se dice lo que quedó y lo que no**: si un cuadre no corrió, si faltó un archivo, si un dato no se verificó, se nombra con el motivo.

### Las cinco preguntas antes de entregar

1. ¿Le habla a alguien que **ya vende**? 2. ¿Muestra utilidad y control, no vanidad? 3. ¿Encontró una fuga o dinero por validar que el vendedor no vería fácil? 4. ¿Demuestra por qué hace falta un sistema completo? 5. ¿Evita promesas de dinero, ACOS objetivo o campañas específicas que los datos no prueban? **Si alguna sale que no, se corrige antes de entregar.**

---

## 14. Plantilla del artefacto — se usa tal cual

**Procedimiento:**

1. Calcular con los reportes (secciones 2 a 8) los datos por producto, hijos, cargos y cobros.
2. Copiar la plantilla **completa** a un archivo `.html` y reemplazar **solo** el bloque entre `/* ===== DATOS` y `/* ===== FIN DATOS ===== */` por los datos del vendedor. **No se toca el CSS, el HTML ni el resto del JS.** Si hace falta otra columna o bloque, se avisa al dueño de la skill para v1.3; no se improvisa.
3. Probar (sección 10, «Antes de publicar») y publicar con `capabilities: {downloads: true}`.

Campos de `DATA`: `tienda`, `pais` (`'MX'` o `'US'`; en US desaparecen las columnas de retenciones), `mes`, `periodo`, `moneda`, `muestra`, `nota`; `productos` (Parent, 19 campos en el orden del comentario); `hijos` (opcional, `[parent, nombre, …19 campos]`); `sin` (sin venta o sin clasificar); `sb` (publicidad de marca); `cargos` (`[nombre, monto negativo, nota]`); `pubAsignada` (positivo); `rev` (tarjetas de revisión: `[título, texto, etiqueta, ok]`).

```html
<title>Profit AI System Diagnóstico Amazon</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root{
  color-scheme:dark;
  --bg:#0A0A0A; --panel:#111111; --panel2:#171717; --line:#222222; --line2:#333333;
  --accent:#FF6B00; --accent-soft:#FFB347; --on-accent:#0A0A0A;
  --fg:#FFFFFF; --fg2:#A0A0A0; --fg3:#666666;
  --ok:#35B37E; --warn:#E5A03C; --bad:#E5484D;
  --ui:'Inter',system-ui,-apple-system,'Segoe UI',sans-serif;
  --mono:'JetBrains Mono',ui-monospace,Menlo,Consolas,monospace;
}
*{box-sizing:border-box}
body{background:var(--bg);color:var(--fg);font-family:var(--ui);font-size:14px;line-height:1.55;margin:0}
.num{font-family:var(--mono);font-variant-numeric:tabular-nums}
.neg{color:var(--bad)}
.gut{padding-inline:max(16px,3vw)}
.wrap{width:100%;max-width:1280px;margin:0 auto;min-width:0}
section,main,.gut{min-width:0}
.tw{max-width:100%}
h1,h2,h3,p{margin:0;text-wrap:balance}
.bar{position:sticky;top:env(safe-area-inset-top,0px);z-index:20;background:rgba(10,10,10,.94);border-bottom:1px solid var(--line);backdrop-filter:blur(6px)}
.bar .wrap{display:flex;align-items:center;gap:12px;padding-block:9px}
.bar .nm{font-weight:800;letter-spacing:.06em;font-size:13px;white-space:nowrap}
.bar .nm i{font-style:normal;color:var(--accent)}
.bar .sub{color:var(--fg2);font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}
.bar .sp{flex:1}
.bar .mu{font-family:var(--mono);font-size:10.5px;letter-spacing:.12em;color:var(--on-accent);background:var(--accent-soft);padding:3px 8px;border-radius:3px;font-weight:700;white-space:nowrap}
.logo{width:30px;height:30px;flex:none;display:block}
.hero{border-bottom:1px solid var(--line);position:relative;padding-block:34px 30px}
.hero::before{content:'';position:absolute;left:0;right:0;top:0;height:3px;background:var(--accent)}
.lock{display:flex;align-items:center;gap:16px;flex-wrap:wrap}
.lock .logo{width:68px;height:68px}
.lock .wm{display:flex;flex-direction:column;line-height:1}
.lock .wm b{font-size:clamp(34px,6vw,60px);font-weight:900;letter-spacing:-.02em}
.lock .wm span{font-family:var(--mono);font-weight:700;color:var(--accent);letter-spacing:.42em;font-size:clamp(12px,1.9vw,19px);margin-top:8px}
.hero h1{font-size:clamp(20px,3vw,30px);font-weight:700;margin-top:26px;letter-spacing:-.01em}
.hero .tag{color:var(--fg2);margin-top:6px;font-size:15px;max-width:70ch}
.hero .tag b{color:var(--fg)}
.facts{display:flex;flex-wrap:wrap;gap:8px 10px;margin-top:20px}
.fact{border:1px solid var(--line2);background:var(--panel);padding:6px 12px;border-radius:4px;font-size:12px;color:var(--fg2)}
.fact b{color:var(--fg);font-weight:600}
.fact.br{border-color:var(--accent);color:var(--accent-soft)}
.fact.br b{color:var(--accent-soft)}
main{display:flex;flex-direction:column;gap:44px;padding-block:32px 40px}
.sh{display:flex;flex-direction:column;gap:4px;margin-bottom:16px}
.eyebrow{font-size:11px;letter-spacing:.16em;text-transform:uppercase;color:var(--accent);font-weight:700}
.sh h2{font-size:22px;font-weight:800;letter-spacing:-.01em}
.sh p{color:var(--fg2);max-width:78ch}
.ctl{display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;margin-bottom:12px}
.seg{display:inline-flex;border:1px solid var(--line2);border-radius:6px;padding:3px;background:var(--panel)}
.seg button{font-family:var(--ui);font-size:13px;font-weight:600;color:var(--fg2);background:transparent;border:0;padding:8px 16px;border-radius:4px;cursor:pointer;display:flex;gap:8px;align-items:center}
.seg button .c{font-family:var(--mono);font-size:11px;color:var(--fg3)}
.seg button[aria-selected="true"]{background:var(--accent);color:var(--on-accent)}
.seg button[aria-selected="true"] .c{color:var(--on-accent)}
.seg.sm button{font-size:12px;padding:6px 12px}
button:focus-visible,th.sort:focus-visible{outline:2px solid var(--accent-soft);outline-offset:2px}
.callout{border:1px solid var(--warn);background:#1a1407;border-radius:4px;padding:11px 14px;font-size:13px;color:#d9cdb3;display:flex;gap:12px;align-items:center;justify-content:space-between;flex-wrap:wrap;margin-bottom:12px}
.callout b{color:var(--fg)}
.lk{font-family:var(--ui);background:transparent;border:1px solid var(--warn);color:var(--warn);padding:5px 12px;border-radius:4px;font-weight:600;font-size:12px;cursor:pointer}
.tw{overflow:auto;max-height:76vh;border:1px solid var(--line);border-radius:6px;background:var(--panel)}
table.big{border-collapse:separate;border-spacing:0;font-size:12.5px;min-width:100%}
table.big th,table.big td{padding:8px 11px;white-space:nowrap;text-align:right;border-bottom:1px solid var(--line);border-right:1px solid #1a1a1a;background:var(--panel)}
table.big thead th{position:sticky;background:#0e0e0e;color:var(--fg2);font-weight:600;font-size:11.5px;z-index:2}
table.big thead tr:first-child th{top:0;color:var(--accent);letter-spacing:.12em;font-size:10.5px;text-align:center;border-bottom:1px solid var(--line2);z-index:3;font-weight:700}
table.big thead tr:nth-child(2) th{top:29px;border-bottom:1px solid var(--line2)}
table.big th.sort{cursor:pointer;user-select:none}
table.big th.sort:hover{color:var(--fg)}
table.big th.sort[data-d="1"]::after{content:' ▲';color:var(--accent)}
table.big th.sort[data-d="-1"]::after{content:' ▼';color:var(--accent)}
table.big td.pn,table.big th.pn{position:sticky;left:0;text-align:left;z-index:1;min-width:170px;border-right:1px solid var(--line2)}
table.big thead th.pn{z-index:4}
table.big td.pn{font-weight:600}
table.big td.pn small{display:block;font-weight:500;font-size:11px;color:var(--fg3)}
table.big td.pn .pill{display:inline-block;margin-top:3px;font-size:10px;font-weight:700;color:var(--warn);border:1px solid var(--warn);border-radius:99px;padding:1px 7px}
table.big td.acc{white-space:normal;min-width:250px;text-align:left;color:var(--fg2);font-size:12px}
table.big tr.sub td{background:var(--panel2);font-weight:700;border-top:1px solid var(--line2)}
table.big tr.tot td{background:#1b1208;font-weight:700;border-top:1px solid var(--accent)}
table.big tr.sub td.pn,table.big tr.tot td.pn{background:inherit}
table.big tr.nv td{color:var(--fg3)}
.sem{display:inline-block;font-size:10.5px;font-weight:800;padding:2px 8px;border-radius:3px;letter-spacing:.03em;color:#0A0A0A}
.s-ss{background:#2FD38F}.s-sano{background:var(--ok)}.s-ac{background:#B9C24A}.s-rev{background:var(--warn)}.s-pel{background:#F0714F}.s-pi{background:var(--bad);color:#fff}
.vol{font-size:10.5px;font-weight:700;color:var(--fg2);letter-spacing:.07em}
.vol.core{color:var(--accent-soft)}
.legend{display:flex;flex-wrap:wrap;gap:8px 16px;align-items:center;margin-top:12px;font-size:12px;color:var(--fg2)}
.legend .g{display:flex;gap:6px;align-items:center}
.legend .t{color:var(--fg3);font-size:11px}
.note{font-size:12px;color:var(--fg3);margin-top:8px;max-width:110ch}
.chg{background:var(--panel);border:1px solid var(--line);border-radius:6px;overflow:hidden}
.chg h3{margin:0;padding:12px 16px;background:#1b1208;border-bottom:1px solid var(--accent);color:var(--accent-soft);font-size:12px;letter-spacing:.12em;font-weight:800}
.chg .r{display:flex;justify-content:space-between;gap:16px;padding:10px 16px;border-bottom:1px solid var(--line);font-size:13.5px;color:var(--fg)}
.chg .r span:last-child{font-family:var(--mono);font-variant-numeric:tabular-nums;white-space:nowrap}
.chg .r small{color:var(--fg3);font-size:11.5px;margin-left:6px}
.chg .r.cr span:last-child{color:var(--ok)}
.chg .r.tt{background:#1b1208;font-weight:800;border-top:1px solid var(--accent);border-bottom:0}
.chg.sb{margin-top:14px}
.chg .sbx{display:flex;flex-wrap:wrap;gap:8px 28px;padding:12px 16px;font-size:13.5px}
.chg .sbx b{font-family:var(--mono);font-variant-numeric:tabular-nums}
.pay{background:var(--panel);border:1px solid var(--line);border-radius:6px;padding:20px;display:flex;flex-direction:column;gap:16px}
.pay .top{display:flex;flex-wrap:wrap;gap:16px;align-items:center;justify-content:space-between}
.pay .big{font-family:var(--mono);font-size:36px;font-weight:700;color:var(--accent-soft);line-height:1.1}
.pay .big small{display:block;font-family:var(--ui);font-size:12px;font-weight:500;color:var(--fg2);margin-top:4px}
.btn{font-family:var(--ui);font-weight:800;font-size:14px;background:var(--accent);color:var(--on-accent);border:0;padding:13px 22px;border-radius:5px;cursor:pointer;display:inline-flex;align-items:center;gap:10px}
.btn[disabled]{opacity:.5;cursor:default}
.btn svg{width:18px;height:18px}
.msg{font-size:12.5px;color:var(--fg2);min-height:18px}
table.s{border-collapse:collapse;width:100%;font-size:13px}
table.s th,table.s td{padding:10px 12px;border-bottom:1px solid var(--line);text-align:right;white-space:nowrap}
table.s th:first-child,table.s td:first-child{text-align:left}
table.s td.l,table.s th.l{text-align:left;white-space:normal}
table.s th{font-weight:600;color:var(--fg2);font-size:11.5px;letter-spacing:.04em}
.chip{display:inline-block;font-size:11px;font-weight:600;border:1px solid var(--warn);color:var(--warn);padding:2px 9px;border-radius:99px}
.chip.ok{border-color:var(--line2);color:var(--fg2)}
.sc{overflow-x:auto;max-width:100%}
.warnbox{border-left:3px solid var(--accent);background:var(--panel2);padding:12px 14px;font-size:13px;color:var(--fg2);border-radius:0 4px 4px 0}
.warnbox b{color:var(--fg)}
.chk{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:10px}
.chk div{border:1px solid var(--line);border-radius:4px;padding:10px 12px;font-size:12.5px;color:var(--fg2);display:flex;flex-direction:column;gap:3px}
.chk b{color:var(--fg);font-size:12.5px}
footer{border-top:1px solid var(--line);padding-block:26px 40px}
footer .wrap{display:flex;flex-wrap:wrap;gap:16px;align-items:center;justify-content:space-between}
footer .l{display:flex;align-items:center;gap:12px}
footer .l .logo{width:38px;height:38px}
footer .nm{font-weight:900;letter-spacing:.05em;font-size:15px}
footer .nm i{font-style:normal;color:var(--accent)}
footer .by{color:var(--fg2);font-size:12px}
footer .pf{font-weight:700;color:var(--accent-soft);font-size:13px;border:1px solid var(--accent);padding:7px 14px;border-radius:4px}
@media (max-width:640px){.bar .sub{display:none}.lock .logo{width:52px;height:52px}}
</style>

<svg width="0" height="0" style="position:absolute" aria-hidden="true">
  <symbol id="mark" viewBox="0 0 64 64">
    <rect width="64" height="64" rx="12" fill="#FF6B00"/>
    <rect x="12" y="38" width="9" height="14" rx="1.5" fill="#0A0A0A"/>
    <rect x="27" y="29" width="9" height="23" rx="1.5" fill="#0A0A0A"/>
    <rect x="42" y="18" width="9" height="34" rx="1.5" fill="#0A0A0A"/>
    <path d="M12 27 L28 17 L36 21 L52 9" fill="none" stroke="#0A0A0A" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M44 9 H52 V17" fill="none" stroke="#0A0A0A" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
  </symbol>
</svg>

<div class="bar gut">
  <div class="wrap">
    <svg class="logo" aria-hidden="true"><use href="#mark"/></svg>
    <span class="nm">PROFIT <i>AI SYSTEM</i></span>
    <span class="sub">Diagnóstico de Rentabilidad Amazon · por Gerardo Villa</span>
    <span class="sp"></span>
    <span class="mu" id="mu" hidden>MUESTRA</span>
  </div>
</div>

<header class="hero gut">
  <div class="wrap">
    <div class="lock">
      <svg class="logo" role="img" aria-label="Profit AI System"><use href="#mark"/></svg>
      <div class="wm"><b>PROFIT</b><span>AI SYSTEM</span></div>
    </div>
    <h1>Diagnóstico de Rentabilidad Amazon · por Gerardo Villa</h1>
    <p class="tag"><b>Seller Central te da datos. Este diagnóstico te da decisiones.</b> Qué producto deja dinero, cuál se lo lleva y qué cobros de Amazon merecen revisión.</p>
    <div class="facts" id="facts"></div>
    <div class="facts"><span class="fact">Corrió en tu propia cuenta. Tus reportes no salieron de ahí.</span></div>
  </div>
</header>

<main class="gut">
<div class="wrap" style="display:flex;flex-direction:column;gap:44px">

<section id="productos" aria-label="Rentabilidad por producto">
  <div class="sh">
    <span class="eyebrow">1 · Tus productos</span>
    <h2>Qué producto deja dinero y cuál se lo lleva</h2>
    <p>Empieza por Parent. Cambia a Child cuando un Parent esconda una variante que arrastra el resultado.</p>
  </div>
  <div class="ctl">
    <div class="seg" role="tablist" aria-label="Nivel de producto">
      <button role="tab" id="tp" aria-selected="true" data-view="parent">Parent <span class="c" id="cp"></span></button>
      <button role="tab" id="tc" aria-selected="false" data-view="child">Child <span class="c" id="cc"></span></button>
    </div>
    <div class="seg sm" role="group" aria-label="Columnas">
      <button aria-selected="true" data-cols="key">Columnas clave</button>
      <button aria-selected="false" data-cols="all">Todas las columnas</button>
    </div>
  </div>
  <div id="co"></div>
  <div class="tw"><table class="big" id="big"></table></div>
  <div class="legend" id="legend"></div>
  <p class="note">ACOS y TACOS miden solo Sponsored Products; la publicidad de marca se muestra aparte y no baja a producto. Los porcentajes se recalculan desde los totales. Haz clic en un encabezado para ordenar. Los subtotales no llevan Volumen ni Acción.</p>
</section>

<section id="cargos" aria-label="Cargos de cuenta">
  <div class="sh"><span class="eyebrow">2 · Cargos de cuenta</span><h2>Lo que Amazon cobra y no baja a ningún producto</h2></div>
  <div id="cg"></div>
</section>

<section id="cobros" aria-label="Cobros por validar">
  <div class="sh">
    <span class="eyebrow">3 · Cobros de Amazon</span>
    <h2>Lo que Amazon pudo haberte cobrado de más</h2>
    <p>Solo el mes analizado. Cada renglón es una posible diferencia que hay que validar, no un reembolso.</p>
  </div>
  <div class="pay">
    <div class="top">
      <div class="big num"><span id="vt"></span><small id="vs"></small></div>
      <div style="display:flex;flex-direction:column;gap:8px;align-items:flex-start">
        <button class="btn" id="dl" type="button" disabled>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v12m0 0l-5-5m5 5l5-5M4 20h16"/></svg>
          Descargar expediente de cobros (CSV)
        </button>
        <span class="msg" id="dm" role="status"></span>
      </div>
    </div>
    <div class="warnbox">Vimos <b id="vt2"></b> que Amazon podría haberte cobrado de más en el mes analizado. Aún hay que revisar producto por producto antes de reclamarlo. <b>No es dinero garantizado.</b> Si se confirma, ya tienes la información para pedirle a Amazon que revise el cobro.</div>
    <div class="sc"><table class="s" id="vtab"></table></div>
    <div class="chk" id="rev"></div>
    <p class="note" style="margin:0">Ruta del caso: Ayuda › Obtener soporte › Vender en Amazon › <b>Reconcile Charges</b> › Review Fees › Order ID › Contact an associate › pestaña <b>Email</b> (nunca por chat: necesitas adjuntos y rastro escrito). Si un SKU cobra de más de forma sistemática, suele ser peso o dimensiones mal medidos: usa FBA product weights and dimensions. Sistema que resuelve esto: Auditoría y Recuperación Amazon. No se manda nada a Amazon sin tu OK.</p>
  </div>
</section>

</div>
</main>

<footer class="gut">
  <div class="wrap">
    <div class="l">
      <svg class="logo" aria-hidden="true"><use href="#mark"/></svg>
      <div><div class="nm">PROFIT <i>AI SYSTEM</i></div><div class="by">Diagnóstico de Rentabilidad Amazon · por Gerardo Villa</div></div>
    </div>
    <div class="pf">$5M+ USD en ventas verificadas en Amazon MX/USA</div>
  </div>
</footer>

<script>
(function(){
'use strict';
var $=function(i){return document.getElementById(i)};
var fm=function(n,d){d=d==null?0:d;var s=Math.abs(n).toLocaleString('es-MX',{minimumFractionDigits:d,maximumFractionDigits:d});return (n<0?'-':'')+'$'+s};
var fp=function(n,d){d=d==null?1:d;return (n*100).toFixed(d)+'%'};
var neg=function(n,h){return n<0?'<span class="neg">'+h+'</span>':h};

/* ===== DATOS: la skill reemplaza SOLO este bloque con los números del vendedor ===== */
var DATA={
 tienda:'Amazon México', pais:'MX', mes:'agosto 2026', periodo:'1 a 31 de agosto de 2026', moneda:'MXN', muestra:false,
 nota:'Costo de producto puesto en tu bodega, confirmado por ti',
 /* productos (Parent): [nombre, uds, pub SP, ventas con ads, ventas, costo unit, comisión %, comisión $, FBA $/u, FBA total, costo producto, devoluciones, ajustes FBA, IVA retenido, ISR devengado, FBA debería ser, dif FBA, por validar $, uds a revisar] */
 productos:[],
 /* hijos (Child), opcional: [parent, nombre, ...mismos 19 campos] */
 hijos:[],
 /* sin venta / sin clasificar: [nombre, publicidad, ventas con ads] */
 sin:[],
 /* publicidad de marca SB/SD: no baja a producto */
 sb:{pub:0,va:0},
 /* cargos de cuenta, de mayor a menor: [nombre, monto negativo, nota opcional] */
 cargos:[],
 pubAsignada:0,
 /* revisión de cobros: [título, texto, etiqueta, ok(true/false)] */
 rev:[]
};
/* ===== FIN DATOS ===== */
var P=DATA.productos, SIN=DATA.sin, HIJOS=DATA.hijos||[], SBD=DATA.sb;
var ES_MX=DATA.pais==='MX';

function ent(o){
  o.acos=o.va&&o.pub? o.pub/o.va:null; o.tacos=o.v&&o.pub? o.pub/o.v:null; o.precio=o.u? o.v/o.u:null;
  o.ct=o.c$+o.ft+o.cpr; o.ub=o.v-o.ct; o.un=o.ub-o.pub; o.pu=o.v? o.un/o.v:null;
  o.con=o.un-o.dev+o.aj-o.iva-o.isr; o.pf=o.v? o.con/o.v:null; o.cx=o.u? o.con/o.u:null; o.ret=o.cpr? o.con/o.cpr:null;
  o.fu=o.u? o.ft/o.u:o.fu; return o;
}
var mk=function(r,n){return ent({n:n,u:r[1],pub:r[2],va:r[3],v:r[4],cu:r[5],cp:r[6],c$:r[7],fu:r[8],ft:r[9],cpr:r[10],dev:r[11],aj:r[12],iva:r[13],isr:r[14],fd:r[15],df:r[16],val:r[17],vu:r[18]})};
var T=P.map(function(r){return mk(r,r[0])});
var sumK=function(a,k){return a.reduce(function(s,r){return s+r[k]},0)};
var sinPub=SIN.reduce(function(a,r){return a+r[1]},0), sinVa=SIN.reduce(function(a,r){return a+r[2]},0);
var S={n:'Subtotal productos (solo Sponsored Products)',u:sumK(T,'u'),pub:sumK(T,'pub')+sinPub,va:sumK(T,'va')+sinVa,v:sumK(T,'v'),c$:sumK(T,'c$'),ft:sumK(T,'ft'),cpr:sumK(T,'cpr'),dev:sumK(T,'dev'),aj:sumK(T,'aj'),iva:sumK(T,'iva'),isr:sumK(T,'isr'),fd:sumK(T,'fd'),df:sumK(T,'df'),val:sumK(T,'val'),vu:sumK(T,'vu')};
S.cu=S.cpr/S.u; S.cp=S.c$/S.v; ent(S); S.tot=true;
var CONTOT=S.con;
var TOT=ent({n:'TOTAL '+DATA.tienda.toUpperCase()+' (con publicidad de marca)',u:S.u,pub:S.pub+SBD.pub,va:S.va+SBD.va,v:S.v,c$:S.c$,ft:S.ft,cpr:S.cpr,dev:S.dev,aj:S.aj,iva:S.iva,isr:S.isr,fd:S.fd,df:S.df,val:S.val,vu:S.vu,cu:S.cu,cp:S.cp});TOT.tot=true;
var SB={n:'Publicidad de marca (SB/SD): no baja a producto',pub:SBD.pub,va:SBD.va,sbrow:true};

function salud(r){return r<.20?'PIERDE':r<.45?'PELIGRO':r<.70?'REVISAR':r<1?'ACEPTABLE':r<1.5?'SANO':'SÚPER SANO'}
function tier(c){var s=c/CONTOT;return s>=.10?'CORE':s>=.02?'RELEVANTE':s>=.005?'MARGINAL':'RUIDO'}
function accion(roi,t,pub,sv){
  var g=(t==='CORE'||t==='RELEVANTE')||sv>=.03;
  if(roi<.20)return g?'PARAR VENTAS YA':'DESCONTINUAR';
  if(roi<.45){if(t==='CORE')return 'EMERGENCIA: volumen drenando caja';return g?'Cortar publicidad y arreglar precio o empaque':'DESCONTINUAR'}
  if(roi<.70){if(t==='CORE')return 'EMERGENCIA: volumen drenando caja';return g?'Cortar publicidad y arreglar precio o empaque':'Cortar publicidad y revisar precio'}
  if(roi<1){if(t==='CORE')return 'Arreglar antes de crecer: precio o publicidad';if(t==='RELEVANTE')return 'Subir precio 5-10% y medir';return 'Dejar quieto: no merece presupuesto'}
  if(t==='CORE')return 'Proteger stock y subir publicidad';
  if(t==='RELEVANTE')return 'ESCALAR FUERTE: aquí va el presupuesto';
  if(pub<500)return 'PROBAR: rentable con publicidad limitada';
  return 'Ya se empujó con presupuesto y no jaló';
}
function clasifica(r){r.s=salud(r.ret);r.t=tier(r.con);r.a=accion(r.ret,r.t,r.pub,r.v/S.v)}
T.forEach(clasifica);
S.s=salud(S.ret);TOT.s=salud(TOT.ret);

/* variantes */
var KIDS=[];
T.forEach(function(p){
  var hs=HIJOS.filter(function(h){return h[0]===p.n});
  if(!hs.length){var k=ent(Object.assign({},p));k.n=p.n+' · Variante 1';k.parent=p.n;k.single=true;clasifica(k);p.kids=[k];KIDS.push(k);return}
  p.kids=hs.map(function(h){var k=mk(h.slice(1),p.n+' · '+h[1]);k.parent=p.n;clasifica(k);KIDS.push(k);return k});
  var rs=p.kids.map(function(k){return k.ret});p.rango=Math.max.apply(null,rs)-Math.min.apply(null,rs);
  if(p.rango>.40){p.flag=true;p.peor=p.kids.reduce(function(a,k){return k.ret<a.ret?k:a});p.mejor=p.kids.reduce(function(a,k){return k.ret>a.ret?k:a})}
});

/* columnas */
var SEMC={'SÚPER SANO':'s-ss','SANO':'s-sano','ACEPTABLE':'s-ac','REVISAR':'s-rev','PELIGRO':'s-pel','PIERDE':'s-pi'};
var m$=function(n){return n==null||isNaN(n)?['','']:[n,neg(n,fm(n))]};
var mp=function(n,d){return n==null||isNaN(n)?['','']:[n,neg(n,fp(n,d==null?1:d))]};
var m2=function(n){return n==null||isNaN(n)?['','']:[n,neg(n,fm(n,2))]};
var COLS=[
 {g:'PRODUCTO',l:'Producto',k:1,t:'pn'},
 {g:'PRODUCTO',l:'Unidades',k:1,get:function(r){return [r.u,r.u==null?'':r.u.toLocaleString('es-MX')]}},
 {g:'PUBLICIDAD',l:'Publicidad',k:1,get:function(r){return r.pub?m$(-r.pub):['','']}},
 {g:'PUBLICIDAD',l:'Ventas con ads',k:0,get:function(r){return r.va?m$(r.va):['','']}},
 {g:'PUBLICIDAD',l:'ACOS',k:1,get:function(r){return mp(r.acos)}},
 {g:'VENTA',l:'Ventas totales',k:1,get:function(r){return m$(r.v)}},
 {g:'VENTA',l:'TACOS',k:1,get:function(r){return mp(r.tacos)}},
 {g:'VENTA',l:'Precio prom.',k:0,get:function(r){return m2(r.precio)}},
 {g:'COSTOS',l:'Costo unit.',k:0,get:function(r){return m2(r.cu)}},
 {g:'COSTOS',l:'Comisión ref. %',k:0,get:function(r){return mp(r.cp)}},
 {g:'COSTOS',l:'Comisión ref. $',k:0,get:function(r){return m$(-r.c$)}},
 {g:'COSTOS',l:'Tarifa FBA $/u',k:0,get:function(r){return m2(r.fu)}},
 {g:'COSTOS',l:'Costo FBA total',k:0,get:function(r){return m$(-r.ft)}},
 {g:'COSTOS',l:'Costo producto',k:0,get:function(r){return m$(-r.cpr)}},
 {g:'COSTOS',l:'Costo total',k:0,get:function(r){return m$(-r.ct)}},
 {g:'UTILIDAD',l:'Util. bruta',k:0,get:function(r){return m$(r.ub)}},
 {g:'UTILIDAD',l:'Util. tras publicidad',k:1,get:function(r){return m$(r.un)}},
 {g:'UTILIDAD',l:'% utilidad',k:0,get:function(r){return mp(r.pu)}},
 {g:'AJUSTES DEL REPORTE',l:'Devoluciones',k:0,get:function(r){return r.dev?m$(-r.dev):['','']}},
 {g:'AJUSTES DEL REPORTE',l:'Ajustes FBA',k:0,get:function(r){return r.aj?m$(r.aj):['','']}},
 {g:'RETENCIONES',l:'IVA retenido',k:0,get:function(r){return m$(-r.iva)}},
 {g:'RETENCIONES',l:'ISR devengado 2.5%',k:0,get:function(r){return m$(-r.isr)}},
 {g:'RESULTADO FINAL',l:'Contribución del producto',k:1,get:function(r){return m$(r.con)}},
 {g:'RESULTADO FINAL',l:'% final',k:1,get:function(r){return mp(r.pf)}},
 {g:'RESULTADO FINAL',l:'Contribución $/u',k:0,get:function(r){return m2(r.cx)}},
 {g:'RETORNO SOBRE COSTO',l:'Costo unitario producto',k:0,get:function(r){return m2(r.cu)}},
 {g:'RETORNO SOBRE COSTO',l:'Retorno s/ costo',k:1,get:function(r){return mp(r.ret)}},
 {g:'RETORNO SOBRE COSTO',l:'Salud del costo',k:1,t:'t',get:function(r){return [r.s,r.s?'<span class="sem '+SEMC[r.s]+'">'+r.s+'</span>':'']}},
 {g:'RETORNO SOBRE COSTO',l:'Volumen',k:1,t:'t',get:function(r){return [r.t,r.t?'<span class="vol'+(r.t==='CORE'?' core':'')+'">'+r.t+'</span>':'']}},
 {g:'RETORNO SOBRE COSTO',l:'Acción',k:1,t:'a',get:function(r){return [r.a,r.a||'']}},
 {g:'ATENCIÓN',l:'FBA debería ser',k:0,get:function(r){return m$(-r.fd)}},
 {g:'ATENCIÓN',l:'Dif. FBA',k:0,get:function(r){return m$(r.df)}},
 {g:'ATENCIÓN',l:'Por validar',k:1,get:function(r){return r.val?m$(r.val):['','']}}
];
var st={view:'parent',cols:'key',sk:null,sd:-1};
var visCols=function(){return COLS.map(function(c,i){return {c:c,i:i}}).filter(function(x){return (ES_MX||x.c.g!=='RETENCIONES')&&(st.cols==='all'||x.c.k)})};

function cell(r,c,i,isFirst){
  var cls=c.t==='pn'?'pn':c.t==='a'?'acc':'num';
  if(c.t==='pn'){
    var h=r.n;
    if(r.parent){h=r.n.split(' · ')[1]+'<small>'+r.parent+'</small>'}
    else if(r.kids&&r.kids.length>0&&!r.tot){h=r.n+'<small>'+(r.kids.length===1?'1 variante':r.kids.length+' variantes')+'</small>'+(r.flag?'<span class="pill">Decidir por Child</span>':'')}
    return '<td class="pn">'+h+'</td>';
  }
  var v=c.get(r);
  if((r.tot||r.sbrow)&&(c.t==='t'||c.t==='a')&&!(r.tot&&c.l==='Salud del costo'))v=['',''];
  return '<td class="'+cls+'" data-v="'+(v[0]==null?'':(typeof v[0]==='number'?v[0]:''))+'">'+v[1]+'</td>';
}
function rowHtml(r,cls){
  var vc=visCols();
  return '<tr class="'+(cls||'')+'">'+vc.map(function(x,j){return cell(r,x.c,x.i,j===0)}).join('')+'</tr>';
}
function noVenta(s,n){
  var vc=visCols();
  return '<tr class="nv">'+vc.map(function(x){
    var l=x.c.l;
    if(x.c.t==='pn')return '<td class="pn">'+s[0]+'</td>';
    if(l==='Unidades')return '<td class="num">0</td>';
    if(l==='Publicidad')return '<td class="num neg">'+fm(-s[1])+'</td>';
    if(l==='Ventas con ads')return '<td class="num">'+fm(s[2])+'</td>';
    if(l==='Util. tras publicidad'||l==='Contribución del producto')return '<td class="num neg">'+fm(-s[1])+'</td>';
    if(l==='Salud del costo')return '<td><span class="sem" style="background:#444;color:#ddd">SIN VENTA</span></td>';
    return '<td></td>';
  }).join('')+'</tr>';
}
function sortRows(rows){
  if(!st.sk)return rows;
  var c=COLS[st.sk];
  var key=function(r){var v=c.t==='pn'?r.n:c.get(r)[0];return v};
  return rows.slice().sort(function(a,b){
    var x=key(a),y=key(b);
    if(typeof x==='string'||typeof y==='string'){return st.sd*(String(x).localeCompare(String(y)))}
    if(x===''||x==null||isNaN(x))x=-Infinity; if(y===''||y==null||isNaN(y))y=-Infinity;
    return -st.sd*(y-x);
  });
}
function render(){
  var vc=visCols();
  var gr=[];vc.forEach(function(x){var g=x.c.g;if(gr.length&&gr[gr.length-1][0]===g)gr[gr.length-1][1]++;else gr.push([g,1])});
  var th1='<tr>'+gr.map(function(g,i){return '<th colspan="'+g[1]+'"'+(i===0?' class="pn"':'')+'>'+g[0]+'</th>'}).join('')+'</tr>';
  var th2='<tr>'+vc.map(function(x){var c=x.c;var so=c.t!=='t'&&c.t!=='a';return '<th class="'+(c.t==='pn'?'pn ':'')+(so?'sort':'')+'"'+(so?' tabindex="0" data-i="'+x.i+'"'+(st.sk===x.i?' data-d="'+st.sd+'"':''):'')+'>'+c.l+'</th>'}).join('')+'</tr>';
  var body='';
  var parents=T.slice().sort(function(a,b){return b.con-a.con});
  if(st.view==='parent'){
    sortRows(parents).forEach(function(r){body+=rowHtml(r)});
  }else{
    if(st.sk){sortRows(KIDS).forEach(function(r){body+=rowHtml(r)})}
    else parents.forEach(function(p){
      p.kids.slice().sort(function(a,b){return b.con-a.con}).forEach(function(k){body+=rowHtml(k)});
    });
  }
  SIN.forEach(function(s){body+=noVenta(s)});
  body+=rowHtml(S,'sub');
  body+='<tr class="sub">'+vc.map(function(x){var l=x.c.l;
    if(x.c.t==='pn')return '<td class="pn">'+SB.n+'</td>';
    if(l==='Publicidad')return '<td class="num neg">'+fm(-SB.pub)+'</td>';
    if(l==='Ventas con ads')return '<td class="num">'+fm(SB.va)+'</td>';
    if(l==='ACOS')return '<td class="num">'+(SB.va?fp(SB.pub/SB.va):'')+'</td>';
    return '<td></td>'}).join('')+'</tr>';
  body+=rowHtml(TOT,'tot');
  $('big').innerHTML='<thead>'+th1+th2+'</thead><tbody>'+body+'</tbody>';
  $('big').querySelectorAll('th.sort').forEach(function(th){
    var i=+th.getAttribute('data-i');
    var go=function(){if(st.sk===i){st.sd=-st.sd}else{st.sk=i;st.sd=-1}render()};
    th.addEventListener('click',go);
    th.addEventListener('keydown',function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();go()}});
  });
  var fl=T.filter(function(p){return p.flag});
  if(st.view==='parent'&&fl.length){
    var p=fl[0];
    $('co').innerHTML='<div class="callout"><span><b>'+p.n+'</b>: sus variantes van de <b class="num">'+fp(p.peor.ret,0)+'</b> a <b class="num">'+fp(p.mejor.ret,0)+'</b> de retorno sobre costo. El promedio del Parent esconde el problema: <b>decide por Child, no por Parent.</b> Arrastra '+p.peor.n.split(' · ')[1]+' ('+p.peor.u+' unidades, retorno '+fp(p.peor.ret,0)+').</span><button class="lk" type="button" id="go">Ver Child</button></div>';
    $('go').addEventListener('click',function(){setView('child')});
  }else{$('co').innerHTML=''}
}
function setView(v){st.view=v;st.sk=null;$('tp').setAttribute('aria-selected',v==='parent');$('tc').setAttribute('aria-selected',v==='child');render()}
$('tp').addEventListener('click',function(){setView('parent')});
$('tc').addEventListener('click',function(){setView('child')});
document.querySelectorAll('[data-cols]').forEach(function(b){b.addEventListener('click',function(){
  st.cols=b.getAttribute('data-cols');document.querySelectorAll('[data-cols]').forEach(function(x){x.setAttribute('aria-selected',x===b)});render()})});
$('cp').textContent=T.length; $('cc').textContent=KIDS.length;

var bands=[['SÚPER SANO','s-ss','150%+'],['SANO','s-sano','100-149%'],['ACEPTABLE','s-ac','70-99%'],['REVISAR','s-rev','45-69%'],['PELIGRO','s-pel','20-44%'],['PIERDE','s-pi','<20%']];
$('legend').innerHTML='<span class="t">RETORNO SOBRE COSTO: lo que deja cada peso invertido en producto</span>'+bands.map(function(b){return '<span class="g"><span class="sem '+b[1]+'">'+b[0]+'</span><span class="num">'+b[2]+'</span></span>'}).join('')+
 '<span class="t">VOLUMEN (parte de la contribución)</span><span class="g"><span class="vol core">CORE</span><span class="num">10%+</span></span><span class="g"><span class="vol">RELEVANTE</span><span class="num">2-10%</span></span><span class="g"><span class="vol">MARGINAL</span><span class="num">0.5-2%</span></span><span class="g"><span class="vol">RUIDO</span><span class="num">&lt;0.5%</span></span>';

/* cobros */
var VR=T.filter(function(r){return r.val>0}).sort(function(a,b){return b.val-a.val});
var vtot=sumK(VR,'val'), vun=sumK(VR,'vu');
$('vt').innerHTML=fm(vtot,2)+'<small>posible diferencia · '+VR.length+' productos · '+vun+' unidades</small>';
$('vt2').textContent=fm(vtot,2);
$('vtab').innerHTML='<thead><tr><th>Producto</th><th class="l">Qué se comparó</th><th>Unidades a revisar</th><th>Posible diferencia</th><th class="l">Etiqueta</th></tr></thead><tbody>'+
 VR.map(function(r){return '<tr><td><b>'+r.n+'</b></td><td class="l">Tarifa FBA por unidad vs la tarifa más frecuente del propio SKU en el mes</td><td class="num">'+r.vu+'</td><td class="num">'+fm(r.val,2)+'</td><td class="l"><span class="chip">Validar antes de actuar</span></td></tr>'}).join('')+
 '<tr><td><b>Total</b></td><td class="l"></td><td class="num"><b>'+vun+'</b></td><td class="num"><b>'+fm(vtot,2)+'</b></td><td class="l"></td></tr></tbody>';
$('rev').innerHTML=DATA.rev.map(function(x){return '<div><b>'+x[0]+'</b>'+x[1]+' <span class="chip'+(x[3]?' ok':'')+'" style="align-self:flex-start">'+x[2]+'</span></div>'}).join('');

/* cargos de cuenta: TOTAL = todos los renglones (incluido el ISR) + publicidad ya asignada */
var cs=DATA.cargos.reduce(function(a,c){return a+c[1]},0)+DATA.pubAsignada;
$('cg').innerHTML='<div class="chg"><h3>CARGOS QUE AMAZON NO ATA A NINGÚN PRODUCTO</h3>'+
 DATA.cargos.map(function(c){return '<div class="r"><span>'+c[0]+(c[2]?'<small>('+c[2]+')</small>':'')+'</span><span>'+fm(c[1],2)+'</span></div>'}).join('')+
 '<div class="r cr"><span>(-) Publicidad ya asignada por producto</span><span>+'+fm(DATA.pubAsignada,2)+'</span></div>'+
 '<div class="r tt"><span>TOTAL CARGOS DE CUENTA</span><span>'+fm(cs,2)+'</span></div></div>'+
 '<div class="chg sb"><h3>PUBLICIDAD DE MARCA — NO BAJA A PRODUCTO</h3><div class="sbx"><span>Gasto SB/SD <b>'+fm(SBD.pub,2)+'</b></span><span>Ventas <b>'+fm(SBD.va,2)+'</b></span><span>ACOS <b>'+(SBD.va?fp(SBD.pub/SBD.va):'—')+'</b></span></div></div>';

$('facts').innerHTML='<span class="fact">Tienda: <b>'+DATA.tienda+'</b></span><span class="fact">Periodo: <b>'+DATA.periodo+'</b></span><span class="fact">'+DATA.moneda+(ES_MX?' · venta con IVA':'')+'</span><span class="fact">'+DATA.nota+'</span>'+(DATA.muestra?'<span class="fact br"><b>Muestra:</b> datos de ejemplo</span>':'');
if(DATA.muestra)$('mu').hidden=false;

var esc=function(s){s=String(s);return /[",\n]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s};
function csv(){
  var h=['Producto','Concepto','Mes','Unidades a revisar','Posible diferencia ('+DATA.moneda+')','Etiqueta','Order IDs','Qué se comparó','Ruta del caso','Nota'];
  var rows=VR.map(function(r){return [r.n,'Tarifa FBA por unidad arriba de la tarifa normal del SKU',DATA.mes,r.vu,r.val.toFixed(2),'Validar antes de actuar','Completar desde el reporte de transacciones','Tarifa FBA por unidad vs la tarifa más frecuente del SKU en el mes','Ayuda > Obtener soporte > Vender en Amazon > Reconcile Charges > Review Fees > Order ID > Contact an associate > Email','Posible diferencia por validar. No es dinero garantizado: Amazon decide.']});
  rows.push(['TOTAL','',DATA.mes,vun,vtot.toFixed(2),'','','','','']);
  return '﻿'+[h].concat(rows).map(function(r){return r.map(esc).join(',')}).join('\r\n');
}
var btn=$('dl');
btn.addEventListener('click',function(){
  var ds=window.__dl; if(!ds)return;
  $('dm').textContent='';
  ds.save({filename:'expediente-cobros-por-validar-'+DATA.mes.replace(/\s+/g,'-')+'.csv',data:csv()}).then(function(){
    $('dm').textContent='Listo. Revisa tu carpeta de descargas.';
  }).catch(function(e){
    var c=e&&e.code;
    $('dm').textContent=c==='declined'?'Descarga cancelada. Puedes intentarlo otra vez.':c==='rate_limited'?'Espera unos segundos e inténtalo de nuevo.':'La descarga no está disponible en esta vista.';
  });
});
$('dm').textContent='';
if(window.claude&&window.claude.use){
  window.claude.use('downloads').then(function(d){
    if(d){window.__dl=d;btn.disabled=false}else{$('dm').textContent='La descarga no está disponible en esta vista.'}
  }).catch(function(){$('dm').textContent='La descarga no está disponible en esta vista.'});
}else{$('dm').textContent='La descarga no está disponible en esta vista.'}

render();
})();
</script>
```